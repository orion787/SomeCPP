#include "http_service.hpp"
#include <QHttpMultiPart>
#include <QHttpPart>
#include <QMetaEnum>

HttpClient::HttpClient(QObject *parent) : QObject(parent) {
    m_manager = new QNetworkAccessManager(this);
    // m_manager->setConnectTimeout(5000);  // 5 seconds
    // m_manager->setTransferTimeout(10000); // 10 seconds

    m_host = QUrl("http://" + QString(URL));
}

void HttpClient::get(const QString &urlPath) {
    QUrl requestURL = m_host.resolved(urlPath);

    QNetworkRequest request(requestURL);
    request.setTransferTimeout(requestTimeout);
    // request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    // request.setAttribute(QNetworkRequest::HttpPipeliningAllowedAttribute, true);

    QNetworkReply *m_reply = m_manager->get(request);
    m_reply->setProperty("request_type", QVariant::fromValue(RequestType::Get));
    m_reply->setProperty("urlPath", urlPath);

    connect(m_reply, &QNetworkReply::finished, this, &HttpClient::onFinished);
    connect(m_reply, &QNetworkReply::errorOccurred, this, &HttpClient::onError);
}

void HttpClient::post(const QString &urlPath, const QByteArray &body) {
    QUrl requestURL = m_host.resolved(urlPath);

    QNetworkRequest request(requestURL);
    request.setTransferTimeout(requestTimeout);
    // request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    // request.setAttribute(QNetworkRequest::HttpPipeliningAllowedAttribute, true);

    QNetworkReply *m_reply = m_manager->post(request, body);
    m_reply->setProperty("request_type", QVariant::fromValue(RequestType::Post));
    m_reply->setProperty("urlPath", urlPath);

    connect(m_reply, &QNetworkReply::finished, this, &HttpClient::onFinished);
    connect(m_reply, &QNetworkReply::errorOccurred, this, &HttpClient::onError);
}

void HttpClient::onFinished() {
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    if (!reply) return;

    RequestType requestType = reply->property("request_type").value<RequestType>();
    QString urlPath = reply->property("urlPath").toString();

    if (reply->error() != QNetworkReply::NoError) {
        emit replyError(requestType, urlPath, reply->error());
    } else {
        int statusCode = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        QByteArray data = reply->readAll();
        emit replyReady(requestType, urlPath, statusCode, data);
    }
    reply->deleteLater();
}

void HttpClient::onError(QNetworkReply::NetworkError error) {
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    if (!reply) return;

    emit replyError(reply->property("request_type").value<RequestType>(), reply->property("urlPath").toString(), error);
}

void HttpClient::postFile(const QString& urlPath, const QString& id, const QString& fileName, const QByteArray& fileBody)
{
    QUrl url = m_host.resolved(QUrl(urlPath));
    QNetworkRequest request(url);

    QHttpMultiPart *multiPart = new QHttpMultiPart(QHttpMultiPart::FormDataType, this);

    QHttpPart idPart;
    idPart.setHeader(QNetworkRequest::ContentDispositionHeader, QVariant("form-data; name=\"sequence\""));
    idPart.setBody(id.toUtf8());
    multiPart->append(idPart);

    QHttpPart filePart;
    QString disposition = QString("form-data; name=\"file\"; filename=\"%1\"").arg(fileName);
    filePart.setHeader(QNetworkRequest::ContentDispositionHeader, QVariant(disposition));

    filePart.setHeader(QNetworkRequest::ContentTypeHeader, QVariant("application/octet-stream"));
    filePart.setBody(fileBody);
    multiPart->append(filePart);

    QNetworkReply* m_reply = m_manager->post(request, multiPart);
    m_reply->setProperty("request_type", QVariant::fromValue(RequestType::PostFile));
    m_reply->setProperty("urlPath", urlPath);

    multiPart->setParent(m_reply);

    connect(m_reply, &QNetworkReply::finished, this, &HttpClient::onFinished);
    connect(m_reply, &QNetworkReply::errorOccurred, this, &HttpClient::onError);
}