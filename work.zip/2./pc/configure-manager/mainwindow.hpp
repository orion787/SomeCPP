#ifndef MAINWINDOW_HPP
#define MAINWINDOW_HPP

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    void updateCurrentView();
    void switchButtons(int index);
    void nextStep();
    void prevStep();
    void switchToFirstStep();
    void enableSwitchTabs();
    void disableSwitchTabs();
    void setupConnections();
};
#endif // MAINWINDOW_HPP
