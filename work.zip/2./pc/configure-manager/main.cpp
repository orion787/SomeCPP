#include "mainwindow.hpp"

#include <QApplication>
#include <QLocale>
#include <QTranslator>
#include "db_service/databaseservice.hpp"
#include <QStyleFactory>
#include <QDir>
#include <settings.hpp>

const QString LOG_FILE_PATH = "log.txt";

int main(int argc, char *argv[])
{

    QApplication a(argc, argv);

    QTranslator translator;
    const QStringList uiLanguages = QLocale::system().uiLanguages();
    for (const QString &locale : uiLanguages) {
        const QString baseName = "configure-manager_" + QLocale(locale).name();
        if (translator.load(":/i18n/" + baseName)) {
            a.installTranslator(&translator);
            break;
        }
    }

    if (Settings::instance().writingLogs()) {
        qInstallMessageHandler([](QtMsgType type, const QMessageLogContext &context, const QString &msg){
            QString fullMessage;
            switch (type) {
            case QtDebugMsg:
                fullMessage = QString("Debug: %1").arg(msg);
                break;
            case QtInfoMsg:
                fullMessage = QString("Info: %1").arg(msg);
                break;
            case QtWarningMsg:
                fullMessage = QString("Warning: %1").arg(msg);
                break;
            case QtCriticalMsg:
                fullMessage = QString("Critical: %1").arg(msg);
                break;
            case QtFatalMsg:
                fullMessage = QString("Fatal: %1").arg(msg);
                break;
            }

            QFile file(LOG_FILE_PATH);
            if (file.open(QIODevice::Append | QIODevice::Text)) {
                QTextStream out(&file);
                out << fullMessage << '\n';
            }

            QTextStream(stdout) << fullMessage << '\n';

            if (type == QtFatalMsg) {
                abort();
            }
        });;
    }



    QStringList requiredPaths = {
        Settings::instance().rootDataDirPath(),
        Settings::instance().audioDirPath(),
        Settings::instance().deviceAudioDirPath(),
        Settings::instance().modelsDirPath(),
        Settings::instance().scriptsDirPath()
    };

    QDir dir;
    for (QString path: requiredPaths) {
        if (!QDir(path).exists()) {
            if (dir.mkpath(path)) {
                qDebug() << path + "dir already exists!";
            } else {
                qDebug() << "Create dir error";
            }
        }
    }

    MainWindow w;
    w.show();

    QApplication::setStyle(QStyleFactory::create("Fusion"));

    return a.exec();
}
