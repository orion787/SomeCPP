#pragma once

#include <QObject>
#include <QTimer>
#include <QString>
#include <QStringList>
#include <QDir>

class SshActions : public QObject
{
    Q_OBJECT
public:
    explicit SshActions(QObject *parent = nullptr);
    ~SshActions();

    Q_INVOKABLE void connectAsync(const QString &host, int port,
                                  const QString &username, const QString &password);

    Q_INVOKABLE void disconnect(); // async

    Q_INVOKABLE QString executeCommand(const QString &command);
    Q_INVOKABLE bool downloadFile(const QString &remotePath, const QString &localPath);
    Q_INVOKABLE QStringList listRemoteDirectory(const QString &remotePath);
    Q_INVOKABLE void uploadFileAsync(const QString &localPath, const QString &remotePath);
    Q_INVOKABLE void uploadFilesAsync(const QStringList &localPaths, const QString &remoteDir);

    QString getLastError() const;

signals:
    void connected();
    void connectionFailed(const QString &error);
    void disconnected();
    void connectionCancelled();

    void uploadProgress(const QString &file, qint64 fileSent, qint64 fileSize);
    void uploadFinished(const QString &file);
    void uploadFailed(const QString &file, const QString &reason);

    void uploadTotalProgress(qint64 bytesSent, qint64 totalBytes);
    void uploadTotalFinished();

private:
    QString root;
    bool connectedFlag = false;
    QString lastError;
};
