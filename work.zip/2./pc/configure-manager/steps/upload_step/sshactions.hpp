#pragma once

#include <QObject>
#include <QThread>
#include <QString>
#include <atomic>
#include <string>
#include <vector>
#include <libssh2.h>
#include <libssh2_sftp.h>

class SshActions : public QObject
{
    Q_OBJECT

public:
    explicit SshActions();
    ~SshActions();

    Q_INVOKABLE void connectAsync(const QString &host, int port,
                                  const QString &username, const QString &password);

    Q_INVOKABLE void disconnect(); // async

    Q_INVOKABLE QString executeCommand(const QString &command);
    // Q_INVOKABLE bool uploadFile(const QString &localPath, const QString &remotePath);
    Q_INVOKABLE bool downloadFile(const QString &remotePath, const QString &localPath);
    Q_INVOKABLE QStringList listRemoteDirectory(const QString &remotePath);
    QString getLastError();

    Q_INVOKABLE void uploadFileAsync(const QString &localPath, const QString &remotePath);
    void uploadFilesAsync(const QStringList &localPaths, const QString &remoteDir);
signals:
    void connected();
    void connectionFailed(const QString &error);
    void disconnected();
    void connectionCancelled();

    void uploadProgress(const QString &file, qint64 fileSent, qint64 fileSize);
    void uploadFinished(const QString &file);
    void uploadFailed(const QString &file, const QString &reason);

    void uploadTotalProgress(qint64 bytesSent, qint64 totalBytes);
    void uploadTotalFinished();

private slots:
    void performDisconnect();

private:
    void runConnection(const QString &host, int port,
                       const QString &username, const QString &password);

    bool connectToHost(const std::string &host, int port,
                       const std::string &username, const std::string &password);
    bool initializeSocket(const std::string &host, int port);
    void cleanup();

    std::atomic_bool stopRequested{false};

#ifdef _WIN32
    SOCKET sock = INVALID_SOCKET;
#else
    int sock = -1;
#endif

    LIBSSH2_SESSION *session = nullptr;
    LIBSSH2_SFTP *sftp_session = nullptr;
    bool connectedFlag = false;

    QString lastError;
    std::thread connectThread;
};
