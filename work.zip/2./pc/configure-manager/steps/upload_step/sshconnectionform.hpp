#pragma once

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class SshConnectionForm; }
QT_END_NAMESPACE

class SshActions;

class SshConnectionForm : public QWidget
{
    Q_OBJECT

public:
    explicit SshConnectionForm(QWidget *parent = nullptr);
    ~SshConnectionForm();
    void downloadRemoteTargetConfigDb();
    void removeOldRemoveConfigFiles();
    void uploadNewConfigFiles(QStringList filesDirs);
    void setVisibleSshCredsLineEdits(bool visible);
    void setVisibleIp(bool visible);
    void setVisiblePort(bool visible);
    void setVisibleUsername(bool visible);
    void setVisiblePassword(bool visible);

    void setIp(QString ip);
    void setPort(uint port);
    void setUsername(QString username);
    void setPassword(QString password);
    void showEvent(QShowEvent* event);
signals:
    void connected();
    void disconnected();
    void uploaded();
    void uploadProgress(qint64 sent, qint64 total);
    void uploadFinished();
    void uploadFailed(const QString& file, const QString& reason);

private slots:
    void updateButtonText();
    void onConnectButtonClicked();
    void createDirs();
    void removeOldDownloadedConfig();
    void tryConnectOnShow();





private:
    Ui::SshConnectionForm *ui;
    enum ConnectionState { Disconnected, Connecting, Connected };
    ConnectionState connectionState = Disconnected;

    SshActions *ssh = nullptr;
    QThread *sshThread = nullptr;

    bool hostIsValid = false;
    bool portIsValid = false;

    bool passwordVisible = false;
    bool ignoreWarns = false;

    void updateFormEnabledState();
    void updateConnectButtonState();
};
