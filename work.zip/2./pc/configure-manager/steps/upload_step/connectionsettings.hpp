#ifndef CONNECTIONSETTINGS_HPP
#define CONNECTIONSETTINGS_HPP

#include <QObject>
#include <QSettings>
//DEPRECATED
class ConnectionSettings : public QObject
{
    Q_OBJECT
public:
    explicit ConnectionSettings(QObject *parent = nullptr);

    static ConnectionSettings& instance();

    QString ip();
    void setIp(QString ip);

    uint port();
    void setPort(uint port);

    QString username();
    void setUsername(QString username);

    QString password();
    void setPassword(QString password);

private:
    QSettings connectionSettings;
};

#endif // CONNECTIONSETTINGS_HPP
