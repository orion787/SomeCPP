#include "mocksshactions.hpp"

#include <QDebug>
#include <QFile>
#include <QFileInfo>
#include <QDir>
#include <QTimer>
#include <functional>

SshActions::SshActions(QObject *parent)
    : QObject(parent)
{
    root = QDir::tempPath() + "/mock_ssh_root";
    QDir().mkpath(root);
    qDebug() << "[MockSshActions] Initialized mock SSH root at:" << root;
}

SshActions::~SshActions() {}

void SshActions::connectAsync(const QString &, int, const QString &, const QString &)
{
    QTimer::singleShot(100, this, [this]() {
        connectedFlag = true;
        qDebug() << "[MockSshActions] Emitting connected";
        emit connected();
    });
}

void SshActions::disconnect()
{
    QTimer::singleShot(0, this, [this]() {
        connectedFlag = false;
        qDebug() << "[MockSshActions] Emitting disconnected";
        emit disconnected();
    });
}

QString SshActions::executeCommand(const QString &command)
{
    if (!connectedFlag)
        return "";

    qDebug() << "[MockSshActions] Executing command:" << command;

    if (command.startsWith("mkdir ")) {
        QString relPath = command.section(' ', 1);
        QDir().mkpath(root + "/" + relPath);
        return "OK\n";
    }

    if (command.startsWith("rm ")) {
        QString relPath = command.section(' ', 1);
        QString fullPath = root + "/" + relPath;
        QDir dir(fullPath);
        if (dir.exists()) {
            dir.removeRecursively();
            return "Directory removed\n";
        }
        QFile::remove(fullPath);
        return "File removed\n";
    }

    if (command.trimmed().startsWith("ls")) {
        QString dirPath = root;
        return QDir(dirPath).entryList(QDir::Files | QDir::Dirs | QDir::NoDotAndDotDot).join("\n");
    }

    return "Mock command executed: " + command + "\n";
}

bool SshActions::downloadFile(const QString &remotePath, const QString &localPath)
{
    if (!connectedFlag) return false;

    QString source = root + "/" + remotePath;
    QFile::remove(localPath);
    bool ok = QFile::copy(source, localPath);
    if (!ok) lastError = "Mock download failed";
    return ok;
}

QStringList SshActions::listRemoteDirectory(const QString &remotePath)
{
    if (!connectedFlag) return {};

    QDir dir(root + "/" + remotePath);
    if (!dir.exists()) {
        lastError = "Mock directory not found";
        return {};
    }

    return dir.entryList(QDir::Files | QDir::Dirs | QDir::NoDotAndDotDot);
}

void SshActions::uploadFileAsync(const QString &localPath, const QString &remotePath)
{
    if (!connectedFlag) return;

    QTimer::singleShot(0, this, [=]() {
        QFileInfo fi(localPath);
        if (!fi.exists()) {
            emit uploadFailed(localPath, "Mock: file does not exist");
            return;
        }

        QString dest = root + "/" + remotePath;
        QDir().mkpath(QFileInfo(dest).absolutePath());
        QFile::remove(dest);
        if (!QFile::copy(localPath, dest)) {
            emit uploadFailed(localPath, "Mock: copy failed");
            return;
        }

        emit uploadProgress(localPath, fi.size(), fi.size());
        emit uploadFinished(localPath);
    });
}

void SshActions::uploadFilesAsync(const QStringList &localPaths, const QString &remoteDir)
{
    if (!connectedFlag) {
        qDebug() << "[MockSshActions] Not connected, aborting upload";
        return;
    }

    qint64 total = 0;
    for (const QString &path : localPaths)
        total += QFileInfo(path).size();

    auto sent = std::make_shared<qint64>(0);
    auto fileIndex = std::make_shared<int>(0);

    auto uploadNext = std::make_shared<std::function<void()>>();

    *uploadNext = [=]() {
        if (*fileIndex >= localPaths.size()) {
            qDebug() << "[MockSshActions] All files uploaded.";
            emit uploadTotalFinished();
            return;
        }

        const QString localPath = localPaths[*fileIndex];
        const QFileInfo fi(localPath);
        const QString fileName = fi.fileName();
        const QString dest = root + "/" + remoteDir + "/" + fileName;

        qDebug() << "[MockSshActions] Preparing to upload:" << localPath << "->" << dest;

        if (!fi.exists()) {
            qDebug() << "[MockSshActions] File does not exist:" << localPath;
            emit uploadFailed(localPath, "Mock: file does not exist");
            (*fileIndex)++;
            QTimer::singleShot(0, this, *uploadNext);
            return;
        }

        QDir().mkpath(QFileInfo(dest).absolutePath());
        QFile::remove(dest);

        QFile *file = new QFile(localPath);
        QFile *out = new QFile(dest);

        if (!file->open(QIODevice::ReadOnly)) {
            emit uploadFailed(localPath, "Mock: cannot open file");
            delete file;
            delete out;
            (*fileIndex)++;
            QTimer::singleShot(0, this, *uploadNext);
            return;
        }

        if (!out->open(QIODevice::WriteOnly)) {
            emit uploadFailed(localPath, "Mock: cannot create remote file");
            delete file;
            delete out;
            (*fileIndex)++;
            QTimer::singleShot(0, this, *uploadNext);
            return;
        }

        const qint64 fileSize = fi.size();
        auto fileSent = std::make_shared<qint64>(0);
        const int chunkSize = 4096;

        auto sendChunk = std::make_shared<std::function<void()>>();
        *sendChunk = [=]() {
            if (!file->atEnd()) {
                QByteArray chunk = file->read(chunkSize);
                out->write(chunk);
                out->flush();

                *fileSent += chunk.size();
                *sent += chunk.size();

                emit uploadProgress(localPath, *fileSent, fileSize);
                emit uploadTotalProgress(*sent, total);

                QTimer::singleShot(0, this, *sendChunk);
            } else {
                out->close();
                file->close();

                emit uploadFinished(localPath);

                delete file;
                delete out;

                (*fileIndex)++;
                QTimer::singleShot(0, this, *uploadNext);
            }
        };

        qDebug() << "[MockSshActions] Starting chunked upload of" << localPath;
        (*sendChunk)();
    };

    QTimer::singleShot(0, this, *uploadNext);
}

QString SshActions::getLastError() const
{
    return lastError;
}
