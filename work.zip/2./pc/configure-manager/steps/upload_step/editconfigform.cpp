#include "editconfigform.hpp"
#include "ui_editconfigform.h"

#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlRecord>
#include <QTableWidgetItem>
#include <buttondelegate.hpp>
#include <dragdropsqlmodel.hpp>
#include <settings.hpp>
#include "sshactions.hpp"
#include "readonlydragdropsqlmodel.hpp"

EditConfigForm::EditConfigForm(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::EditConfigForm)
{
    ui->setupUi(this);
    ui->sourceTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Fixed);
    ui->targetTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Fixed);
}

void EditConfigForm::setMaxTargetRowCount(int max)
{
    ui->targetTable->setMaxRowCount(max);
    ui->modelsCountLabel->setText("(Up to "+QString::number(max)+" models)");
}


void EditConfigForm::showEvent(QShowEvent* event) {
    QWidget::showEvent(event);
    if (sourceModel) sourceModel->select();
    if (targetModel) targetModel->select();
}

EditConfigForm::~EditConfigForm()
{
    delete ui;
}

QSqlDatabase EditConfigForm::sourceDatabase() const {
    return sourceDb;
}

QSqlDatabase EditConfigForm::targetDatabase() const {
    return targetDb;
}

DragDropTableView* EditConfigForm::targetTable() const {
    return ui->targetTable;
}

QSqlTableModel* EditConfigForm::getTargetModel() const {
    return targetModel;
}

QString EditConfigForm::targetTableToJson() const {
    const auto* tableModel = this->targetModel;
    int rowCount = tableModel->rowCount();
    int columnCount = tableModel->columnCount();
    QJsonArray jsonRowsArray;

    QStringList headers;
    for (int col = 0; col < columnCount; ++col) {
        headers << tableModel->headerData(col, Qt::Horizontal).toString();
    }

    for (int row = 0; row < rowCount; ++row) {
        QJsonObject jsonRow;

        jsonRow["Sequence"] = row;

        for (int col = 0; col < columnCount; ++col) {
            QModelIndex index = tableModel->index(row, col);

            QVariant cellData = tableModel->data(index, Qt::DisplayRole);

            QString columnName = headers.at(col).isEmpty() ? QString("column_%1").arg(col) : headers.at(col);

            jsonRow[columnName] = QJsonValue::fromVariant(cellData);
        }

        jsonRowsArray.append(jsonRow);
    }

    QJsonDocument doc(jsonRowsArray);
    return doc.toJson(QJsonDocument::Indented);
}

void EditConfigForm::capitalizeHeaderLabels(QSqlTableModel* model) {
    if (!model) return;

    const QSqlRecord record = model->record();
    for (int i = 0; i < record.count(); ++i) {
        QString fieldName = record.fieldName(i);

        if (!fieldName.isEmpty()) {
            QString capitalized = fieldName.left(1).toUpper() + fieldName.mid(1);
            model->setHeaderData(i, Qt::Horizontal, capitalized);
        }
    }
}

void EditConfigForm::setSourceDatabaseTable(const QSqlDatabase& db, QString table_name) {
    sourceDb = db;
    sourceTableName = table_name;
    setupModels();
}

void EditConfigForm::setTargetDatabaseTable(const QSqlDatabase& db, QString table_name) {
    targetDb = db;
    targetTableName = table_name;
    setupModels();
}

void EditConfigForm::setupModels() {
    if (sourceModel) {
        delete sourceModel;
        sourceModel = nullptr;
    }

    if (targetModel) {
        delete targetModel;
        targetModel = nullptr;
    }

    // --- SOURCE MODEL ---
    if (sourceDb.isValid() && sourceDb.isOpen()) {
        sourceModel = new ReadOnlyDragDropSqlModel(this, sourceDb);
        sourceModel->setTable(sourceTableName);
        sourceModel->select();
        capitalizeHeaderLabels(sourceModel);
        ui->sourceTable->setModel(sourceModel);
    } else {
        ui->sourceTable->setModel(nullptr);
    }

    // --- TARGET MODEL ---
    if (targetDb.isValid() && targetDb.isOpen()) {
        targetModel = new DragDropSqlModel(this, targetDb);
        targetModel->setTable(targetTableName);
        targetModel->setEditStrategy(QSqlTableModel::OnFieldChange);
        targetModel->select();
        capitalizeHeaderLabels(targetModel);
        ui->targetTable->setModel(targetModel);

        int columnCount = targetModel->columnCount();
        if (columnCount > 0) {
            int buttonColumn = columnCount - 1;

            auto* deleteButtonDelegate = new ButtonDelegate(this);
            deleteButtonDelegate->setButtons({ ButtonSpec("🗑️", QIcon(), "Remove"), });

            ui->targetTable->setItemDelegateForColumn(buttonColumn, deleteButtonDelegate);

            connect(deleteButtonDelegate, &ButtonDelegate::buttonClicked, this, [=](const QModelIndex& index, int) {
                if (!index.isValid()) return;

                if (QMessageBox::question(this, "Remove", "Remove item ?") == QMessageBox::Yes) {

                    QModelIndex indexRow = targetModel->index(index.row(), 2);
                    QString filename = targetModel->data(indexRow).toString();
                    QFile::remove(Settings::instance().deviceAudioDirPath() + "/" + filename);

                    targetModel->removeRow(index.row());
                    targetModel->submitAll();
                    targetModel->select();

                    emit(removeTargetRow(targetModel));
                }
            });
        }
    } else {
        ui->targetTable->setModel(nullptr);
    }

    ui->targetTable->setEditTriggers(QAbstractItemView::NoEditTriggers);

    hideColumns();

    for (QTableView* table : { ui->sourceTable, ui->targetTable }) {
        table->setSelectionBehavior(QAbstractItemView::SelectRows);
        table->setDragEnabled(true);
        table->setAcceptDrops(true);
        table->setDropIndicatorShown(true);
        table->setDragDropOverwriteMode(false);
        table->setDragDropMode(QAbstractItemView::DragDrop);
        table->horizontalHeader()->setStretchLastSection(true);
        table->setDefaultDropAction(Qt::CopyAction);
    }

    // For internal rotation on the target table
    // ui->targetTable->setDragDropMode(QAbstractItemView::InternalMove);
    ui->targetTable->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->targetTable->setDragDropOverwriteMode(false);

    connect(ui->sourceTable, &QTableView::pressed, this, [this](const QModelIndex& index) {
        if (index.isValid())
            draggedRecord = sourceModel->record(index.row());
    });

    auto* target = qobject_cast<DragDropTableView*>(ui->targetTable);
    connect(target, &DragDropTableView::droppedRecord, this, [this](const QSqlRecord&, DragDropTableView*) {
        targetModel->submitAll();
        targetModel->select();
    });
}

void EditConfigForm::hideColumns()
{
    for (QString column_name: hidden_columns) {
        int column_i = sourceModel->fieldIndex(column_name);
        ui->sourceTable->setColumnHidden(column_i, true);
        ui->targetTable->setColumnHidden(column_i, true);
    }
}

QList<QVariant> EditConfigForm::allTargetFieldValues(const QString& fieldName) const
{
    QList<QVariant> values;

    if (!targetModel) return values;

    int column = targetModel->fieldIndex(fieldName);
    if (column == -1) {
        qWarning() << "Field not found in model:" << fieldName;
        return values;
    }

    for (int row = 0; row < targetModel->rowCount(); ++row) {
        QModelIndex index = targetModel->index(row, column);
        if (index.isValid()) {
            values << targetModel->data(index);
        }
    }

    return values;
}
