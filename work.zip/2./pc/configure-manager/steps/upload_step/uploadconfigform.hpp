#ifndef UPLOADCONFIGFORM_HPP
#define UPLOADCONFIGFORM_HPP

#include <QWidget>
#include "http_service.hpp"

struct DoOnce {
    void operator()(std::function<void()> first, std::function<void(const QString&)> second, const QString& argForSecond) {
        if(!perform) {
            if(first) first();
            if(second) second(argForSecond);
            perform = true;
        }
    }

    void reset() {
        perform = false;
    }

private:
    bool perform = false;
};

namespace Ui {
class UploadConfigForm;
}

class UploadConfigForm : public QWidget
{
    Q_OBJECT

public:
    explicit UploadConfigForm(QWidget *parent = nullptr);
    ~UploadConfigForm();
    void setupDatabases();
protected:
    void setWidgetsEnabled(bool connected);
private:
    Ui::UploadConfigForm *ui;

    void viewDisable();
    void viewEnable();
    void viewStart();
    void viewAddingTargets();
    void viewUpload();

    template<typename T>
    void setViewState(T* t);

    void applyUploadpReady(HttpClient::RequestType reguestType, QString urlPath, int statusCode, const QByteArray &data);
    void applyUploadpError(HttpClient::RequestType reguestType, QString urlPath, QNetworkReply::NetworkError error);

    HttpClient voiceClient;
    HttpClient stateUploadClient;

    int targetRow = 0;
    const int targetCol = 2;
    void sendFile(const int targetRow);
    void receiveFile(const int targetRow);
    QTimer *timerUploadReady = nullptr;
    void checkUploadReady();

    DoOnce doOnce;

signals:
    void readySendFile();
    void readyReceiveFile();
};



#endif // UPLOADCONFIGFORM_HPP
