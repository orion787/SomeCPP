#include "connectionsettings.hpp"
//DEPRECATED
ConnectionSettings::ConnectionSettings(QObject *parent)
    : QObject{parent}, connectionSettings("config-manager", "config-manager")
{}

ConnectionSettings &ConnectionSettings::instance()
{
    static ConnectionSettings inst;
    return inst;
}

QString ConnectionSettings::ip() {
    return connectionSettings.value("ip", "").toString();
}

void ConnectionSettings::setIp(QString ip) {
    connectionSettings.setValue("ip", ip);
    connectionSettings.sync();
}

uint ConnectionSettings::port()
{
    return connectionSettings.value("port", 22).toUInt();
}

void ConnectionSettings::setPort(uint port)
{
    connectionSettings.setValue("port", port);
    connectionSettings.sync();
}

QString ConnectionSettings::username()
{
    return connectionSettings.value("username", "").toString();
}

void ConnectionSettings::setUsername(QString username)
{
    connectionSettings.setValue("username", username);
    connectionSettings.sync();
}

QString ConnectionSettings::password() {
    if (connectionSettings.value("password").isNull()) {
        return "";
    }
    QByteArray enc = connectionSettings.value("password").toByteArray();
    QByteArray key = "my_secret_key";
    for (int i = 0; i < enc.size(); ++i)
        enc[i] ^= key[i % key.size()];
    return QString::fromUtf8(enc);
}

void ConnectionSettings::setPassword(QString password) {
    QByteArray data = password.toUtf8();
    QByteArray key = "my_secret_key";
    for (int i = 0; i < data.size(); ++i)
        data[i] ^= key[i % key.size()];
    connectionSettings.setValue("password", data);
    connectionSettings.sync();
}
