#ifndef EDITCONFIGFORM_H
#define EDITCONFIGFORM_H

#include <QSqlDatabase>
#include <QSqlRecord>
#include <QSqlTableModel>
#include <QWidget>
#include <models_repo.hpp>
#include "dragdroptableview.hpp"

namespace Ui {
class EditConfigForm;
}

class EditConfigForm : public QWidget
{
    Q_OBJECT

public:
    explicit EditConfigForm(QWidget *parent = nullptr);
    ~EditConfigForm();

    void setSourceDatabaseTable(const QSqlDatabase& db, QString table_name);
    void setTargetDatabaseTable(const QSqlDatabase& db, QString table_name);

    QSqlDatabase sourceDatabase() const;
    QSqlDatabase targetDatabase() const;

    DragDropTableView* targetTable() const;
    QSqlTableModel* getTargetModel() const;

    QString targetTableToJson() const;

    void showEvent(QShowEvent *event);
    QList<QVariant> allTargetFieldValues(const QString &fieldName) const;
    void setMaxTargetRowCount(int max);

signals:
    void removeTargetRow(QSqlTableModel* model);


protected:
    void capitalizeHeaderLabels(QSqlTableModel *model);
private:
    Ui::EditConfigForm *ui;

    uint maxTargetRowCount = 0;
    ModelsRepo* models_repo;

    QStringList hidden_columns = {"id", "file_path"};

    QSqlDatabase sourceDb;
    QSqlDatabase targetDb;

    QString sourceTableName;
    QString targetTableName;

    QSqlRecord draggedRecord;

    QSqlTableModel* sourceModel = nullptr;
    QSqlTableModel* targetModel = nullptr;

    void setupModels();
    void hideColumns();
};

#endif // EDITCONFIGFORM_H
