#ifndef UTILS_H
#define UTILS_H

#include <QByteArray>
#include <QJsonObject>
#include <QJsonParseError>
#include <QDir>
#include <QFileInfo>
#include <QStringList>
#include <QDebug>

bool parseJsonToObj(const QByteArray &rawJson, QJsonObject &outObj);
void removeWavFiles(const QString &dirPath);

#endif // UTILS_H
