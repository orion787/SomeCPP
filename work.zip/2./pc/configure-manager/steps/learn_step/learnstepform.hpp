#ifndef LEARNSTEPFORM_HPP
#define LEARNSTEPFORM_HPP

#include "learnprocesscontroller.hpp"

#include <QWidget>

namespace Ui {
class LearnStepForm;
}

class LearnStepForm : public QWidget
{
    Q_OBJECT

public:
    explicit LearnStepForm(QWidget *parent = nullptr);
    ~LearnStepForm();

    void setupConnections();
    bool voicesIsSelected();
    bool modelNameIsUnique(QString name);
    void showEvent(QShowEvent* event);
    void updateLists();
    void clearForm();
    void setEnabledForm(bool enabled);

protected:
    void checkReadyState();
private:
    Ui::LearnStepForm *ui;
    LearnProcessController learnProcessController;
};

#endif // LEARNSTEPFORM_HPP
