#include "headsetform.h"
#include "ui_headsetform.h"
#include <QThread>
#include <QJsonDocument>


static const QString SCAN_ON = "Scan on";
static const QString SCAN_OFF = "Scan off";

HeadsetForm::HeadsetForm(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::HeadsetForm)
    , headsetsList(parent)
    , hc(parent)
{
    ui->setupUi(this);

    this->setDisabled(true);

    connectorThread = new QThread(this);
    connectorActions = new HeadsetConnector(parent);
    connectorActions->moveToThread(connectorThread);
    connectorThread->start();

    connect(connectorActions, &HeadsetConnector::setupReady, this, &HeadsetForm::applySetupReady);

    connect(connectorActions, &HeadsetConnector::newSetupData, &headsetsList, &HeadsetsList::handleHeadsets);
    connect(connectorActions, &HeadsetConnector::newSetupData, this, &HeadsetForm::handleSaveState);
    connect(connectorActions, &HeadsetConnector::newSetupData, this, &HeadsetForm::handleScanState);
    connect(connectorActions, &HeadsetConnector::newSetupData, this, &HeadsetForm::handleCurrentHeadset);

    connect(ui->tableWidget, &QTableWidget:: itemSelectionChanged, this, &HeadsetForm::onRowSelected);
    connect(ui->tableWidget, &QTableWidget::cellPressed, this, &HeadsetForm::onCellActivated);
    connect(ui->saveButton, &QPushButton::clicked, this, &HeadsetForm::onClickSaveButton);
    connect(ui->scanButton, &QPushButton::clicked, this, &HeadsetForm::onClickScanButton);

    headsetsList.init(ui->tableWidget);

    ui->saveButton->setEnabled(false);
}

HeadsetForm::~HeadsetForm()
{
    delete ui;

    if (connectorThread->isRunning()) {
        connectorThread->quit();
        connectorThread->deleteLater();
    }
}

void HeadsetForm::applySetupReady(const bool result) {
    this->setDisabled(!result);
}

QString HeadsetForm::statusSaveMsg(const QString& text) {
    return currentAlias + ": " + text;
}

void HeadsetForm::handleSaveState(const QJsonObject setupData) {
    QJsonValue saveState = setupData["save_state"];

    if(saveState == "nothing") {
        return;
    }else if(saveState == "pairing"
               || saveState == "connecting"
               || saveState == "trusting") {
        ui->statusSave->setText(statusSaveMsg(saveState.toString()));
        ui->saveButton->setEnabled(false);
        return;
    } else if(saveState == "success"){
        ui->statusSave->setText(statusSaveMsg(saveState.toString()));
        ui->tableWidget->clearContents();
        ui->tableWidget->setRowCount(0);

        ui->tableWidget->setEnabled(true);
        ui->saveButton->setEnabled(false);
        hc.get("/scan_off");
        // ui->scanButton->setText(SCAN_ON);
        // ui->scanButton->setEnabled(true);
    }else {
        return;
    }
}

void HeadsetForm::handleScanState(const QJsonObject setupData) {
    QJsonValue scanState = setupData["scan_state"];

    if(scanState == "nothing") {
        return;
    }else if(scanState == "scanning") {
        ui->scanButton->setEnabled(true);
        ui->scanButton->setText(SCAN_OFF);
        return;
    } else if(scanState == "success"){
        // hc.get("/scan_off");
        ui->saveButton->setEnabled(false);
        ui->scanButton->setText(SCAN_ON);
        ui->scanButton->setEnabled(true);
        ui->tableWidget->clearContents();
        ui->tableWidget->setRowCount(0);
    }else {
        return;
    }
}

void HeadsetForm::handleCurrentHeadset(const QJsonObject setupData) {
    ui->currentHeadset->setText("Current headset: " + setupData["current_headset"].toString());
}

void HeadsetForm::onRowSelected() {
    currentRow = ui->tableWidget->currentRow();

    if(currentRow < 0) return;

    currentAlias = ui->tableWidget->item(currentRow, 1)->text();
}

void HeadsetForm::onCellActivated(int row, int column) {
    ui->saveButton->setEnabled(true);
}

void HeadsetForm::onClickSaveButton(bool checked) {
    ui->tableWidget->setEnabled(false);

    ui->saveButton->setEnabled(false);

    ui->scanButton->setText(SCAN_ON);
    ui->scanButton->setEnabled(false);

    QJsonObject jsonObj;
    jsonObj["addr"] = ui->tableWidget->item(currentRow, 0)->text();
    jsonObj["alias"] = ui->tableWidget->item(currentRow, 1)->text();
    jsonObj["object"] = ui->tableWidget->item(currentRow, 2)->text();

    QJsonDocument jsonDoc(jsonObj);
    QByteArray request = jsonDoc.toJson(QJsonDocument::Compact);

    hc.post("/save", request);
}

void HeadsetForm::onClickScanButton(bool checked) {
    if(ui->scanButton->text() == SCAN_ON) {
        ui->scanButton->setText(SCAN_OFF);
        ui->scanButton->setEnabled(false);
        ui->statusSave->clear();

        hc.get("/scan_on");
        return;
    }

    if(ui->scanButton->text() == SCAN_OFF) {
        ui->scanButton->setText(SCAN_ON);
        ui->scanButton->setEnabled(false);
        ui->saveButton->setEnabled(false);

        hc.get("/scan_off");
        return;
    }
}