#include "headsetformconnector.h"
#include <QTimer>
#include <QJsonDocument>
#include <QJsonArray>
#include "utils.h"

inline constexpr const char* URL_PATH_SETUP_READY = "/setup";

HeadsetConnector::HeadsetConnector(QObject *parent) : hcSetupReady(parent), QObject(parent) {
    QObject::connect(&hcSetupReady, &HttpClient::replyReady, this, [this](HttpClient::RequestType reguestType, QString urlPath, int statusCode, const QByteArray &data){
        if(!parseJsonToObj(data, setupData)) {
            emit hasError("Received broken data.");
        }

        if(setupData["setup_ready"] == "setup_ready") {
            emit setupReady(true);
        }else if(setupData["setup_ready"] == "setup_not_ready") {
            emit setupReady(false);
        }

        emit newSetupData(setupData);
        waitSetupReady.store(false);
    });

    QObject::connect(&hcSetupReady, &HttpClient::replyError, this, [this](HttpClient::RequestType reguestType, QString urlPath, QNetworkReply::NetworkError error){
        emit setupReady(false);
        waitSetupReady.store(false);
    });

    timerSetupReady = new QTimer(this);
    QObject::connect(timerSetupReady, &QTimer::timeout, this, &HeadsetConnector::checkSetupReady);
    timerSetupReady->start(1000);
}

void HeadsetConnector::checkSetupReady() {
    if(!waitSetupReady.load()) {
        hcSetupReady.get(URL_PATH_SETUP_READY);
        waitSetupReady.store(true);
    }
}

// void HeadsetConnector::testNewSetupData() {

//     QJsonDocument doc = QJsonDocument::fromJson(dataTest);
//     QJsonObject root = doc.object();

//     emit newSetupData(root);
// }