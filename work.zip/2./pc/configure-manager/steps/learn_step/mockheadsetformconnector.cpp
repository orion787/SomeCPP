#include "mockheadsetformconnector.h"
#include <QTimer>
#include <QJsonDocument>
#include <QJsonArray>
#include <mutex>
#include "utils.h"


HttpRequest httpRequest;

std::mutex mtx;

inline constexpr const char* URL_PATH_SETUP_READY = "/setup";

QByteArray dataTest = R"(
    {   "save_state": "nothing",
        "scan_state": "nothing",
        "current_headset": "",
        "headsets_list":
        [
        ]
    }
)";

HeadsetConnector::HeadsetConnector(QObject *parent) : QObject(parent) {
    parseJsonToObj(dataTest, setupData);

    timerSetupReady = new QTimer(this);
    QObject::connect(timerSetupReady, &QTimer::timeout, this, &HeadsetConnector::updateSetup);
    timerSetupReady->start(3000);
}

void HeadsetConnector::updateSetup() {
    if (!enableOnceSetupNotReadyState && setupReadyState) {
        emit setupReady(setupReadyState);
        setupReadyState = false;
    } else if (!enableOnceSetupNotReadyState && !setupReadyState) {
        enableOnceSetupNotReadyState = true;
        emit setupReady(setupReadyState);
        setupReadyState = true;
    } else if(enableOnceSetupNotReadyState && setupReadyState) {
        emit setupReady(setupReadyState);
    }

    requestHandler(httpRequest);
}

void HeadsetConnector::requestHandler(HttpRequest& httpRequest) {
    {
        std::scoped_lock lock(mtx);
        if(httpRequest.url == "/save") {
            saveOn = true;
            saveStates.clean();
            currentHeadset = QJsonDocument::fromJson(httpRequest.body.toUtf8()).object()["alias"].toString() ;
            httpRequest.clean();
        }

        if(httpRequest.url == "/scan_on") {
            scanOn = true;
            scanOff = false;
            scanStates.clean();
            httpRequest.clean();
        }

        if(httpRequest.url == "/scan_off") {
            scanOff = true;
            scanOn = false;
            httpRequest.clean();
        }
    }

    scanStates.changeState(setupData, scanOn, scanOff);

    if(saveOn) {
        saveStates.changeState(setupData, currentHeadset);
    }

    emit newSetupData(setupData);
}

MockHttpClient::MockHttpClient(QObject *parent) : QObject(parent) {}

void MockHttpClient::get(const QString &urlPath) {
    std::scoped_lock lock(mtx);
    httpRequest.method = "get";
    httpRequest.url = urlPath;
    httpRequest.body = "";
}

void MockHttpClient::post(const QString &urlPath, const QByteArray &body) {
    std::scoped_lock lock(mtx);
    httpRequest.method = "post";
    httpRequest.url = urlPath;
    httpRequest.body = body;
}