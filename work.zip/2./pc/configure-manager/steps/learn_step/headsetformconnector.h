#ifndef HEADSETCONNECTOR_H
#define HEADSETCONNECTOR_H

#include "http_service.hpp"
#include <QObject>
#include <QUrl>
#include <QTimer>
#include <QThread>
#include <QJsonObject>


class HeadsetConnector : public QObject {
    Q_OBJECT
public:
    explicit HeadsetConnector(QObject *parent = nullptr);
    // void testNewSetupData();

    // Q_INVOKABLE void connect();
    // Q_INVOKABLE void disconnect();

private:
    HttpClient hcSetupReady;
    std::atomic<bool> waitSetupReady { false };
    QTimer *timerSetupReady = nullptr;
    QJsonObject setupData;

    void checkSetupReady();

signals:
    void setupReady(const bool result);
    void newSetupData(QJsonObject setupData);
    void hasError(QString setupData);
};

#endif // HEADSETCONNECTOR_H
