#ifndef HEADSETSLIST_H
#define HEADSETSLIST_H

#include <QObject>
#include <QTableWidget>

class HeadsetsList : public QObject
{
    Q_OBJECT
public:
    explicit HeadsetsList(QObject *parent = nullptr);
    void handleHeadsets(const QJsonObject setupData);
    void init(QTableWidget* headsetsTable);

private:
    QTableWidget* headsetsTable;

    void addItemToTable(const QString &addr, const QString &alias, const QString &object);
    int findRowByKey(const QString &addr) const;
    void deleteItemFromTable(const QString &addr);
};

#endif  // HEADSETSLIST_H
