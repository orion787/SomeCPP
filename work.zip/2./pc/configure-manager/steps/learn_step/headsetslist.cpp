#include "headsetslist.h"

#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonParseError>
#include <QDebug>
#include <QJsonValue>
#include <QJsonArray>

HeadsetsList::HeadsetsList(QObject *parent)
    : QObject{parent}
{
}

void HeadsetsList::init(QTableWidget* headsetsTable) {
    this->headsetsTable = headsetsTable;
    headsetsTable->setColumnCount(3);
    headsetsTable->setHorizontalHeaderLabels({"Addr", "Name", "Object"});
}

void HeadsetsList::addItemToTable(const QString &addr, const QString &alias, const QString &object)
{
    int row = headsetsTable->rowCount();
    headsetsTable->insertRow(row);

    auto *addrItem   = new QTableWidgetItem(addr);
    auto *aliasItem  = new QTableWidgetItem(alias);
    auto *objectItem = new QTableWidgetItem(object);

    addrItem->setFlags(addrItem->flags() & ~Qt::ItemIsEditable);   // make key non-editable
    aliasItem->setFlags(aliasItem->flags() & ~Qt::ItemIsEditable);
    objectItem->setFlags(objectItem->flags() & ~Qt::ItemIsEditable);

    headsetsTable->setItem(row, 0, addrItem);
    headsetsTable->setItem(row, 1, aliasItem);
    headsetsTable->setItem(row, 2, objectItem);
}

int HeadsetsList::findRowByKey(const QString &addr) const
{
    for (int row = 0; row < headsetsTable->rowCount(); ++row) {
        QTableWidgetItem *item = headsetsTable->item(row, 2); // column 2 = object
        if (item && item->text() == addr)
            return row;
    }
    return -1;
}

void HeadsetsList::deleteItemFromTable(const QString &object)
{
    int row = findRowByKey(object);
    if (row != -1)
        headsetsTable->removeRow(row);

    headsetsTable->setCurrentCell(0, 0);
}

void HeadsetsList::handleHeadsets(const QJsonObject setupData) {
    QJsonArray headsets = setupData["headsets_list"].toArray();

    if(headsets.isEmpty()) return;

    for (const QJsonValue &value : headsets) {
        if (!value.isObject())
            continue;

        QJsonObject obj = value.toObject();
        QString action = obj.value("action").toString();
        QString addr = obj.value("addr").toString();
        QString alias = obj.value("alias").toString();
        QString object = obj.value("object").toString();

        if (action == "add") {
            addItemToTable(addr, alias, object);
        } else if (action == "delete") {
            deleteItemFromTable(object);
        }
    }
}


