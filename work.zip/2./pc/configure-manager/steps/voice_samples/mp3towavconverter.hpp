#ifndef MP3TOWAVCONVERTER_HPP
#define MP3TOWAVCONVERTER_HPP

#include <QString>

class Mp3ToWavConverter {
public:
    static bool convert(const QString& inputFile,
                                    const QString& outputFile,
                                    uint32_t targetSampleRate,
                                           uint32_t targetChannels);
    static int getMp3BitrateKbps(const QString &filePath);
    static double getMp3DurationSeconds(const QString &filePath);
};

#endif // MP3TOWAVCONVERTER_HPP
