#include "DeleteButtonDelegate.hpp"
#include <QPainter>
#include <QMouseEvent>
#include <QApplication>
#include <QStyle>

DeleteButtonDelegate::DeleteButtonDelegate(QObject *parent)
    : QStyledItemDelegate(parent)
{}

void DeleteButtonDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option,
                                 const QModelIndex &index) const
{
    QStyleOptionViewItem textOption(option);
    initStyleOption(&textOption, index);

    // Calculate space for button (e.g., 24x24px at right)
    QRect buttonRect = option.rect.adjusted(option.rect.width() - 28, 4, -4, -4);

    // Adjust text rect to leave space for button
    QRect textRect = option.rect.adjusted(4, 0, -32, 0);
    textOption.rect = textRect;

    // Draw text
    QStyledItemDelegate::paint(painter, textOption, index);

    // Draw delete button
    QStyleOptionButton button;
    button.rect = buttonRect;
    button.text = "✖"; // or use QIcon
    button.state = QStyle::State_Enabled;

    QApplication::style()->drawControl(QStyle::CE_PushButton, &button, painter);
}

bool DeleteButtonDelegate::editorEvent(QEvent *event, QAbstractItemModel *model,
                                       const QStyleOptionViewItem &option, const QModelIndex &index)
{
    if (event->type() == QEvent::MouseButtonRelease) {
        auto mouseEvent = static_cast<QMouseEvent*>(event);
        if (option.rect.contains(mouseEvent->pos())) {
            emit deleteRequested(index);
            return true;
        }
    }
    return false;
}
