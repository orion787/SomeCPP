#include "clickableslider.hpp"
#include <QMouseEvent>
#include <QStyle>
#include <QStyleOptionSlider>

void ClickableSlider::mousePressEvent(QMouseEvent *event)
{
    if (orientation() == Qt::Horizontal) {
        QStyleOptionSlider opt;
        initStyleOption(&opt);

        QRect sliderRect = style()->subControlRect(QStyle::CC_Slider, &opt, QStyle::SC_SliderHandle, this);
        int sliderMin = style()->pixelMetric(QStyle::PM_SliderLength, &opt, this) / 2;
        int sliderMax = width() - sliderMin;

        int newVal = QStyle::sliderValueFromPosition(minimum(), maximum(), event->position().x(), width());
        setValue(newVal);

        emit sliderMoved(newVal);
        emit sliderReleased();
    }

    QSlider::mousePressEvent(event);
}
