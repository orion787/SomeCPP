#ifndef CLICKABLESLIDER_HPP
#define CLICKABLESLIDER_HPP

#include <QSlider>

class ClickableSlider : public QSlider
{
    Q_OBJECT

public:
    using QSlider::QSlider;

protected:
    void mousePressEvent(QMouseEvent *event) override;
};

#endif // CLICKABLESLIDER_HPP
