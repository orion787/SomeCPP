#pragma once

#include <QWidget>
#include <QFile>
#include <QTimer>
#include <QElapsedTimer>
#include <QVector>
#include <portaudio.h>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class AudioRecorderForm;
}
QT_END_NAMESPACE

class AudioRecorderForm : public QWidget {
    Q_OBJECT

public:
    explicit AudioRecorderForm(QWidget* parent = nullptr);
    ~AudioRecorderForm();

    void setOutputDirectory(const QString& dir);
    QString getOutputDirectory() const;

    void setSelectDirVisible(bool enabled);
    bool selectDirVisible();

    void setSampleRate(uint rate);
    uint sampleRate();

    void setNumChannels(uint numChannels);
    uint numChannels();

private slots:
    void onStartClicked();
    void onStopClicked();
    void onSelectDirClicked();
    void updatePlot();

signals:
    void recordingStop();
    void recordingStart();
    void recordedAudioSaved(QString relative_audio_path);

protected:
    void updateDurationLabel();
private:
    Ui::AudioRecorderForm* ui;

    QElapsedTimer recordingTime;
    QTimer timeUpdateTimer;

    PaStream* stream = nullptr;
    QFile wavFile;
    QString outputDirectory;
    bool isRecording = false;

    QTimer plotTimer;
    QVector<double> audioBuffer;

    uint m_sampleRate = 48000;
    static constexpr uint framesPerBuffer = 512;
    uint m_numChannels = 1;
    static constexpr PaSampleFormat sampleFormat = paInt16;

    void writeWavHeader();
    void finalizeWavHeader();
    static int recordCallback(const void* input, void*, unsigned long frameCount,
                              const PaStreamCallbackTimeInfo*, PaStreamCallbackFlags, void* userData);
};
