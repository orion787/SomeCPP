#ifndef MAINFORM_HPP
#define MAINFORM_HPP

#include <QWidget>

#include <QWidget>
#include <QSqlTableModel>
#include <QSortFilterProxyModel>

namespace Ui {
    class MainForm;
}

class MainForm : public QWidget
{
    Q_OBJECT

public:
    explicit MainForm(QWidget *parent = nullptr);
    ~MainForm();
    void showEvent(QShowEvent* event) override;

private:
    void setupModel();
    void replaceTitlesFromSnakeCase();
    void setupTableView();
    void setupConnections();
    void handleDeleteClicked(const QModelIndex &proxyIndex);
    Ui::MainForm *ui;
    QSqlTableModel *sqlModel;
    QSortFilterProxyModel *proxyModel;

};

#endif // MAINFORM_HPP
