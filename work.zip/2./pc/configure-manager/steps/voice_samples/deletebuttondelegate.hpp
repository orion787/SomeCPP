#ifndef DELETEBUTTONDELEGATE_HPP
#define DELETEBUTTONDELEGATE_HPP

#include <QStyledItemDelegate>
#include <QObject>

class DeleteButtonDelegate : public QStyledItemDelegate {
    Q_OBJECT
public:
    explicit DeleteButtonDelegate(QObject *parent = nullptr);

    void paint(QPainter *painter, const QStyleOptionViewItem &option,
               const QModelIndex &index) const override;

    bool editorEvent(QEvent *event, QAbstractItemModel *model,
                     const QStyleOptionViewItem &option, const QModelIndex &index) override;

signals:
    void deleteRequested(const QModelIndex &sourceIndex) const;
};

#endif // DELETEBUTTONDELEGATE_HPP
