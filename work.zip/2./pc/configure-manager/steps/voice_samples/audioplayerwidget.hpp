#ifndef AUDIOPLAYERWIDGET_HPP
#define AUDIOPLAYERWIDGET_HPP

#include <QWidget>
#include <QMediaPlayer>
#include <QAudioOutput>

class QPushButton;
class QSlider;
class QLabel;

class AudioPlayerWidget : public QWidget
{
    Q_OBJECT

public:
    explicit AudioPlayerWidget(QWidget *parent = nullptr);

    void setAudio(const QString &filePath, const QString &title);

signals:
    void requestPrevious();
    void requestNext();
    void autoRequestNext();

public slots:
    void play();
    void stop();
    void setPrevEnabled(bool enabled);
    void setNextEnabled(bool enabled);

private slots:

    void togglePlayback();
    void updatePosition(qint64 pos);
    void setPosition(int sliderValue);
    void updateDuration(qint64 dur);
    void handleMediaStatusChanged(QMediaPlayer::MediaStatus status);

private:
    QMediaPlayer *player;
    QAudioOutput *audioOutput;

    QPushButton *playButton;
    QPushButton *prevButton;
    QPushButton *nextButton;
    QLabel *currentTimeLabel;
    QLabel *totalTimeLabel;

    QSlider *positionSlider;
    QLabel *titleLabel;

    bool userIsSeeking = false;
};

#endif // AUDIOPLAYERWIDGET_HPP
