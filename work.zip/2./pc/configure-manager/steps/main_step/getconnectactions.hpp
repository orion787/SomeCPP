#ifndef GETCONNECTACTIONS_H
#define GETCONNECTACTIONS_H

#include "http_service.hpp"
#include <QObject>
#include <QUrl>
#include <QTimer>
#include <QThread>

class GetConnectActions : public QObject {
    Q_OBJECT
public:
    explicit GetConnectActions(QObject *parent = nullptr);

    Q_INVOKABLE void connect();
    Q_INVOKABLE void disconnect();

private:
    HttpClient httpClient;
    bool hasConnect = false;
    QTimer *timer = nullptr;

    void checkConnection();

signals:
    void connecting();
    void connectingFailed(const QString &reason);
    void connected();
    // void connectionFailed(const QString &reason);
    void disconnected();
};

#endif // GETCONNECTACTIONS_H
