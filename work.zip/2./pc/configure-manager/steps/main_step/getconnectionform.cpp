#include "getconnectionform.hpp"
#include "ui_getconnectionform.h"

#include <QFileInfo>
#include <QMessageBox>
// #include <QRegularExpressionValidator>
#include <QStyle>
#include <QThread>
#include <QTimer>
// #include <settings.hpp>


GetConnectionForm::GetConnectionForm(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::GetConnectionForm)
{
    ui->setupUi(this);

    getConnectThread = new QThread(this);
    getConnectActions = new GetConnectActions(parent);
    getConnectActions->moveToThread(getConnectThread);
    getConnectThread->start();


    connect(ui->connectButton, &QPushButton::clicked,
            this, &GetConnectionForm::onConnectButtonClicked);

    connect(getConnectActions, &GetConnectActions::connecting, this, [this]() {
        connectionState = Connecting;
        updateButtonText();
        emit connecting();
    });

    connect(getConnectActions, &GetConnectActions::connected, this, [this]() {
        connectionState = Connected;
        updateButtonText();
        emit connected();
    });

    connect(getConnectActions, &GetConnectActions::disconnected, this, [this]() {
        connectionState = Disconnected;
        updateButtonText();
        emit disconnected();
    });

    connect(getConnectActions, &GetConnectActions::connectingFailed, this, [this](const QString &reason) {
        qDebug() << "[GetConnectionForm] connectionFailed received:" << reason;
        connectionState = Disconnected;
        updateButtonText();
   });

    connect(this, &QObject::destroyed, getConnectActions, &GetConnectActions::deleteLater);
    connect(getConnectThread, &QThread::finished, getConnectThread, &QThread::deleteLater);

    updateButtonText();
}

void GetConnectionForm::updateConnectButtonState()
{
    ui->connectButton->setEnabled(hostIsValid && portIsValid && connectionState == Disconnected);
}

GetConnectionForm::~GetConnectionForm()
{
    if (getConnectThread) {
        QMetaObject::invokeMethod(getConnectActions, "disconnect", Qt::QueuedConnection);

        getConnectThread->quit();
        getConnectThread->wait();

        getConnectThread->deleteLater();
    }

    delete ui;
}

void GetConnectionForm::onConnectButtonClicked()
{
    switch (connectionState) {
    case Disconnected:
        connectionState = Connecting;
        getConnectActions->connect();
        updateButtonText();
        break;
    /*case Connecting:
        connectionState = Disconnected;
        updateButtonText();
        getConnectActions->disconnect();
        break*/;
    case Connected:
        getConnectActions->disconnect();
        break;
    }
}

/* This block commented for exclude undefined behaviour when moving to Main tab, when device already connected
void GetConnectionForm::tryConnectOnShow()
{
    ui->connectButton->click();
}


void GetConnectionForm::showEvent(QShowEvent *event)
{
        tryConnectOnShow();
}
*/

void GetConnectionForm::updateButtonText()
{
    switch (connectionState) {
    case Disconnected:
        ui->connectButton->setEnabled(true);
        ui->connectButton->setText("Connect");
        ui->statusLabel->setText("Disconnected");
        ui->statusLabel->setStyleSheet("QLabel { color : red; }");
        break;
    case Connecting:
        // ui->connectButton->setText("Stop");
        ui->connectButton->setEnabled(false);
        ui->statusLabel->setText("Trying to connect");
        ui->statusLabel->setStyleSheet("QLabel { color : orange; }");
        break;
    case Connected:
        ui->connectButton->setEnabled(true);
        ui->connectButton->setText("Disconnect");
        ui->statusLabel->setText("Connected");
        ui->statusLabel->setStyleSheet("QLabel { color : green; }");
        break;
    }

    // updateFormEnabledState();
}

