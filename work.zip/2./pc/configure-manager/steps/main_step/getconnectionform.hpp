#pragma once

#include <QWidget>
#include <QTimer>

#if GET_CONNECT_MOCK
#include "mockgetconnectactions.hpp"
#else
#include "getconnectactions.hpp"
#endif

QT_BEGIN_NAMESPACE
namespace Ui { class GetConnectionForm; }
QT_END_NAMESPACE


class GetConnectionForm : public QWidget
{
    Q_OBJECT

public:
    explicit GetConnectionForm(QWidget *parent = nullptr);
    ~GetConnectionForm();

    // void showEvent(QShowEvent* event);

signals:
    void connecting();
    void connected();
    void disconnected();

private slots:
    void updateButtonText();
    void onConnectButtonClicked();
    /* void createDirs();
    void removeOldDownloadedConfig();*/
    // void tryConnectOnShow();

private:
    Ui::GetConnectionForm *ui;
    enum ConnectionState { Disconnected, Connecting, Connected };
    ConnectionState connectionState = Disconnected;

    GetConnectActions *getConnectActions = nullptr;
    QThread *getConnectThread = nullptr;

    bool hostIsValid = false;
    bool portIsValid = false;

    void updateConnectButtonState();
};
