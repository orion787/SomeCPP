#ifndef QTABLEVIEWWITHTOOLTIP_HPP
#define QTABLEVIEWWITHTOOLTIP_HPP

#include <QEvent>
#include <QHoverEvent>
#include <QObject>
#include <QTableView>
#include <QToolTip>

class QTableViewWithTooltip : public QTableView
{
public:
    QTableViewWithTooltip(QWidget *parent = nullptr) : QTableView(parent) {}

    bool event(QEvent *event) override {
        if (event->type() == QEvent::ToolTip) {

            QPoint globalPos = QCursor::pos();

            QPoint localPos = viewport()->mapFromGlobal(globalPos);

            QModelIndex index = indexAt(localPos);

            if (index.isValid()) {

                QRect rect = visualRect(index);

                if (viewport()->rect().contains(localPos)) {
                    QString text = model()->data(index, Qt::DisplayRole).toString();

                    QToolTip::showText(globalPos, text);
                } else {
                }
            }

            return true;
        }

        return QTableView::event(event);
    }
};

#endif // QTABLEVIEWWITHTOOLTIP_HPP
