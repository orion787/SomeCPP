#ifndef DRAGDROPSQLMODEL_HPP
#define DRAGDROPSQLMODEL_HPP

#include <QIODevice>
#include <QMimeData>
#include <QObject>
#include <QSqlRecord>
#include <QSqlTableModel>
#include <QSqlError>
#include <QSqlIndex>
#include <QMessageBox>

// dragdropsqlmodel.hpp
#pragma once

#include <QSqlTableModel>

class DragDropSqlModel : public QSqlTableModel {
    Q_OBJECT
public:
    int maxRowCount = 0;

    using QSqlTableModel::QSqlTableModel;

    Qt::ItemFlags flags(const QModelIndex& index) const override {
        Qt::ItemFlags f = QSqlTableModel::flags(index);
        if (index.isValid()) {
            f |= Qt::ItemIsDragEnabled;
            f |= Qt::ItemIsDropEnabled;
        } else {
            f |= Qt::ItemIsDropEnabled;
        }
        return f;
    }

    Qt::DropActions supportedDropActions() const override {
        return Qt::CopyAction | Qt::MoveAction;
    }

    QStringList mimeTypes() const override {
        return { "application/x-qsqlrecord-row" };
    }

    QMimeData* mimeData(const QModelIndexList& indexes) const override {
        QMimeData* mime = new QMimeData;
        QByteArray encoded;
        QDataStream stream(&encoded, QIODevice::WriteOnly);

        QSet<int> rows;
        for (const QModelIndex& idx : indexes)
            rows.insert(idx.row());

        for (int row : rows) {
            stream << row;
            QSqlRecord rec = record(row);
            stream << rec.count();
            for (int i = 0; i < rec.count(); ++i) {
                stream << rec.fieldName(i) << rec.value(i);
            }
        }

        mime->setData("application/x-qsqlrecord-row", encoded);
        return mime;
    }

    bool swapRows(QSqlTableModel *model, int rowA, int rowB) {
        if (!model || rowA < 0 || rowB < 0 ||
            rowA >= model->rowCount() || rowB >= model->rowCount() ||
            rowA == rowB) {
            return false;
        }

        QSqlRecord recordA = model->record(rowA);
        QSqlRecord recordB = model->record(rowB);

        int primaryKeyIndex = model->primaryKey().indexOf(model->primaryKey().fieldName(0));

        for (int i = 0; i < recordA.count(); ++i) {
            if (i == primaryKeyIndex) continue; // Skip swapping the ID

            QVariant temp = recordA.value(i);
            recordA.setValue(i, recordB.value(i));
            recordB.setValue(i, temp);
        }

        bool successA = model->setRecord(rowA, recordA);
        bool successB = model->setRecord(rowB, recordB);

        if (model->editStrategy() == QSqlTableModel::OnManualSubmit) {
            return successA && successB;
        }

        return successA && successB;
    }

    bool dropMimeData(const QMimeData *data, Qt::DropAction action, int row, int column, const QModelIndex &parent ) override {
        if (action == Qt::IgnoreAction)
            return true;

        if (action != Qt::MoveAction && action != Qt::CopyAction)
            return false;

        if (!data->hasFormat("application/x-qsqlrecord-row"))
            return false;

        int beginRow;
        if (row != -1) {
            beginRow = row;
        } else if (parent.isValid()) {
            beginRow = parent.row();
        } else {
            beginRow = rowCount(QModelIndex());
        }

        QByteArray encodedData = data->data("application/x-qsqlrecord-row");
        QDataStream stream(&encodedData, QIODevice::ReadOnly);

        int sourceRow;
        stream >> sourceRow;

        if (sourceRow == beginRow || sourceRow == beginRow - 1)
            return true;

        swapRows(this, beginRow, sourceRow);


        /*
        int sourceRow = -1;
        while (!stream.atEnd()) {
            int fieldCount;
            stream >> fieldCount;

            QMap<QString, QVariant> incomingValues;
            for (int i = 0; i < fieldCount; ++i) {
                QString fieldName;
                QVariant value;
                stream >> fieldName >> value;

                if (fieldName == "id") sourceRow = value.toInt();
                incomingValues[fieldName] = value;
            }

            QString filename;
            QSqlRecord modelRec = record();
            for (int i = 0; i < modelRec.count(); ++i) {
                QString name = modelRec.fieldName(i);
                if (name == "id") {
                    modelRec.setGenerated(name, false);
                    continue;
                }

                if (name == "file_path") {
                    filename = incomingValues["file_path"].toString();
                }

                if (incomingValues.contains(name)) {
                    modelRec.setValue(name, incomingValues[name]);
                    modelRec.setGenerated(name, true);
                } else {
                    modelRec.setGenerated(name, false);
                }
            }

            QSqlRecord recordToMove = this->record(sourceRow);

            if(!insertRecord(beginRow, recordToMove)) {
                auto errMsg = lastError().text();
                qDebug() << "Insert failed. Error:" << errMsg;
                return false;
            }
        }
        */

        // int rowToDelete = sourceRow;
        // if (beginRow <= sourceRow) {
        //     rowToDelete++;
        // }

        // Удаляем старую строку физически из БД через методы QSqlTableModel
        // this->removeRow(rowToDelete);


        // 5. Логика вставки данных на новое место
        // Оповещаем view о начале вставки строк
        // beginInsertRows(QModelIndex(), beginRow, beginRow);

        // Извлекаем элемент из вашего контейнера данных
        // MyItem movedItem = m_data.takeAt(sourceRow);

        // Корректируем индекс вставки, если мы перемещаем строку "сверху вниз",
        // так как после takeAt() размер списка уменьшился и индексы сместились
        // if (sourceRow < beginRow) {
        //     beginRow--;
        // }

        // Вставляем элемент на новую позицию
        // m_data.insert(beginRow, movedItem);

        // endInsertRows(); // Оповещаем view об успешном завершении вставки

        submitAll();
        select();

        return true;
    }

    void setMaxRowCount(int max) {
        maxRowCount = max;
    }

    bool canDropMimeData(const QMimeData *data, Qt::DropAction action,
                                    int row, int column, const QModelIndex &parent) const override {
        if (!supportedDropActions().testFlag(action)) {
            return false;
        }

        if (!data->hasFormat("application/x-qsqlrecord-row")) {
            return false;
        }

        return true;
    }
};

#endif // DRAGDROPSQLMODEL_HPP
