#ifndef ABSTRACTTABLEEDITORWIDGET_HPP
#define ABSTRACTTABLEEDITORWIDGET_HPP

#include "buttondelegate.hpp"
#include "editablesqltablemodel.hpp"

#include <QWidget>
#include <QSqlTableModel>
#include <QSortFilterProxyModel>
#include <QTableView>
#include <QVBoxLayout>
#include <QHeaderView>
#include <QLineEdit>
#include <QLabel>
#include <QStyledItemDelegate>
#include <QSqlRecord>
#include <QMessageBox>
#include <QSqlQuery>
#include <QToolTip>
#include <qtableviewwithtooltip.hpp>

class AbstractTableEditorWidget : public QWidget {
    Q_OBJECT
public:
    explicit AbstractTableEditorWidget(QWidget* parent = nullptr)
        : QWidget(parent)
    {
        setupUi();
    }

    virtual ~AbstractTableEditorWidget() = default;
    virtual QStringList readOnlyColumns() const {
        return {};
    }
    virtual QStringList notNullColumns() const {
        return {};
    }

    virtual QMap<QString, uint> maxLenghtColumns() const {
        return {};
    }

    void sortByField(const QString& fieldName) {
        if (!model || !proxyModel || !tableView) return;

        int columnIndex = model->fieldIndex(fieldName);
        if (columnIndex < 0) return;

        int proxyColumn = proxyModel->mapFromSource(model->index(0, columnIndex)).column();

        Qt::SortOrder currentOrder = tableView->horizontalHeader()->sortIndicatorOrder();
        int currentSection = tableView->horizontalHeader()->sortIndicatorSection();

        Qt::SortOrder order = Qt::AscendingOrder;
        if (currentSection == proxyColumn && currentOrder == Qt::AscendingOrder)
            order = Qt::DescendingOrder;

        tableView->sortByColumn(proxyColumn, order);
    }

    QModelIndex currentSourceIndex() const {
        if (!tableView || !proxyModel || !model)
            return {};

        QModelIndex proxyIndex = tableView->currentIndex();
        if (!proxyIndex.isValid())
            return {};

        return proxyModel->mapToSource(proxyIndex);
    }

    QSqlRecord currentRecord() const {
        QModelIndex index = currentSourceIndex();
        if (!index.isValid() || !model)
            return {};

        return model->record(index.row());
    }

protected:
    QTableViewWithTooltip* tableView = nullptr;
    QLineEdit* filterEdit = nullptr;
    QSqlTableModel* model = nullptr;
    QSortFilterProxyModel* proxyModel = nullptr;
    ButtonDelegate* buttonDelegate = nullptr;

    virtual QString tableName() const = 0;
    virtual QStringList hiddenColumns() const { return {}; }
    virtual QStyledItemDelegate* itemDelegate() const { return nullptr; }
    virtual int filterColumn() const { return 0; }


    virtual void onButtonClicked(const QModelIndex& index, int buttonId) {
        Q_UNUSED(index);
        Q_UNUSED(buttonId);
    }

    void showEvent(QShowEvent* event) override {
        QWidget::showEvent(event);
        loadModel();
    }

    void setupUi() {
        auto* layout = new QVBoxLayout(this);
        filterEdit = new QLineEdit(this);
        filterEdit->setPlaceholderText("Search...");
        tableView = new QTableViewWithTooltip(this);

        layout->addWidget(filterEdit);
        layout->addWidget(tableView);

        connect(filterEdit, &QLineEdit::textChanged, this, [this](const QString& text) {
            if (proxyModel)
                proxyModel->setFilterFixedString(text);
        });
    }

    void loadModel() {
        if (model) {
            delete model;
            model = nullptr;
        }

        model = new EditableSqlTableModel(this, this);

        model->setTable(tableName());
        model->setEditStrategy(QSqlTableModel::OnFieldChange);
        model->select();

        connect(model, &EditableSqlTableModel::beforeUpdate, this, [this](int row, QSqlRecord& record) {
            for (const QString& colName : notNullColumns()) {
                if (record.value(colName).isNull() || record.value(colName).toString().isEmpty()) {
                    QSqlQuery query(model->database());
                    QString query_str = QString("SELECT %1 FROM %2 WHERE id = :id").arg(colName).arg((model->tableName()));
                    query.prepare(query_str);
                    query.bindValue(":id", record.value(0).toInt());

                    if (query.exec()) {
                        query.next();
                        QVariant old_value = query.value(colName);
                        QString value = record.value(colName).toString();
                        // qDebug() << id << old_value << value;
                        record.setValue(colName, old_value);
                    }
                }
            }

            auto ColumnMaxLenMap = maxLenghtColumns();
            for (const QString& colName : ColumnMaxLenMap.keys()) {
                if (record.value(colName).toString().length() > ColumnMaxLenMap[colName]) {
                    QSqlQuery query(model->database());
                    QString query_str = QString("SELECT %1 FROM %2 WHERE id = :id").arg(colName).arg((model->tableName()));
                    query.prepare(query_str);
                    query.bindValue(":id", record.value(0).toInt());

                    if (query.exec()) {
                        query.next();
                        QVariant old_value = query.value(colName);
                        QString value = record.value(colName).toString();
                        record.setValue(colName, old_value);
                    }
                }
            }

        });



        for (int col = 0; col < model->columnCount(); ++col) {
            QString header = model->headerData(col, Qt::Horizontal).toString();
            QStringList words = header.split('_');
            for (QString& word : words) word[0] = word[0].toUpper();
            model->setHeaderData(col, Qt::Horizontal, words.join(' '));
        }

        if (proxyModel) delete proxyModel;
        proxyModel = new QSortFilterProxyModel(this);
        proxyModel->setSourceModel(model);
        proxyModel->setFilterKeyColumn(filterColumn());
        proxyModel->setFilterCaseSensitivity(Qt::CaseInsensitive);

        tableView->setModel(proxyModel);
        tableView->setSortingEnabled(true);
        tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        tableView->verticalHeader()->setHidden(true);

        if (auto* delegate = itemDelegate()) {
            int lastColumn = model->columnCount() - 1;
            tableView->setItemDelegateForColumn(lastColumn, delegate);

            if (auto* btnDelegate = qobject_cast<ButtonDelegate*>(delegate)) {
                connect(btnDelegate, &ButtonDelegate::buttonClicked, this, [this](const QModelIndex& index, int buttonId) {
                    onButtonClicked(index, buttonId);
                });
            }
        }

        for (const QString& name : hiddenColumns()) {
            int colIndex = model->fieldIndex(name);
            if (colIndex >= 0)
                tableView->setColumnHidden(colIndex, true);
        }

        connect(tableView->selectionModel(), &QItemSelectionModel::currentRowChanged,
            this, [this](const QModelIndex& current, const QModelIndex&) {
                if (!current.isValid()) return;
                emit currentRowChanged(currentRecord());
        });
    }

    signals:
        void currentRowChanged(const QSqlRecord& record);
};

#endif // ABSTRACTTABLEEDITORWIDGET_HPP
