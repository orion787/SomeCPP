#ifndef READONLYDRAGDROPSQLMODEL_HPP
#define READONLYDRAGDROPSQLMODEL_HPP

#include <QSqlTableModel>
#include <QMimeData>

class ReadOnlyDragDropSqlModel : public QSqlTableModel {
    Q_OBJECT
public:
    using QSqlTableModel::QSqlTableModel;

    Qt::ItemFlags flags(const QModelIndex& index) const override;
    Qt::DropActions supportedDropActions() const override;
    QStringList mimeTypes() const override;
    QMimeData* mimeData(const QModelIndexList& indexes) const override;
    bool dropMimeData(const QMimeData* data, Qt::DropAction action,
                      int row, int column, const QModelIndex& parent) override;
};

#endif // READONLYDRAGDROPSQLMODEL_HPP
