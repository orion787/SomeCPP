#ifndef BUTTONDELEGATE_HPP
#define BUTTONDELEGATE_HPP

#include <QStyledItemDelegate>
#include <QPushButton>
#include <QPainter>
#include <QMouseEvent>
#include <QApplication>
#include <QStyleOptionButton>
#include <QMap>

struct ButtonSpec {
    QString text;
    QIcon icon;
    QString tooltip;

    ButtonSpec(const QString& t = QString(), const QIcon& i = QIcon(), const QString& tip = QString())
        : text(t), icon(i), tooltip(tip) {}
};

class ButtonDelegate : public QStyledItemDelegate {
    Q_OBJECT
public:
    explicit ButtonDelegate(QObject* parent = nullptr)
        : QStyledItemDelegate(parent) {}

    void paint(QPainter* painter, const QStyleOptionViewItem& option, const QModelIndex& index) const override {
        QStyledItemDelegate::paint(painter, option, index);

        int buttonWidth = 80;
        int buttonHeight = 25;
        int spacing = 5;

        int totalWidth = (buttonWidth + spacing) * buttons.size() - spacing;
        int startX = option.rect.right() - totalWidth - spacing;

        QStyle* style = option.widget ? option.widget->style() : QApplication::style();

        for (int i = 0; i < buttons.size(); ++i) {
            const ButtonSpec& spec = buttons[i];

            QStyleOptionButton button;
            button.rect = QRect(startX + i * (buttonWidth + spacing),
                                option.rect.top() + (option.rect.height() - buttonHeight) / 2,
                                buttonWidth, buttonHeight);

            button.state = QStyle::State_Enabled;

            if (!spec.text.isEmpty()) button.text = spec.text;
            if (!spec.icon.isNull()) {
                button.icon = spec.icon;
                button.iconSize = QSize(buttonWidth - 10, buttonHeight - 10);
            }

            button.palette = option.palette;

            style->drawControl(QStyle::CE_PushButton, &button, painter);
            buttonRects[index][i] = button.rect;
        }
    }

    bool editorEvent(QEvent* event, QAbstractItemModel* /*model*/,
                     const QStyleOptionViewItem& option, const QModelIndex& index) override {
        if (event->type() == QEvent::MouseButtonRelease) {
            auto* mouseEvent = static_cast<QMouseEvent*>(event);
            const auto& buttons = buttonRects[index];
            for (int i = 0; i < buttons.size(); ++i) {
                if (buttons.contains(i) && buttons[i].contains(mouseEvent->pos())) {
                    emit buttonClicked(index, i);
                    return true;
                }
            }
        }
        return false;
    }

    void setButtons(const QVector<ButtonSpec>& specs) {
        buttons = specs;
    }


signals:
    void buttonClicked(const QModelIndex& index, int buttonId) const;

private:
    QVector<ButtonSpec> buttons;
    mutable QMap<QModelIndex, QMap<int, QRect>> buttonRects;
};
#endif // BUTTONDELEGATE_HPP
