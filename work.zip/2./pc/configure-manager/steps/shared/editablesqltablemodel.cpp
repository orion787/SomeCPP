#include "editablesqltablemodel.hpp"
#include "abstracttableeditorwidget.hpp"
#include <QSqlRecord>

EditableSqlTableModel::EditableSqlTableModel(QObject* parent, AbstractTableEditorWidget* editor)
    : QSqlTableModel(parent), editorWidget(editor) {}

Qt::ItemFlags EditableSqlTableModel::flags(const QModelIndex& index) const {
    if (!editorWidget)
        return QSqlTableModel::flags(index);

    const QString field = this->record().fieldName(index.column());
    if (editorWidget->readOnlyColumns().contains(field))
        return QSqlTableModel::flags(index) & ~Qt::ItemIsEditable;

    return QSqlTableModel::flags(index);
}
