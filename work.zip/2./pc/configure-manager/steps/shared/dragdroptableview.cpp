#include "dragdroptableview.hpp"
#include "settings.hpp"

#include <QSqlQuery>
#include <QSqlTableModel>
#include <QSqlError>
#include <QMessageBox>
#include <QFile>

bool hasExistValues(QSqlTableModel *model, const QMap<QString, QVariant>& values) {
    for (int i = 0; i < model->rowCount(); ++i) {
        QSqlRecord record = model->record(i);
        if (record.value("name").toString() == values["name"]
            || record.value("file_path").toString() == values["file_path"]
            || record.value("created").toString() == values["created"]
            ) {
            return true;
        }
    }

    return false;
}

void DragDropTableView::dropEvent(QDropEvent *event) {
    if (event->source() == this) {
        // event->ignore();
        QTableView::dropEvent(event);
        return;
    }

    auto* sqlModel = qobject_cast<QSqlTableModel*>(model());
    if (!sqlModel) {
        QTableView::dropEvent(event);
        return;
    }

    const QMimeData* mime = event->mimeData();
    if (!mime->hasFormat("application/x-qsqlrecord-row")) {
        QTableView::dropEvent(event);
        return;
    }

    QByteArray encoded = mime->data("application/x-qsqlrecord-row");
    QDataStream stream(&encoded, QIODevice::ReadOnly);

    bool success = false;
    uint dropRowCount = 0;
    int rowsBeforeInsertion = sqlModel->rowCount();

    if (rowsBeforeInsertion >= m_maxRowCount && m_maxRowCount > 0) {
        QMessageBox::warning(this, "Limit Reached", QString("You can only add up to %1 items.").arg(m_maxRowCount));
        event->ignore();
        return;
    }

    while (!stream.atEnd()) {
        int sourceRow;
        stream >> sourceRow;

        int fieldCount;
        stream >> fieldCount;

        QMap<QString, QVariant> incomingValues;
        for (int i = 0; i < fieldCount; ++i) {
            QString fieldName;
            QVariant value;
            stream >> fieldName >> value;

            if (fieldName == "id") continue;
            incomingValues[fieldName] = value;
        }

        QString filename;
        QSqlRecord modelRec = sqlModel->record();
        for (int i = 0; i < modelRec.count(); ++i) {
            QString name = modelRec.fieldName(i);
            if (name == "id") {
                modelRec.setGenerated(name, false);
                continue;
            }

            if (name == "file_path") {
                filename = incomingValues["file_path"].toString();
            }

            if (incomingValues.contains(name)) {
                modelRec.setValue(name, incomingValues[name]);
                modelRec.setGenerated(name, true);
            } else {
                modelRec.setGenerated(name, false);
            }
        }

        if(hasExistValues(sqlModel, incomingValues)) {
            continue;
        }

        if (!sqlModel->insertRecord(-1, modelRec)) {
            auto errMsg = sqlModel->lastError().text();
            qWarning() << "Insert failed:" << errMsg;
        } else {
            success = true;
            QFile::copy(Settings::instance().audioDirPath() + "/" + filename, Settings::instance().deviceAudioDirPath() + "/" + filename);
            dropRowCount++;
            emit droppedRecord(modelRec, this);
        }
    }

    int currentRowCount = sqlModel->rowCount();
    // qDebug() << Q_FUNC_INFO << "currentRowCount:" << currentRowCount << "dropRowCount" << dropRowCount << "Row count:" << sqlModel->rowCount();

    if (currentRowCount > m_maxRowCount && m_maxRowCount > 0) {
        QMessageBox::warning(this, "Limit Reached", QString("You can only add up to %1 items.").arg(m_maxRowCount));
        event->ignore();
    }

    int totalRowCount = sqlModel->rowCount();
    qDebug() << totalRowCount ;
    if (totalRowCount > m_maxRowCount && m_maxRowCount > 0) {
        int excessRows = totalRowCount - m_maxRowCount;
        for (int i = 0; i < excessRows; ++i) {

            QModelIndex index = sqlModel->index(sqlModel->rowCount() - 1, 2);
            QString filename = sqlModel->data(index).toString();
            QFile::remove(Settings::instance().deviceAudioDirPath() + "/" + filename);

            sqlModel->removeRow(sqlModel->rowCount() - 1);
        }

        QMessageBox::warning(this, "Excess Rows Removed", QString("Removed %1 extra rows.").arg(excessRows));
    }

    if (success) {
        sqlModel->submitAll();
        sqlModel->select();
        event->acceptProposedAction();
    } else {
        event->ignore();
        // QTableView::dropEvent(event);
    }
}

void DragDropTableView::setMaxRowCount(int count) {
    m_maxRowCount = count;
}

int DragDropTableView::maxRowCount() const {
    return m_maxRowCount;
}
