#ifndef ACTIONSPROXYMODEL_HPP
#define ACTIONSPROXYMODEL_HPP

#include <QIdentityProxyModel>
#include <QDebug>

class ActionsProxyModel : public QIdentityProxyModel {
    Q_OBJECT
public:
    explicit ActionsProxyModel(QObject *parent = nullptr) : QIdentityProxyModel(parent) {}

    int columnCount(const QModelIndex &parent = QModelIndex()) const override {
        int baseCols = QIdentityProxyModel::sourceModel() ? QIdentityProxyModel::sourceModel()->columnCount(parent) : 0;
        qDebug() << "[ActionsProxyModel] columnCount base:" << baseCols << "→" << (baseCols + 1);
        return baseCols + 1;
    }

    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override {
        int baseCols = QIdentityProxyModel::sourceModel() ? QIdentityProxyModel::sourceModel()->columnCount() : 0;

        if (index.column() == baseCols && role == Qt::DisplayRole) {
            qDebug() << "[ActionsProxyModel] data() for actions column";
            return QVariant();  // Let delegate handle it
        }

        return QIdentityProxyModel::data(index, role);
    }

    QVariant headerData(int section, Qt::Orientation orientation, int role) const override {
        int baseCols = QIdentityProxyModel::sourceModel() ? QIdentityProxyModel::sourceModel()->columnCount() : 0;

        if (orientation == Qt::Horizontal && role == Qt::DisplayRole && section == baseCols) {
            qDebug() << "[ActionsProxyModel] headerData() for actions column";
            return "Actions";
        }

        return QIdentityProxyModel::headerData(section, orientation, role);
    }

    QModelIndex mapToSource(const QModelIndex &proxyIndex) const override {
        int baseCols = QIdentityProxyModel::sourceModel() ? QIdentityProxyModel::sourceModel()->columnCount() : 0;

        if (proxyIndex.column() >= baseCols)
            return QModelIndex();  // Actions column → no source mapping
        return QIdentityProxyModel::mapToSource(proxyIndex);
    }

    QModelIndex mapFromSource(const QModelIndex &sourceIndex) const override {
        return QIdentityProxyModel::mapFromSource(sourceIndex);
    }
};

#endif // ACTIONSPROXYMODEL_HPP
