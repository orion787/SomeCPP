#include "abstracttableeditorwidget.hpp"
