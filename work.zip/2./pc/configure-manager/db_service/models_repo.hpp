#ifndef MODELS_REPO_H
#define MODELS_REPO_H

#include <QDateTime>
#include <QObject>
#include <QSqlDatabase>

struct ModelStruct {
    int id = -1;
    QString name;
    QString description;
    QString filePath;
    QDateTime created;
};

class ModelsRepo : public QObject
{
    Q_OBJECT
public:
    explicit ModelsRepo(QSqlDatabase& db, QObject *parent = nullptr);
    ~ModelsRepo();

    static QString stmt();
    static QString tablename();
    bool deleteModel(int id);
    bool updateModel(const ModelStruct &model);
    QList<ModelStruct> getAllModels();
    bool addModel(const ModelStruct &model);

    std::optional<ModelStruct> getModelById(int id);
    std::optional<ModelStruct> getModelByName(QString name);
private:
    void setMigrations();
    void setupMigrations();

    QSqlDatabase db;
    QStringList migrationSqls;
};

#endif // MODELS_REPO_H
