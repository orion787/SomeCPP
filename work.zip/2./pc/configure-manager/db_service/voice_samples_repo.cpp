#include <QSqlQuery>
#include <QSqlError>

#include "voice_samples_repo.hpp"

VoiceSampleRepo::VoiceSampleRepo(QSqlDatabase& db, QObject *parent)
    : QObject{parent}
{
    this->db = db;
    this->setMigrations();
    this->setupMigrations();
}

QString VoiceSampleRepo::tablename()
{
    return "voice_samples";
}

QString VoiceSampleRepo::stmt() {
    return  R"(
        CREATE TABLE IF NOT EXISTS voice_samples (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            file_path TEXT NOT NULL,
            created TEXT DEFAULT CURRENT_TIMESTAMP
        )
    )";
}

void VoiceSampleRepo::setMigrations()
{
    migrationSqls << stmt();
}

int VoiceSampleRepo::addModel(const VoiceSampleStruct& model)
{
    if (!db.isOpen()) return -1;

    QSqlQuery query(db);
    query.prepare(R"(
        INSERT INTO voice_samples (name, file_path)
        VALUES (:name, :file_path)
    )");
    query.bindValue(":name", model.name);
    query.bindValue(":file_path", model.filePath);

    if (!query.exec()) {
        return -1;
    }

    QVariant lastId = query.lastInsertId();
    if (lastId.isValid() && lastId.canConvert<int>()) {
        return lastId.toInt();
    }

    return -1;
}

QList<VoiceSampleStruct> VoiceSampleRepo::getAllModels()
{
    QList<VoiceSampleStruct> models;
    if (!db.isOpen()) return models;

    QSqlQuery query(db);
    query.exec("SELECT id, name, file_path, created FROM voice_samples");

    while (query.next()) {
        VoiceSampleStruct m;
        m.id = query.value("id").toInt();
        m.name = query.value("name").toString();
        m.filePath = query.value("file_path").toString();
        m.created = QDateTime::fromString(query.value("created").toString(), Qt::ISODate);
        models.append(m);
    }

    return models;
}

bool VoiceSampleRepo::updateModel(const VoiceSampleStruct& model)
{
    if (!db.isOpen() || model.id == -1) return false;

    QSqlQuery query(db);
    query.prepare(R"(
        UPDATE voice_samples
        SET name = :name,
            file_path = :file_path
        WHERE id = :id
    )");
    query.bindValue(":name", model.name);
    query.bindValue(":file_path", model.filePath);
    query.bindValue(":id", model.id);

    return query.exec();
}

bool VoiceSampleRepo::deleteModel(int id)
{
    if (!db.isOpen()) return false;

    QSqlQuery query(db);
    query.prepare("DELETE FROM voice_samples WHERE id = :id");
    query.bindValue(":id", id);

    return query.exec();
}

void VoiceSampleRepo::setupMigrations()
{
    QSqlQuery query(db);

    for (const QString &sql : migrationSqls) {
        if (!query.exec(sql)) {
            qWarning() << "Migrations error:" << query.lastError().text() << "\nSQL:" << sql;
        }
    }
}

std::optional<VoiceSampleStruct> VoiceSampleRepo::getVoiceSampleByName(QString name)
{
    if (!db.isOpen()) return std::nullopt;

    QSqlQuery query(db);
    query.prepare("SELECT id, name, file_path, created FROM voice_samples WHERE name = :name");
    query.bindValue(":name", name);

    if (query.exec() && query.next()) {
        VoiceSampleStruct model;
        model.id = query.value("id").toInt();
        model.name = query.value("name").toString();
        model.filePath = query.value("file_path").toString();
        model.created = QDateTime::fromString(query.value("created").toString(), Qt::ISODate);
        return model;
    }

    return std::nullopt;
}
