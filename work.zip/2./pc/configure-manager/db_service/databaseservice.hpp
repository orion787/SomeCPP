#ifndef DATABASESERVICE_HPP
#define DATABASESERVICE_HPP

#include "models_repo.hpp"
#include "voice_samples_repo.hpp"

#include <QObject>
#include <QSqlDatabase>

class DatabaseService : public QObject
{
    Q_OBJECT
public:
    explicit DatabaseService(QObject *parent = nullptr);
    static DatabaseService& instance();

    void setDatabasePath(QString db_path);

    ModelsRepo* models;
    VoiceSampleRepo* voice_samples;

    QSqlDatabase& database_instance();

private:
    void setupConnections();
    void setupRepos(QSqlDatabase db);

    QSqlDatabase _database;
    QString _db_path;
    bool is_repos_seted = false;


signals:
    void DatabasePathChanged(QString path);
    void DatabaseConnected(QSqlDatabase& db);
    void reposSeted();
};

#endif // DATABASESERVICE_HPP
