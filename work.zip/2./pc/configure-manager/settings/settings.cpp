#include "settings.hpp"

#include <QDir>

const QString DATABASE_NAME_KEY = "database_name";
const QString DATA_DIR_PATH_KEY = "data_dir_path";
const QString AUDIO_DIR_NAME_KEY = "audio_dir_path";
const QString DEVICE_AUDIO_DIR_NAME_KEY = "device_audio_dir_path";
const QString MODELS_DIR_NAME_KEY = "models_dir_path";
const QString MAX_MODELS_COUNT_IN_CONFIG_KEY = "max_models_count_in_config";
const QString RECORD_CHANNELS_COUNT_KEY = "record_channels_count";
const QString RECORD_FREQUENCY_KEY = "record_frequency_Hz";
const QString REQUIRED_BITRATE_KEY = "minimal_bitrate_kbps";
const QString REQUIRED_DURATION_KEY = "duration_secs";
const QString WRITING_LOGS_KEY = "writing_logs";

const QString REMOTE_CONFIG_DIR_PATH_KEY = "remote_config_dir_path";
const QString REMOTE_CONFIG_DB_NAME_KEY = "remote_config_db_name";

const QString PRE_UPLOAD_COMMAND_KEY = "pre_upload_command";
const QString POST_UPLOAD_COMMAND_KEY = "post_upload_command";

const QString MODEL_NAME_MAX_LEN_KEY = "model_name_max_len";

Settings::Settings(QObject *parent)
    : QObject{parent},
    m_settings("./config/config.ini", QSettings::IniFormat, this),
    context_settings("context", "conf", this)

{
    QDir dir;
    QString path = "./config";
    if (!QDir(path).exists()) {
        if (dir.mkpath(path)) {
            qDebug() << "Data dir already exists!";
        } else {
            qDebug() << "Create dir error";
        }
    }
    if (!QFile::exists(m_settings.fileName())) {
        setDefaultParams();
    }
}

Settings &Settings::instance()
{
    static Settings inst;
    return inst;
}

void Settings::setDefaultParams()
{
    // General
    setWritingLogs(true);
    setRootDataDirPath("data");
    setDatabaseName("data.db3");
    setAudioDirName("audio");
    setDeviceAudioDirName("device_audio");
    setModelsDirName("models");
    setMaxModelsCountInConfig(5);

    // Audio
    setRecordingChannelsCount(1);
    setRecordingFrequency(48000); // Hz
    setRequiredMinimalBitrate(64); // kbps
    setRequiredDuration(60);       // secs

    // Learn
    setScriptsDirPath("scripts");
    setInterpretatorPath("python");
    setLearnScriptName("learn.py");

    // Upload
    setPreUploadCommand("bash -c 'echo started > $HOME/start_file.txt'");
    setPostUploadCommand("bash -c 'cd $HOME/app && echo ended >> $HOME/end_file.txt'");

    // SshConnection
    setIp("127.0.0.1");
    setPort(22);
    setUsername("user");
    setPassword("password");

    // Remote Config
    setRemoteConfigDirPath("/home/user/app");
    setRemoteConfigDbName("target.db3");

    //Validation
    setModelNameMaxlen(80);
}

void Settings::setWritingLogs(bool writingLogs)
{
    saveSetting("General", WRITING_LOGS_KEY, writingLogs);
}

void Settings::setRootDataDirPath(QString data_dir_path)
{
    saveSetting("General", DATA_DIR_PATH_KEY, data_dir_path);
}

void Settings::setDatabaseName(QString db_name)
{
    saveSetting("General", DATABASE_NAME_KEY, db_name);
}

void Settings::setAudioDirName(QString audio_dir_name)
{
    saveSetting("General", AUDIO_DIR_NAME_KEY, audio_dir_name);
}

void Settings::setDeviceAudioDirName(QString device_audio_dir_name)
{
    saveSetting("General", DEVICE_AUDIO_DIR_NAME_KEY, device_audio_dir_name);
}

void Settings::setModelsDirName(QString dirname)
{
    saveSetting("General", MODELS_DIR_NAME_KEY, dirname);
}

void Settings::setMaxModelsCountInConfig(uint count)
{
    saveSetting("General", MAX_MODELS_COUNT_IN_CONFIG_KEY, count);
}

void Settings::setRecordingChannelsCount(uint channels_count)
{
    saveSetting("Audio", RECORD_CHANNELS_COUNT_KEY, channels_count);
}

void Settings::setRecordingFrequency(uint frequency)
{
    saveSetting("Audio", RECORD_FREQUENCY_KEY, frequency);
}

void Settings::setRequiredMinimalBitrate(uint bitrate)
{
    saveSetting("Audio", REQUIRED_BITRATE_KEY, bitrate);
}

void Settings::setRequiredDuration(uint duration)
{
    saveSetting("Audio", REQUIRED_DURATION_KEY, duration);
}

void Settings::setInterpretatorPath(QString path)
{
    saveSetting("Learn", "python_interpretator_path", path);
}

void Settings::setScriptsDirPath(QString path) {
    saveSetting("Learn", "scripts_path", path);
}

QString Settings::scriptsDirPath() {
    m_settings.beginGroup("Learn");
    QString path =  m_settings.value("scripts_path", "scripts").toString();
    m_settings.endGroup();
    return path;
}

uint Settings::modelNameMaxlen()
{
    m_settings.beginGroup("Validation");
    uint max_len =  m_settings.value(MODEL_NAME_MAX_LEN_KEY, 80).toUInt();
    m_settings.endGroup();
    return max_len;
}

void Settings::setModelNameMaxlen(uint max_len)
{
    saveSetting("Validation", MODEL_NAME_MAX_LEN_KEY, max_len);
}

void Settings::setLearnScriptName(QString path)
{
    saveSetting("Learn", "learn_script_name", path);
}

void Settings::setPreUploadCommand(QString script)
{
    saveSetting("Upload", PRE_UPLOAD_COMMAND_KEY, script);
}

void Settings::setPostUploadCommand(QString script)
{
    saveSetting("Upload", POST_UPLOAD_COMMAND_KEY, script);
}

void Settings::setIp(QString ip)
{
    saveSetting("SshConnection", "ip", ip);
}

void Settings::setPort(uint port)
{
    saveSetting("SshConnection", "port", port);
}

void Settings::setUsername(QString username)
{
    saveSetting("SshConnection", "username", username);
}

void Settings::setPassword(QString password)
{
    saveSetting("SshConnection", "password", password);
}

void Settings::setRemoteConfigDirPath(QString path)
{
    saveSetting("General", REMOTE_CONFIG_DIR_PATH_KEY, path);
}

void Settings::setRemoteConfigDbName(QString dbname)
{
    saveSetting("General", REMOTE_CONFIG_DB_NAME_KEY, dbname);
}

void Settings::saveSetting(const QString &group, const QString &key, const QVariant &value) {
    m_settings.beginGroup(group);
    m_settings.setValue(key, value);
    m_settings.endGroup();
}

bool Settings::writingLogs()
{   m_settings.beginGroup("General");
    bool writing_logs =  m_settings.value(WRITING_LOGS_KEY, false).toBool();
    m_settings.endGroup();
    return writing_logs;
}

uint Settings::requiredDuration()
{
    m_settings.beginGroup("Audio");
    uint duration =  m_settings.value(REQUIRED_DURATION_KEY, 60).toUInt();
    m_settings.endGroup();
    return duration;
}


uint Settings::requiredBitrate()
{
    m_settings.beginGroup("Audio");
    uint bitrate =  m_settings.value(REQUIRED_BITRATE_KEY, 64).toUInt();
    m_settings.endGroup();
    return bitrate;
}

QString Settings::rootDataDirPath()
{
    m_settings.beginGroup("General");
    QString dir =  m_settings.value(DATA_DIR_PATH_KEY, "data").toString();
    m_settings.endGroup();
    return dir;
}

QString Settings::databaseName()
{
    m_settings.beginGroup("General");
    QString db_name =  m_settings.value(DATABASE_NAME_KEY, "data.db3").toString();
    m_settings.endGroup();
    return db_name;
}

QString Settings::databasePath()
{
    return rootDataDirPath()+"/"+databaseName();
}

QString Settings::audioDirName()
{
    m_settings.beginGroup("General");
    QString dir_name =  m_settings.value(AUDIO_DIR_NAME_KEY, "audio").toString();
    m_settings.endGroup();
    return dir_name;
}

QString Settings::audioDirPath()
{
    return rootDataDirPath()+"/"+audioDirName();
}

QString Settings::deviceAudioDirName()
{
    m_settings.beginGroup("General");
    QString dir_name =  m_settings.value(DEVICE_AUDIO_DIR_NAME_KEY, "device_audio").toString();
    m_settings.endGroup();
    return dir_name;
}

QString Settings::deviceAudioDirPath()
{
    return rootDataDirPath()+"/"+deviceAudioDirName();
}

QString Settings::modelsDirName()
{
    m_settings.beginGroup("General");
    QString dir_name =  m_settings.value(MODELS_DIR_NAME_KEY, "models").toString();
    m_settings.endGroup();
    return dir_name;
}

QString Settings::modelsDirPath()
{
    return rootDataDirPath()+"/"+modelsDirName();
}

uint Settings::maxModelsCountInConfig()
{
    m_settings.beginGroup("General");
    uint max_models_count =  m_settings.value(MAX_MODELS_COUNT_IN_CONFIG_KEY, 5).toUInt();
    m_settings.endGroup();
    return max_models_count;
}

int Settings::recordingChannelsCount()
{
    m_settings.beginGroup("Audio");
    int count =  m_settings.value(RECORD_CHANNELS_COUNT_KEY, 1).toInt();
    m_settings.endGroup();
    return count;
}

int Settings::recordingFrequency()
{
    m_settings.beginGroup("Audio");
    int freq =  m_settings.value(RECORD_FREQUENCY_KEY, 48000).toInt();
    m_settings.endGroup();
    return freq;
}

QString Settings::interpretatorPath()
{
    m_settings.beginGroup("Learn");
    QString path = m_settings.value("python_interpretator_path", "python").toString();
    m_settings.endGroup();
    return path;
}

QString Settings::learnScriptName()
{
    m_settings.beginGroup("Learn");
    QString path = m_settings.value("learn_script_name", "learn.py").toString();
    m_settings.endGroup();
    return path;
}

QString Settings::remoteConfigDirPath()
{
    m_settings.beginGroup("General");
    QString dir =  m_settings.value(REMOTE_CONFIG_DIR_PATH_KEY, "/home/user/app").toString();
    m_settings.endGroup();
    return dir;
}

QString Settings::remoteConfigDbName()
{
    m_settings.beginGroup("General");
    QString db_name =  m_settings.value(REMOTE_CONFIG_DB_NAME_KEY, "target.db3").toString();
    m_settings.endGroup();
    return db_name;
}

QString Settings::preUploadCommand()
{   m_settings.beginGroup("Upload");
    QString cmd = m_settings.value(PRE_UPLOAD_COMMAND_KEY, "bash -c 'echo started > $HOME/start_file.txt'").toString();
    m_settings.endGroup();
    return cmd;
}

QString Settings::postUploadCommand()
{   m_settings.beginGroup("Upload");
    QString cmd = m_settings.value(POST_UPLOAD_COMMAND_KEY, "bash -c 'cd $HOME/app && echo ended >> $HOME/end_file.txt'").toString();
    m_settings.endGroup();
    return cmd;
}

QString Settings::ip() {
    m_settings.beginGroup("SshConnection");
    QString value = m_settings.value("ip", "").toString();
    m_settings.endGroup();
    return value;
}

uint Settings::port() {
    m_settings.beginGroup("SshConnection");
    uint value = m_settings.value("port", 22).toUInt();
    m_settings.endGroup();
    return value;
}

QString Settings::username() {
    m_settings.beginGroup("SshConnection");
    QString value = m_settings.value("username", "").toString();
    m_settings.endGroup();
    return value;
}

QString Settings::password() {
    m_settings.beginGroup("SshConnection");
    QString value = m_settings.value("password", "").toString();
    m_settings.endGroup();
    return value;
}

QString Settings::lastDirectoryForImportAudio() {
    return context_settings.value("last_dir", QDir::homePath()).toString();
}

void Settings::setLastDirectoryForImportAudio(QString last_dir) {
    context_settings.setValue("last_dir", last_dir);
    context_settings.sync();
}
