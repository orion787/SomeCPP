#pragma once

#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrl>
#include <QByteArray>

#ifdef ADDR_DEVICE_MOCK
inline constexpr const char* URL = "10.196.100.78:3040";
#else
inline constexpr const char* URL = "192.168.55.1:3040";
#endif

class HttpClient : public QObject {
    Q_OBJECT

public:
    enum class RequestType {
        Get,
        Post,
        PostFile
    };
    Q_ENUM(RequestType);

    explicit HttpClient(QObject *parent = nullptr);

    void get(const QString &urlPath);
    void post(const QString &urlPath, const QByteArray &body);
    void postFile(const QString& urlPath, const QString& id, const QString& fileName, const QByteArray& fileBody);

signals:
    void replyReady(HttpClient::RequestType reguestType, QString urlPath, int statusCode, const QByteArray &data);
    void replyError(HttpClient::RequestType reguestType, QString urlPath, QNetworkReply::NetworkError error);

private slots:
    void onFinished();
    void onError(QNetworkReply::NetworkError error);

private:
    QNetworkAccessManager *m_manager = nullptr;

    const int requestTimeout = 1000;

    QUrl m_host;
};