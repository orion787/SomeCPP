#include "databaseservice.hpp"
#include "QSqlDriver"
#include "QSqlError"
#include "settings.hpp"

DatabaseService::DatabaseService(QObject *parent)
    : QObject{parent}
{
    this->_database = QSqlDatabase::addDatabase("QSQLITE");
    setupConnections();
    setDatabasePath(Settings::instance().databasePath());
}

DatabaseService &DatabaseService::instance()
{
    static DatabaseService inst;
    return inst;
}

void DatabaseService::setDatabasePath(QString db_path)
{
    _db_path = db_path;

    _database.setDatabaseName(db_path);
    if (!_database.open()) {
        qCritical() << "Database connect error:" << _database.lastError().text();
        return;
    }
    emit DatabaseConnected(_database);

    setupRepos(_database);
}

QSqlDatabase &DatabaseService::database_instance()
{
    return _database;
}

void DatabaseService::setupConnections()
{
}

void DatabaseService::setupRepos(QSqlDatabase db)
{
    this->models = new ModelsRepo(db, this);
    this->voice_samples = new VoiceSampleRepo(db, this);

    is_repos_seted = true;

    emit reposSeted();
}
