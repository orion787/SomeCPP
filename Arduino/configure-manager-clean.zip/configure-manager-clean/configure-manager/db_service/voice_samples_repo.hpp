#ifndef VOICE_SAMPLES_REPO_HPP
#define VOICE_SAMPLES_REPO_HPP

#include <QDateTime>
#include <QObject>
#include <QSqlDatabase>

struct VoiceSampleStruct {
    int id = -1;
    QString name;
    QString filePath;
    QDateTime created;
};

class VoiceSampleRepo : public QObject
{
    Q_OBJECT
public:
    explicit VoiceSampleRepo(QSqlDatabase& db, QObject *parent = nullptr);

    static QString tablename();
    static QString stmt();
    bool deleteModel(int id);
    bool updateModel(const VoiceSampleStruct &model);
    QList<VoiceSampleStruct> getAllModels();
    int addModel(const VoiceSampleStruct &model);

    std::optional<VoiceSampleStruct> getVoiceSampleByName(QString name);
private:
    void setMigrations();
    void setupMigrations();

    QSqlDatabase db;
    QStringList migrationSqls;
};

#endif // VOICE_SAMPLES_REPO_HPP
