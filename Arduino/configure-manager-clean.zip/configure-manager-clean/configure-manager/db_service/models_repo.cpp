#include "models_repo.hpp"

#include <QSqlQuery>
#include <QSqlError>

ModelsRepo::ModelsRepo(QSqlDatabase& db, QObject *parent)
    : QObject{parent}
{
    this->db = db;
    this->setMigrations();
    this->setupMigrations();
}

ModelsRepo::~ModelsRepo()
{
    db.close();
}

QString ModelsRepo::stmt()
{
    return R"(
        CREATE TABLE IF NOT EXISTS models (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            file_path TEXT NOT NULL,
            created TEXT DEFAULT CURRENT_TIMESTAMP
        )
    )";
}

QString ModelsRepo::tablename()
{
    return "models";
}

void ModelsRepo::setMigrations()
{
    migrationSqls << stmt();
}

bool ModelsRepo::addModel(const ModelStruct& model)
{
    if (!db.isOpen()) return false;

    QSqlQuery query(db);
    query.prepare(R"(
        INSERT INTO models (name, description, file_path)
        VALUES (:name, :description, :file_path)
    )");
    query.bindValue(":name", model.name);
    query.bindValue(":description", model.description);
    query.bindValue(":file_path", model.filePath);

    return query.exec();
}

QList<ModelStruct> ModelsRepo::getAllModels()
{
    QList<ModelStruct> models;
    if (!db.isOpen()) return models;

    QSqlQuery query(db);
    query.exec("SELECT id, name, description, file_path, created_at FROM models");

    while (query.next()) {
        ModelStruct m;
        m.id = query.value("id").toInt();
        m.name = query.value("name").toString();
        m.description = query.value("description").toString();
        m.filePath = query.value("file_path").toString();
        m.created = QDateTime::fromString(query.value("created_at").toString(), Qt::ISODate);
        models.append(m);
    }

    return models;
}

bool ModelsRepo::updateModel(const ModelStruct& model)
{
    if (!db.isOpen() || model.id == -1) return false;

    QSqlQuery query(db);
    query.prepare(R"(
        UPDATE models
        SET name = :name,
            description = :description,
            file_path = :file_path
        WHERE id = :id
    )");
    query.bindValue(":name", model.name);
    query.bindValue(":description", model.description);
    query.bindValue(":file_path", model.filePath);
    query.bindValue(":id", model.id);

    return query.exec();
}

bool ModelsRepo::deleteModel(int id)
{
    if (!db.isOpen()) return false;

    QSqlQuery query(db);
    query.prepare("DELETE FROM models WHERE id = :id");
    query.bindValue(":id", id);

    return query.exec();
}

void ModelsRepo::setupMigrations()
{
    QSqlQuery query(db);

    for (const QString &sql : migrationSqls) {
        if (!query.exec(sql)) {
            qWarning() << "Migrations error:" << query.lastError().text() << "\nSQL:" << sql;
        }
    }
}

std::optional<ModelStruct> ModelsRepo::getModelById(int id)
{
    if (!db.isOpen()) return std::nullopt;

    QSqlQuery query(db);
    query.prepare("SELECT id, name, description, file_path, created FROM models WHERE id = :id");
    query.bindValue(":id", id);

    if (query.exec() && query.next()) {
        ModelStruct model;
        model.id = query.value("id").toInt();
        model.name = query.value("name").toString();
        model.description = query.value("description").toString();
        model.filePath = query.value("file_path").toString();
        model.created = QDateTime::fromString(query.value("created").toString(), Qt::ISODate);
        return model;
    }

    return std::nullopt;
}

std::optional<ModelStruct> ModelsRepo::getModelByName(QString name)
{
    if (!db.isOpen()) return std::nullopt;

    QSqlQuery query(db);
    query.prepare("SELECT id, name, description, file_path, created FROM models WHERE name = :name");
    query.bindValue(":name", name);

    if (query.exec() && query.next()) {
        ModelStruct model;
        model.id = query.value("id").toInt();
        model.name = query.value("name").toString();
        model.description = query.value("description").toString();
        model.filePath = query.value("file_path").toString();
        model.created = QDateTime::fromString(query.value("created").toString(), Qt::ISODate);
        return model;
    }

    return std::nullopt;
}
