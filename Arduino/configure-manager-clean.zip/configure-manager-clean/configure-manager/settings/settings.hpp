#ifndef SETTINGS_HPP
#define SETTINGS_HPP

#include <QDir>
#include <QObject>
#include <QSettings>

class Settings : public QObject
{
    Q_OBJECT
public:
    explicit Settings(QObject *parent = nullptr);
    static Settings& instance();
    void setDefaultParams();

    bool writingLogs();

    uint requiredDuration();

    uint requiredBitrate();

    QString rootDataDirPath();

    QString databaseName();
    QString databasePath();

    QString audioDirName();
    QString audioDirPath();

    QString deviceAudioDirName();
    QString deviceAudioDirPath();

    QString modelsDirName();
    void setModelsDirName(QString dirname);
    QString modelsDirPath();

    uint maxModelsCountInConfig();
    void setMaxModelsCountInConfig(uint count);

    void setRecordingChannelsCount(uint channels_count);
    int recordingChannelsCount();

    void setRecordingFrequency(uint frequency);
    int recordingFrequency();

    void setInterpretatorPath(QString path);
    QString interpretatorPath();

    void setLearnScriptName(QString path);
    QString learnScriptName();

    void setRemoteConfigDirPath(QString path);
    QString remoteConfigDirPath();

    void setRemoteConfigDbName(QString dbname);
    QString remoteConfigDbName();

    void setPreUploadCommand(QString script);
    QString preUploadCommand();

    void setPostUploadCommand(QString script);
    QString postUploadCommand();


    void setPassword(QString password);
    QString password();

    void setUsername(QString username);
    QString username();

    void setPort(uint port);
    uint port();

    void setIp(QString ip);
    QString ip();

    void saveSetting(const QString &group, const QString &key, const QVariant &value);
    void setRootDataDirPath(QString data_dir_path);
    void setDatabaseName(QString db_name);
    void setAudioDirName(QString audio_dir_name);
    void setDeviceAudioDirName(QString device_audio_dir_name);
    void setRequiredMinimalBitrate(uint bitrate);
    void setRequiredDuration(uint duration);
    void setWritingLogs(bool writingLogs);
    void setScriptsDirPath(QString path);
    QString scriptsDirPath();

    uint modelNameMaxlen();
    void setModelNameMaxlen(uint name);
    QString lastDirectoryForImportAudio();
    void setLastDirectoryForImportAudio(QString last_dir);
private:
    QSettings m_settings;
    QSettings context_settings;
};

#endif // SETTINGS_HPP
