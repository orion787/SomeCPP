#include "mainwindow.hpp"
#include "./ui_mainwindow.h"

#include <databaseservice.hpp>
#include <settings.hpp>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setupConnections();
    setWindowTitle(tr("Configure manager v") + APP_VERSION);
    DatabaseService::instance();
    this->switchButtons(ui->stepsTabWidget->currentIndex());
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setupConnections() {

    connect(ui->stepsTabWidget, &QTabWidget::currentChanged, this, &MainWindow::switchButtons);
    connect(ui->nextButton, &QPushButton::clicked, this, &MainWindow::nextStep);
    connect(ui->backButton, &QPushButton::clicked, this, &MainWindow::prevStep);
}

void restartApplication() {
    QString program = QCoreApplication::applicationFilePath();
    QStringList arguments = QCoreApplication::arguments();

    QProcess::startDetached(program, arguments);
    QApplication::exit(0);
}

void MainWindow::enableSwitchTabs()
{
    int count = ui->stepsTabWidget->count();
    for (int i = 0; i < count; ++i) {
        ui->stepsTabWidget->setTabEnabled(i, true);
    }
}

void MainWindow::switchToFirstStep() {
    ui->stepsTabWidget->setCurrentIndex(0);
    updateCurrentView();
}



void MainWindow::nextStep() {
    QApplication::setOverrideCursor(Qt::WaitCursor);
    uint8_t maxIndex = ui->stepsTabWidget->count()-1;
    uint8_t currentIndex = ui->stepsTabWidget->currentIndex();
    uint8_t indexToSwitch = currentIndex < maxIndex ? currentIndex+1: currentIndex;

    if (ui->stepsTabWidget->isTabEnabled(indexToSwitch)) {
        ui->stepsTabWidget->setCurrentIndex(indexToSwitch);
    }

    QApplication::restoreOverrideCursor();
    updateCurrentView();
}

void MainWindow::prevStep() {
    QApplication::setOverrideCursor(Qt::WaitCursor);
    uint8_t minIndex = 0;
    uint8_t currentIndex = ui->stepsTabWidget->currentIndex();
    uint8_t indexToSwitch = currentIndex > minIndex ? currentIndex-1: currentIndex;

    if (ui->stepsTabWidget->isTabEnabled(indexToSwitch)) {
        ui->stepsTabWidget->setCurrentIndex(indexToSwitch);
    }

    QApplication::restoreOverrideCursor();
    updateCurrentView();
}

void MainWindow::updateCurrentView()
{
    ui->stepsTabWidget->currentWidget()->hide();
    ui->stepsTabWidget->currentWidget()->show();
}

void MainWindow::switchButtons(int index) {
    if (index == 0) {
        ui->nextButton->setEnabled(true);
        ui->backButton->setEnabled(false);
        return;
    }
    else if (index == (ui->stepsTabWidget->count()-1) ) {
        ui->nextButton->setEnabled(false);
        ui->backButton->setEnabled(true);
        return;
    }
    else if (!ui->stepsTabWidget->isTabEnabled(index+1)) {
        ui->nextButton->setEnabled(false);
        ui->backButton->setEnabled(true);
        return;
    }
    else if (!ui->stepsTabWidget->isTabEnabled(index-1)) {
        ui->nextButton->setEnabled(true);
        ui->backButton->setEnabled(false);
        return;
    }
    ui->nextButton->setEnabled(true);
    ui->backButton->setEnabled(true);
}
