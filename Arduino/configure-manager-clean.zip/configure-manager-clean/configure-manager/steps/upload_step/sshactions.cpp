#include "sshactions.hpp"

#include <QFile>
#include <QMetaObject>
#include <QDebug>

#ifdef _WIN32
#include <QFileInfo>
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "Ws2_32.lib")
#else
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
#endif

SshActions::SshActions()
{
    libssh2_init(0);
}

SshActions::~SshActions()
{
    stopRequested = true;
    if (connectThread.joinable())
        connectThread.join();
    disconnect();
    libssh2_exit();
}

void SshActions::connectAsync(const QString &host, int port,
                              const QString &username, const QString &password)
{
    stopRequested = false;

    if (connectThread.joinable())
        connectThread.join();

    QString h = host, u = username, p = password;

    connectThread = std::thread([=]() {
        runConnection(h, port, u, p);
    });
}

void SshActions::disconnect()
{
    stopRequested = true;

    QMetaObject::invokeMethod(this, [this]() {
        performDisconnect();
    }, Qt::QueuedConnection);
}

void SshActions::performDisconnect()
{
    cleanup();
    emit disconnected();
}

void SshActions::runConnection(const QString &qhost, int port,
                               const QString &quser, const QString &qpass)
{
    qDebug() << "[SshActions] runConnection started";

    std::string host = qhost.toStdString();
    std::string user = quser.toStdString();
    std::string pass = qpass.toStdString();

    if (stopRequested.load()) {
        qDebug() << "[SshActions] Cancelled before connectToHost";
        emit connectionCancelled();
        return;
    }

    bool success = connectToHost(host, port, user, pass);

    if (stopRequested.load()) {
        qDebug() << "[SshActions] Cancelled after connectToHost";
        cleanup();
        emit connectionCancelled();
        return;
    }

    if (success) {
        connectedFlag = true;
        emit connected();
        qDebug() << "[SshActions] Connected successfully";
    } else {
        emit connectionFailed(lastError.isEmpty() ? "Unknown error" : lastError);
        qDebug() << "[SshActions] Connection failed:" << lastError;
    }
}

bool SshActions::initializeSocket(const std::string &host, int port)
{
#ifdef _WIN32
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
        return false;
#endif

    sock = socket(AF_INET, SOCK_STREAM, 0);
#ifdef _WIN32
    if (sock == INVALID_SOCKET)
#else
    if (sock < 0)
#endif
    {
        lastError = "Socket creation failed";
        return false;
    }

    sockaddr_in sin{};
    sin.sin_family = AF_INET;
    sin.sin_port = htons(port);
    inet_pton(AF_INET, host.c_str(), &sin.sin_addr);

    if (::connect(sock, reinterpret_cast<sockaddr*>(&sin), sizeof(sin)) != 0) {
        lastError = "Connection failed";
#ifdef _WIN32
        closesocket(sock);
        sock = INVALID_SOCKET;
#else
        close(sock);
        sock = -1;
#endif
        return false;
    }

    return true;
}

bool SshActions::connectToHost(const std::string &host, int port,
                               const std::string &username, const std::string &password)
{
    if (stopRequested.load()) return false;
    if (!initializeSocket(host, port)) return false;
    if (stopRequested.load()) return false;

    session = libssh2_session_init();
    if (!session) {
        lastError = "Session init failed";
        return false;
    }

    libssh2_session_set_blocking(session, 1);
    if (stopRequested.load()) {
        cleanup();
        return false;
    }

    if (libssh2_session_handshake(session, sock)) {
        lastError = "SSH handshake failed";
        cleanup();
        return false;
    }

    if (stopRequested.load()) {
        cleanup();
        return false;
    }

    if (libssh2_userauth_password(session, username.c_str(), password.c_str())) {
        lastError = "Authentication failed";
        cleanup();
        return false;
    }

    if (stopRequested.load()) {
        cleanup();
        return false;
    }

    sftp_session = libssh2_sftp_init(session);
    if (!sftp_session) {
        lastError = "SFTP session failed";
        cleanup();
        return false;
    }

    return true;
}

void SshActions::cleanup()
{
    if (sftp_session) {
        libssh2_sftp_shutdown(sftp_session);
        sftp_session = nullptr;
    }

    if (session) {
        libssh2_session_disconnect(session, "Normal Shutdown");
        libssh2_session_free(session);
        session = nullptr;
    }

#ifdef _WIN32
    if (sock != INVALID_SOCKET) {
        closesocket(sock);
        sock = INVALID_SOCKET;
    }
#else
    if (sock >= 0) {
        close(sock);
        sock = -1;
    }
#endif

    connectedFlag = false;
}

QString SshActions::executeCommand(const QString &command)
{
    if (!connectedFlag || !session) return {};

    LIBSSH2_CHANNEL *channel = libssh2_channel_open_session(session);
    if (!channel) {
        lastError = "Failed to open SSH channel";
        return {};
    }

    if (libssh2_channel_exec(channel, command.toStdString().c_str()) != 0) {
        lastError = "Command execution failed";
        libssh2_channel_free(channel);
        return {};
    }

    char buffer[4096];
    QString result;
    ssize_t n;

    while ((n = libssh2_channel_read(channel, buffer, sizeof(buffer))) > 0) {
        result.append(QString::fromUtf8(buffer, static_cast<int>(n)));
    }

    libssh2_channel_close(channel);
    libssh2_channel_free(channel);
    return result;
}

void SshActions::uploadFilesAsync(const QStringList &localPaths, const QString &remoteDir)
{
    QMetaObject::invokeMethod(this, [=]() {
        qint64 totalSize = 0;
        for (const QString &path : localPaths) {
            QFileInfo info(path);
            if (info.exists()) totalSize += info.size();
        }

        qint64 totalSent = 0;

        for (const QString &localPath : localPaths) {
            QFileInfo fileInfo(localPath);
            if (!fileInfo.exists()) {
                emit uploadFailed(localPath, "Local file does not exist");
                continue;
            }

            QString remotePath = remoteDir + "/" + fileInfo.fileName();

            QFile file(localPath);
            if (!file.open(QIODevice::ReadOnly)) {
                emit uploadFailed(localPath, "Cannot open local file");
                continue;
            }

            auto *handle = libssh2_sftp_open(sftp_session, remotePath.toUtf8().data(),
                                             LIBSSH2_FXF_WRITE | LIBSSH2_FXF_CREAT | LIBSSH2_FXF_TRUNC,
                                             0644);
            if (!handle) {
                char *errmsg;
                int errlen;
                libssh2_session_last_error(session, &errmsg, &errlen, 0);
                emit uploadFailed(localPath, QString("Failed to open remote file: %1").arg(QString::fromUtf8(errmsg, errlen)));
                continue;
            }

            qint64 fileSize = file.size();
            qint64 fileSent = 0;

            QByteArray data;
            while (!(data = file.read(4096)).isEmpty()) {
                const char *ptr = data.constData();
                size_t len = data.size();

                while (len > 0) {
                    ssize_t written = libssh2_sftp_write(handle, ptr, len);
                    if (written < 0) {
                        emit uploadFailed(localPath, "Write failed");
                        libssh2_sftp_close(handle);
                        goto nextFile;
                    }
                    ptr += written;
                    len -= written;
                    fileSent += written;
                    totalSent += written;

                    emit uploadProgress(localPath, fileSent, fileSize);
                    emit uploadTotalProgress(totalSent, totalSize);
                }
            }

            emit uploadFinished(localPath);
            libssh2_sftp_close(handle);

        nextFile:
            continue;
        }

        emit uploadTotalFinished();
    }, Qt::QueuedConnection);
}

void SshActions::uploadFileAsync(const QString &localPath, const QString &remotePath)
{
    QMetaObject::invokeMethod(this, [=]() {
        QFile file(localPath);
        if (!file.open(QIODevice::ReadOnly)) {
            emit uploadFailed(localPath, "Cannot open local file");
            return;
        }

        auto *handle = libssh2_sftp_open(sftp_session, remotePath.toUtf8().data(),
                                         LIBSSH2_FXF_WRITE | LIBSSH2_FXF_CREAT | LIBSSH2_FXF_TRUNC,
                                         0644);
        if (!handle) {
            emit uploadFailed(localPath, "Failed to open remote file");
            return;
        }

        qint64 total = file.size();
        qint64 sent = 0;

        QByteArray data;
        while (!(data = file.read(4096)).isEmpty()) {
            const char *ptr = data.constData();
            size_t len = data.size();

            while (len > 0) {
                ssize_t written = libssh2_sftp_write(handle, ptr, len);
                if (written < 0) {
                    emit uploadFailed(localPath, "Write failed");
                    libssh2_sftp_close(handle);
                    return;
                }
                ptr += written;
                len -= written;
                sent += written;
                emit uploadProgress(localPath, sent, total);
            }
        }

        libssh2_sftp_close(handle);
        emit uploadFinished(localPath);
    }, Qt::QueuedConnection);
}

bool SshActions::downloadFile(const QString &remotePath, const QString &localPath)
{
    if (!connectedFlag || !sftp_session) return false;

    LIBSSH2_SFTP_HANDLE *handle = libssh2_sftp_open(sftp_session, remotePath.toUtf8().data(),
                                                    LIBSSH2_FXF_READ, 0);
    if (!handle) {
        lastError = "Failed to open remote file for reading";
        return false;
    }

    QFile file(localPath);
    if (!file.open(QIODevice::WriteOnly)) {
        lastError = "Failed to open local file for writing";
        libssh2_sftp_close(handle);
        return false;
    }

    char buffer[4096];
    ssize_t n;

    while ((n = libssh2_sftp_read(handle, buffer, sizeof(buffer))) > 0) {
        if (file.write(buffer, n) != n) {
            lastError = "Error writing to local file";
            libssh2_sftp_close(handle);
            return false;
        }
    }

    libssh2_sftp_close(handle);
    return true;
}

QStringList SshActions::listRemoteDirectory(const QString &remotePath)
{
    QStringList result;

    if (!connectedFlag || !sftp_session)
        return result;

    QByteArray remotePathUtf8 = remotePath.toUtf8();
    LIBSSH2_SFTP_HANDLE *dir = libssh2_sftp_opendir(sftp_session, remotePathUtf8.constData());
    if (!dir) {
        lastError = "Failed to open remote directory";
        return result;
    }

    char buffer[512];
    LIBSSH2_SFTP_ATTRIBUTES attrs;

    while (libssh2_sftp_readdir(dir, buffer, sizeof(buffer), &attrs) > 0) {
        result.append(QString::fromUtf8(buffer));
    }

    libssh2_sftp_closedir(dir);
    return result;
}

QString SshActions::getLastError()
{
    return lastError;
}
