#include "uploadconfigform.hpp"
#include "ui_uploadconfigform.h"

#include <QFile>
#include <QMessageBox>
#include <QSqlQuery>
#include <QMetaEnum>
#include <QJsonObject>
#include <QJsonArray>
#include <settings.hpp>
#include <QTimer>
#include "editconfigform.hpp"
#include "voice_samples_repo.hpp"
#include "databaseservice.hpp"
#include "utils.h"

inline constexpr const char* URL_PATH_UPLOAD = "/upload";
inline constexpr const char* URL_PATH_UPLOAD_FILE = "/upload/file";
inline constexpr const char* URL_PATH_DOWNLOAD = "/download";
inline constexpr const char* URL_PATH_DOWNLOAD_FILE = "/download/";


UploadConfigForm::UploadConfigForm(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::UploadConfigForm)
    , voiceClient(parent)
    , stateUploadClient(parent)
{
    ui->setupUi(this);

    ui->sshConnectionForm->setVisible(false);
    ui->progressBar->setVisible(false);

    ui->sshConnectionForm->setVisibleSshCredsLineEdits(false);

    ui->sshConnectionForm->setIp(Settings::instance().ip());
    ui->sshConnectionForm->setPort(Settings::instance().port());
    ui->sshConnectionForm->setUsername(Settings::instance().username());
    ui->sshConnectionForm->setPassword(Settings::instance().password());

    ui->editConfigForm->setMaxTargetRowCount(Settings::instance().maxModelsCountInConfig());

    this->setDisabled(true);

    // setWidgetsEnabled(false);

    setupDatabases();

    setViewState(ui->editConfigForm->targetTable()->model());

    connect(&stateUploadClient, &HttpClient::replyReady, this, &UploadConfigForm::applyUploadpReady);
    connect(&stateUploadClient, &HttpClient::replyError, this, &UploadConfigForm::applyUploadpError);

    connect(ui->editConfigForm->targetTable(), &DragDropTableView::droppedRecord, this, [this](const QSqlRecord&, DragDropTableView* table){
        setViewState(table->model());
    });

    connect(ui->editConfigForm, &EditConfigForm::removeTargetRow, this, [this](QSqlTableModel* model){
        setViewState(model);
    });

    connect(&voiceClient, &HttpClient::replyReady, this, [this](HttpClient::RequestType reguestType, QString urlPath, int statusCode, const QByteArray &data){
        if(statusCode != 200) {
            const char* key = QMetaEnum::fromType<HttpClient::RequestType>().valueToKey(static_cast<int>(reguestType));
            QMessageBox::critical(this, "Upload error", "Error while doing request to " + urlPath + ", request method " + QString::fromUtf8(key) + ".");
            viewAddingTargets();
            return;
        }

        if((reguestType == HttpClient::RequestType::Post && urlPath == QString(URL_PATH_UPLOAD))
            || (reguestType == HttpClient::RequestType::PostFile &&urlPath == QString(URL_PATH_UPLOAD_FILE))) {
            emit readySendFile();
        }

        if(reguestType == HttpClient::RequestType::Get && urlPath == QString(URL_PATH_DOWNLOAD)) {
            auto model = ui->editConfigForm->getTargetModel();
            while(model->rowCount() != 0) {
                model->removeRow(0);
                model->submitAll();
                model->select();
            }

            QJsonParseError err;
            for (const auto &val : QJsonDocument::fromJson(data, &err).array()) {
                auto obj = val.toObject();

                int id = obj.value("Id").toInt(-1);
                int sequence = obj.value("Sequence").toInt(-1);
                QString name = obj.value("Name").toString();
                QString filePath = obj.value("File_path").toString();
                QString created = obj.value("Created").toString();

                model->insertRow(0);

                model->setData(model->index(0, 1), name);
                model->setData(model->index(0, 2), filePath);
                model->setData(model->index(0, 3), created);
                model->submitAll();
                model->select();
            }

            removeWavFiles(Settings::instance().deviceAudioDirPath());
            targetRow = 0;
            emit readyReceiveFile();
        }

        if(reguestType == HttpClient::RequestType::Get && urlPath.contains(URL_PATH_DOWNLOAD_FILE)) {
            QFileInfo fileInfo(urlPath);

            QFile file(Settings::instance().deviceAudioDirPath() + "/" + fileInfo.fileName());
            if (!file.open(QIODevice::WriteOnly)) {
                qWarning() << "Could not open file for writing:" << file.errorString();
                return;
            }
            file.write(data);
            file.close();

            emit readyReceiveFile();
        }
    });

    connect(&voiceClient, &HttpClient::replyError, this, [this](HttpClient::RequestType reguestType, QString urlPath, QNetworkReply::NetworkError error){
        QString errorMessage(QMetaEnum::fromType<QNetworkReply::NetworkError>()
                                 .valueToKey(static_cast<int>(error)));

        const char* key = QMetaEnum::fromType<HttpClient::RequestType>().valueToKey(static_cast<int>(reguestType));
        QMessageBox::critical(this, "Upload error", "Error while doing request to " + urlPath + ", request method " + QString::fromUtf8(key) + ".");
        viewAddingTargets();
    });

    connect(this, &UploadConfigForm::readySendFile, this, [this](){
        const int count = ui->editConfigForm->targetTable()->model()->rowCount();
        if(targetRow < count) {
            sendFile(targetRow);
            ++targetRow;
        } else {
            targetRow = 0;
            viewAddingTargets();
            return;
        }
    });

    connect(this, &UploadConfigForm::readyReceiveFile, this, [this](){
        const int count = ui->editConfigForm->targetTable()->model()->rowCount();
        if(targetRow < count) {
            receiveFile(targetRow);
            ++targetRow;
        } else {
            targetRow = 0;
            viewAddingTargets();
            return;
        }
    });

    /*
    connect(ui->sshConnectionForm, &SshConnectionForm::uploaded, this, [this]() {
        ui->sshConnectionForm->downloadRemoteTargetConfigDb();
        setupDatabases();
        ui->saveButton->setEnabled(true);
    });

    connect(ui->sshConnectionForm, &SshConnectionForm::connected, this, [this]() {
        qDebug() << "[UploadConfigForm] connected() received";
        setWidgetsEnabled(true);
        setupDatabases();
    });

    connect(ui->sshConnectionForm, &SshConnectionForm::disconnected, this, [this]() {
        qDebug() << "[UploadConfigForm] disconnected() received";
        setWidgetsEnabled(false);
    });
    */

    connect(ui->loadButton, &QPushButton::clicked, this, [this]() {
        viewUpload();
        voiceClient.get(URL_PATH_DOWNLOAD);
    });

    connect(ui->saveButton, &QPushButton::clicked, this, [this]() {
        if(auto count = ui->editConfigForm->targetTable()->model()->rowCount(); count == 0) {
            QMessageBox::critical(this, "Upload error", "Target table empty");
            return;
        }

        auto jsonData = ui->editConfigForm->targetTableToJson();

        QFile file(Settings::instance().rootDataDirPath() + "/" + "json_target.txt");
        if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            qDebug() << "Error: Could not open file for writing.";
        }
        QTextStream out(&file);
        out << jsonData;
        out.flush();
        file.close();

        viewUpload();

        voiceClient.post(URL_PATH_UPLOAD, jsonData.toUtf8());

        /*
        QStringList files_pathes_list;
        QList<QVariant> file_names_from_target = ui->editConfigForm->allTargetFieldValues("file_path");
        QList<QVariant> names_from_target = ui->editConfigForm->allTargetFieldValues("name");

        for (int i = 0; i < file_names_from_target.count(); i++) {
            QVariant& file_name = file_names_from_target[i];
            QString file_path = Settings::instance().modelsDirPath()+"/"+file_name.toString();

            if (QFile::exists(file_path)) {;
                files_pathes_list.append(file_path);
            } else {
                QString model_name = names_from_target[i].toString();
                QMessageBox::critical(this, "Upload error", "Cannot find model " + model_name);
                setWidgetsEnabled(true);
                return;
            };
        }
        QString config_db_path = Settings::instance().rootDataDirPath()+"/"+Settings::instance().remoteConfigDbName();
        files_pathes_list.append(config_db_path);
        ui->sshConnectionForm->uploadNewConfigFiles(files_pathes_list);
        */

    });

    connect(ui->sshConnectionForm, &SshConnectionForm::uploadProgress,
            this, [this](qint64 sent, qint64 total) {
                const int scaleMax = 1000;
                int scaledSent = static_cast<int>((sent * scaleMax) / total);
                ui->progressBar->setMaximum(scaleMax);
                ui->progressBar->setValue(scaledSent);
                ui->progressBar->setEnabled(true);
                setWidgetsEnabled(false);
            });

    connect(ui->sshConnectionForm, &SshConnectionForm::uploadFinished,
            this, [this]() {
                qDebug() << "[uploadFinished]";
                ui->progressBar->setValue(0);
                ui->progressBar->setEnabled(false);
                ui->editConfigForm->setEnabled(true);
                setWidgetsEnabled(true);
            });

    connect(ui->sshConnectionForm, &SshConnectionForm::uploadFailed,
            this, [this](const QString& file, const QString& reason) {
                ui->progressBar->setValue(0);
                ui->progressBar->setEnabled(false);
                setWidgetsEnabled(true);
                QMessageBox::critical(this, "Upload failed", QString("%1: %2").arg(file, reason));

            });

    timerUploadReady = new QTimer(this);
    QObject::connect(timerUploadReady, &QTimer::timeout, this, &UploadConfigForm::checkUploadReady);
    timerUploadReady->start(1000);
}

void UploadConfigForm::applyUploadpReady(HttpClient::RequestType reguestType, QString urlPath, int statusCode, const QByteArray &data) {
    if(statusCode != 200) return;

    QJsonObject resultJson;
    parseJsonToObj(data, resultJson);
    bool ready = resultJson.value("upload_ready").toString() == "upload_ready" ? true : false;
    this->setDisabled(!ready);

    if(!ready) doOnce.reset();
    if(ready) doOnce([this](){ viewUpload();}, [this](const QString& arg){voiceClient.get(arg);}, URL_PATH_DOWNLOAD);
}

void UploadConfigForm::applyUploadpError(HttpClient::RequestType reguestType, QString urlPath, QNetworkReply::NetworkError error) {
    this->setDisabled(true);
}

void UploadConfigForm::checkUploadReady() {
        stateUploadClient.get(URL_PATH_UPLOAD);
}

void UploadConfigForm::sendFile(const int targetRow) {
    auto index = ui->editConfigForm->targetTable()->model()->index(targetRow, targetCol);
    auto filename = ui->editConfigForm->targetTable()->model()->data(index, Qt::DisplayRole).toString();

    QFile file(Settings::instance().deviceAudioDirPath() + "/" + filename);
    if (!file.open(QIODevice::ReadOnly)) {
        QMessageBox::critical(this, "Upload error", "Error while read voice.");
        viewAddingTargets();
        return;
    }
    QByteArray fileData = file.readAll();
    file.close();

    voiceClient.postFile(URL_PATH_UPLOAD_FILE, QString::number(targetRow), filename, fileData);
}

void UploadConfigForm::receiveFile(const int targetRow) {
    auto index = ui->editConfigForm->targetTable()->model()->index(targetRow, targetCol);
    auto filename = ui->editConfigForm->targetTable()->model()->data(index, Qt::DisplayRole).toString();

    voiceClient.get(QString(URL_PATH_DOWNLOAD_FILE + filename));

    /*
    QFile file(Settings::instance().rootDataDirPath() + "/" + Settings::instance().audioDirName() + "/" + filename);
    if (!file.open(QIODevice::ReadOnly)) {
        QMessageBox::critical(this, "Upload error", "Error while read voice.");
        viewAddingTargets();
        return;
    }
    QByteArray fileData = file.readAll();
    file.close();

    voiceClient.postFile(URL_PATH_UPLOAD_FILE, QString::number(targetRow), filename, fileData);
    */
}

template<typename T>
void UploadConfigForm::setViewState(T* t) {
    if(t->rowCount() == 0) {
        viewStart();
    } else {
        viewAddingTargets();
    }
}

UploadConfigForm::~UploadConfigForm()
{
    delete ui;
}

void UploadConfigForm::setWidgetsEnabled(bool enabled)
{
    ui->editConfigForm->setEnabled(enabled);
    ui->saveButton->setEnabled(enabled);
    ui->loadButton->setEnabled(enabled);
}

void UploadConfigForm::viewDisable() {
    ui->editConfigForm->setEnabled(false);
    ui->saveButton->setEnabled(false);
    ui->loadButton->setEnabled(false);
}

void UploadConfigForm::viewEnable() {
    ui->editConfigForm->setEnabled(true);
    ui->saveButton->setEnabled(true);
    ui->loadButton->setEnabled(true);
}

void UploadConfigForm::viewStart() {
    ui->editConfigForm->setEnabled(true);
    ui->saveButton->setEnabled(false);
    ui->loadButton->setEnabled(true);
}

void UploadConfigForm::viewAddingTargets() {
    ui->editConfigForm->setEnabled(true);
    ui->saveButton->setEnabled(true);
    ui->loadButton->setEnabled(true);
}

void UploadConfigForm::viewUpload() {
    ui->saveButton->setEnabled(false);
    ui->loadButton->setEnabled(false);
    ui->editConfigForm->setEnabled(false);
}

void UploadConfigForm::setupDatabases()
{
    // const QString sourceConn = "source_db";
    const QString targetConn = "target_db";

    /*
    if (QSqlDatabase::contains(sourceConn)) {
        QSqlDatabase db = QSqlDatabase::database(sourceConn);
        if (db.isOpen()) db.close();
        QSqlDatabase::removeDatabase(sourceConn);
    }
    */

    if (QSqlDatabase::contains(targetConn)) {
        QSqlDatabase db = QSqlDatabase::database(targetConn);
        if (db.isOpen()) db.close();
        QSqlDatabase::removeDatabase(targetConn);
    }

    // QSqlDatabase db1 = QSqlDatabase::addDatabase("QSQLITE", sourceConn);
    // db1.setDatabaseName(Settings::instance().databasePath());

    QSqlDatabase db2 = QSqlDatabase::addDatabase("QSQLITE", targetConn);
    db2.setDatabaseName(Settings::instance().rootDataDirPath() + "/" + Settings::instance().remoteConfigDbName());

    /*
    if (db1.open() && db2.open()) {
        QSqlQuery stmt(ModelsRepo::stmt(), db2);
        stmt.exec();
    } else {
        qWarning() << "Cannot open target or source database";
    }
    */

    if (db2.open()) {
        QSqlQuery stmt(VoiceSampleRepo::stmt(), db2);
        stmt.exec();
    } else {
        qWarning() << "Cannot open target or source database db2";
    }

    auto db1 = DatabaseService::instance().database_instance();
    ui->editConfigForm->setSourceDatabaseTable(db1, VoiceSampleRepo::tablename());
    // ui->editConfigForm->setSourceDatabaseTable(db1, ModelsRepo::tablename());

    ui->editConfigForm->setTargetDatabaseTable(db2, VoiceSampleRepo::tablename());
    // ui->editConfigForm->setTargetDatabaseTable(db2, ModelsRepo::tablename());
}






