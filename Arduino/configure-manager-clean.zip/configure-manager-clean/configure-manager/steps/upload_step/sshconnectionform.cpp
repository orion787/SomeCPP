#include "sshconnectionform.hpp"
#include "ui_sshconnectionform.h"

#if !SSH_MOCKED
    #include "sshactions.hpp"
#else
    #include "mocksshactions.hpp"
#endif

#include <QFileInfo>
#include <QMessageBox>
#include <QRegularExpressionValidator>
#include <QStyle>
#include <QThread>
#include <QTimer>
#include <settings.hpp>
#include "connectionsettings.hpp"

SshConnectionForm::SshConnectionForm(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::SshConnectionForm)
{
    ui->setupUi(this);
    connect(ui->hostLineEdit, &QLineEdit::textChanged, this, [=](const QString &text) {
        static QRegularExpression ipRegex(
            R"(^(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$)"
            );

        QString trimmed = text.trimmed();
        hostIsValid = ipRegex.match(trimmed).hasMatch();

        ui->hostLineEdit->setStyleSheet(hostIsValid
                                            ? ""
                                            : "QLineEdit { border: 1px solid red; }");

        updateConnectButtonState();
    });

    auto *portValidator = new QIntValidator(1, 65535, this);
    ui->portLineEdit->setValidator(portValidator);

    connect(ui->portLineEdit, &QLineEdit::textChanged, this, [=](const QString &text) {
        int pos = 0;
        QString input = text;
        QIntValidator portValidator(1, 65535, this);
        portIsValid = (portValidator.validate(input, pos) == QValidator::Acceptable);

        ui->portLineEdit->setStyleSheet(portIsValid
                                            ? ""
                                            : "QLineEdit { border: 1px solid red; }");

        updateConnectButtonState();
    });


    sshThread = new QThread(this);
    ssh = new SshActions();
    ssh->moveToThread(sshThread);
    sshThread->start();

    // connect(ssh, &SshActions::uploadTotalProgress, this, [=](qint64 sent, qint64 total) {
    //     QMetaObject::invokeMethod(this, [=]() {
    //         const int scaleMax = 1000;
    //         int scaledSent = static_cast<int>((sent * scaleMax) / total);
    //         ui->progressBar->setMaximum(scaleMax);
    //         ui->progressBar->setValue(scaledSent);
    //         ui->progressBar->setEnabled(true);
    //     }, Qt::QueuedConnection);
    // });

    // connect(ssh, &SshActions::uploadTotalFinished, this, [=]() {
    //     emit uploaded();
    //     ui->connectButton->setEnabled(true);
    //     ssh->executeCommand(Settings::instance().postUploadCommand());
    // });

    // connect(ssh, &SshActions::uploadFailed, this, [this](const QString &file, const QString &reason) {
    //     QMessageBox::critical(this, "Upload failed", QString("%1: %2").arg(file, reason));
    //     ui->progressBar->setValue(0);
    //     ui->connectButton->setEnabled(true);
    // });

    connect(ssh, &SshActions::connectionCancelled, this, [this]() {
        qDebug() << "[SshConnectionForm] connectionCancelled received";
        connectionState = Disconnected;
        updateButtonText();
    });

    connect(ui->connectButton, &QPushButton::clicked,
            this, &SshConnectionForm::onConnectButtonClicked);

    connect(ssh, &SshActions::connected, this, [this]() {
        connectionState = Connected;
        updateButtonText();
        createDirs();
        downloadRemoteTargetConfigDb();
        // ConnectionSettings::instance().setIp(ui->hostLineEdit->text());
        // ConnectionSettings::instance().setPort(ui->portLineEdit->text().toInt());
        // ConnectionSettings::instance().setUsername(ui->usernameLineEdit->text());
        // ConnectionSettings::instance().setPassword(ui->passwordLineEdit->text());
        this->ignoreWarns = false;
        emit connected();

    });

    connect(ssh, &SshActions::disconnected, this, [this]() {
        connectionState = Disconnected;
        updateButtonText();
        emit disconnected();
    });

    connect(ssh, &SshActions::connectionFailed, this, [this](const QString &reason) {

        qDebug() << "[SshConnectionForm] connectionFailed received:" << reason;
        connectionState = Disconnected;
        updateButtonText();
        if (this->ignoreWarns) {
            return;
        }
        QTimer::singleShot(0, this, [this, reason]() {
            QMessageBox::critical(this, "Connection Failed", reason);
        });
    });

    connect(ssh, &SshActions::uploadTotalProgress, this, [=](qint64 sent, qint64 total) {
        emit uploadProgress(sent, total);
    });

    connect(ssh, &SshActions::uploadTotalFinished, this, [=]() {
        emit uploadFinished();

        ui->connectButton->setEnabled(true);

        ssh->executeCommand(Settings::instance().postUploadCommand());

        QMessageBox::information(this, "Config uploaded", "Config uploaded succefully");
    });

    connect(ssh, &SshActions::uploadFailed, this, [=](const QString &file, const QString &reason) {
        emit uploadFailed(file, reason);
    });

    connect(this, &QObject::destroyed, ssh, &SshActions::deleteLater);
    connect(sshThread, &QThread::finished, sshThread, &QThread::deleteLater);

    updateButtonText();
}


void SshConnectionForm::updateConnectButtonState()
{
    ui->connectButton->setEnabled(hostIsValid && portIsValid && connectionState == Disconnected);
}

SshConnectionForm::~SshConnectionForm()
{
    if (ssh) {
        QMetaObject::invokeMethod(ssh, "disconnect", Qt::QueuedConnection);

        sshThread->quit();
        sshThread->wait();

        ssh->deleteLater();
    }

    delete ui;
}

void SshConnectionForm::onConnectButtonClicked()
{
    const QString host = ui->hostLineEdit->text();
    const QString user = ui->usernameLineEdit->text();
    const QString pass = ui->passwordLineEdit->text();
    int port = ui->portLineEdit->text().toInt();

    switch (connectionState) {
    case Disconnected:
        connectionState = Connecting;
        updateButtonText();
        ssh->connectAsync(host, port, user, pass);
        break;
    case Connecting:
    case Connected:
        ssh->disconnect();
        break;
    }
}

void SshConnectionForm::createDirs()
{
    QString result = ssh->executeCommand("mkdir " + Settings::instance().remoteConfigDirPath());
    if (result.isEmpty()) {
        qDebug() << "Directory created or already exists.";
    } else {
        qDebug() << "mkdir output:" << result;
    }
}

void SshConnectionForm::downloadRemoteTargetConfigDb()
{
    removeOldDownloadedConfig();
    QStringList files_in_dir = ssh->listRemoteDirectory(Settings::instance().remoteConfigDirPath());
    for (QString file_name: files_in_dir) {
        if (file_name == Settings::instance().remoteConfigDbName()) {
            ssh->downloadFile(Settings::instance().remoteConfigDirPath()+"/"+Settings::instance().remoteConfigDbName(),
                              Settings::instance().rootDataDirPath()+"/"+Settings::instance().remoteConfigDbName());
        }
    }
}

void SshConnectionForm::removeOldDownloadedConfig()
{
    QFile target_downloaded_db_file(Settings::instance().rootDataDirPath()+"/"+Settings::instance().remoteConfigDbName());
    if (target_downloaded_db_file.exists()) {
        target_downloaded_db_file.remove();
    }
}

void SshConnectionForm::tryConnectOnShow()
{
    this->ignoreWarns = true;
    ui->connectButton->click();
}

void SshConnectionForm::setVisibleIp(bool visible)
{
    ui->hostLineEdit->setVisible(visible);
}

void SshConnectionForm::setVisiblePort(bool visible)
{
    ui->portLineEdit->setVisible(visible);
}

void SshConnectionForm::setVisibleUsername(bool visible)
{
    ui->usernameLineEdit->setVisible(visible);
}

void SshConnectionForm::setVisiblePassword(bool visible)
{
    ui->passwordLineEdit->setVisible(visible);
}

void SshConnectionForm::setIp(QString ip) {
    ui->hostLineEdit->setText(ip);
    emit ui->hostLineEdit->textEdited(ui->hostLineEdit->text());
}

void SshConnectionForm::setPort(uint port) {
    ui->portLineEdit->setText(QString::number(port));
    emit ui->portLineEdit->textEdited(ui->portLineEdit->text());
}

void SshConnectionForm::setUsername(QString username) {
    ui->usernameLineEdit->setText(username);
    emit ui->usernameLineEdit->textEdited(ui->usernameLineEdit->text());
}

void SshConnectionForm::setPassword(QString password) {
    ui->passwordLineEdit->setText(password);
    emit ui->passwordLineEdit->textEdited(ui->passwordLineEdit->text());
}


void SshConnectionForm::showEvent(QShowEvent *event)
{
    static bool first_show = true;
    if (first_show) {
        tryConnectOnShow();
        first_show = false;
    }
}

void SshConnectionForm::setVisibleSshCredsLineEdits(bool visible)
{
    setVisibleIp(visible);
    setVisiblePort(visible);
    setVisibleUsername(visible);
    setVisiblePassword(visible);
}

void SshConnectionForm::removeOldRemoveConfigFiles()
{
    QString result = ssh->executeCommand("rm "+Settings::instance().remoteConfigDirPath()+"/*");
    if (result.isEmpty()) {
        qDebug() << "Directory created or already exists.";
    } else {
        qDebug() << "mkdir output:" << result;
    }
}

void SshConnectionForm::uploadNewConfigFiles(QStringList filesDirs)
{
    if (connectionState != Connected) {
        QMessageBox::warning(this, "SSH", "SSH connection not established.");
        return;
    }

    ui->connectButton->setEnabled(false);

    qDebug() << "[uploadNewConfigFiles] running preUploadCommand...";
    QString preOutput = ssh->executeCommand(Settings::instance().preUploadCommand());
    qDebug() << "[preUploadCommand output]: " << preOutput;

    removeOldRemoveConfigFiles();

    qDebug() << "[uploadNewConfigFiles] starting async upload...";
    ssh->uploadFilesAsync(
        filesDirs,
        Settings::instance().remoteConfigDirPath()
        );
}

void SshConnectionForm::updateButtonText()
{
    switch (connectionState) {
    case Disconnected:
        ui->connectButton->setText("Connect");
        ui->statusLabel->setText("Disconnected");
        ui->statusLabel->setStyleSheet("QLabel { color : red; }");
        break;
    case Connecting:
        ui->connectButton->setText("Stop");
        ui->statusLabel->setText("Trying to connect");
        ui->statusLabel->setStyleSheet("QLabel { color : orange; }");
        break;
    case Connected:
        ui->connectButton->setText("Disconnect");
        ui->statusLabel->setText("Connected");
        ui->statusLabel->setStyleSheet("QLabel { color : green; }");
        break;
    }

    updateFormEnabledState();
}

void SshConnectionForm::updateFormEnabledState()
{
    bool editable = (connectionState == Disconnected);

    ui->hostLineEdit->setEnabled(editable);
    ui->portLineEdit->setEnabled(editable);
    ui->usernameLineEdit->setEnabled(editable);
    ui->passwordLineEdit->setEnabled(editable);
}
