#include "abstracttableeditorwidget.hpp"
