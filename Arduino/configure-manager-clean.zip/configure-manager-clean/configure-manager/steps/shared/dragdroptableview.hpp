#pragma once
#include "QTableViewWithTooltip.hpp"

#include <QTableView>
#include <QDropEvent>
#include <QSqlRecord>
#include <QAbstractItemModel>
#include <QMimeData>
#include <QSqlField>

class DragDropTableView : public QTableViewWithTooltip {
    Q_OBJECT
public:
    using QTableViewWithTooltip::QTableViewWithTooltip;
    void dropEvent(QDropEvent *event);
    void setMaxRowCount(int count);
    int maxRowCount() const;
private:
    int m_maxRowCount = 0;
signals:
    void droppedRecord(const QSqlRecord&, DragDropTableView* table);
};
