#ifndef NAMEVALIDATORDELEGATE_HPP
#define NAMEVALIDATORDELEGATE_HPP

#include <QLineEdit>
#include <QMessageBox>
#include <QObject>
#include <QSqlTableModel>
#include <QStyledItemDelegate>

class NameValidatorDelegate : public QStyledItemDelegate {
public:
    NameValidatorDelegate(QObject *parent = nullptr, QSqlTableModel *model = nullptr)
        : QStyledItemDelegate(parent), model(model) {}

    QWidget *createEditor(QWidget *parent, const QStyleOptionViewItem &option,
                          const QModelIndex &index) const override
    {
        QLineEdit *editor = new QLineEdit(parent);

        if (index.column() == 1) {
            editor->setPlaceholderText("Name required");
            editor->setValidator(new QRegularExpressionValidator(QRegularExpression(".+"), editor));
        } else {
            editor->setPlaceholderText("Description");
        }

        return editor;
    }

    void setModelData(QWidget *editor, QAbstractItemModel *model,
                      const QModelIndex &index) const override
    {
        QLineEdit *lineEdit = qobject_cast<QLineEdit *>(editor);
        if (!lineEdit)
            return;

        QString value = lineEdit->text().trimmed();

        if (index.column() == 1) {
            if (value.isEmpty()) {
                QMessageBox::warning(nullptr, "Error", "Name can not be empty");
                return;
            }

            QString currentId = model->data(model->index(index.row(), 0)).toString();
            for (int row = 0; row < model->rowCount(); ++row) {
                if (row == index.row()) continue;

                QString otherName = model->data(model->index(row, 1)).toString();
                if (otherName == value) {
                    QMessageBox::warning(nullptr, "Error", "Name is not unique");
                    return;
                }
            }
        }

        model->setData(index, value);
    }

private:
    QSqlTableModel *model;
};

#endif // NAMEVALIDATORDELEGATE_HPP
