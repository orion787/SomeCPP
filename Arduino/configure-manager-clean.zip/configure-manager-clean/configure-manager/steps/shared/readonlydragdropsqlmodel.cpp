#include "readonlydragdropsqlmodel.hpp"
#include <QDataStream>
#include <QSqlField>
#include <QDebug>
#include <QIODevice>
#include <QSqlRecord>

Qt::ItemFlags ReadOnlyDragDropSqlModel::flags(const QModelIndex& index) const {
    Qt::ItemFlags f = QSqlTableModel::flags(index);
    f &= ~Qt::ItemIsEditable; // убираем редактирование
    if (index.isValid())
        f |= Qt::ItemIsDragEnabled;  // разрешаем перетаскивание
    else
        f |= Qt::ItemIsDropEnabled;  // только визуально, drop не обрабатывается
    return f;
}

Qt::DropActions ReadOnlyDragDropSqlModel::supportedDropActions() const {
    return Qt::CopyAction | Qt::MoveAction;
}

QStringList ReadOnlyDragDropSqlModel::mimeTypes() const {
    return { "application/x-qsqlrecord-row" };
}

QMimeData* ReadOnlyDragDropSqlModel::mimeData(const QModelIndexList& indexes) const {
    if (indexes.isEmpty()) return nullptr;

    qDebug() << "[ReadOnlyDragDropSqlModel] Creating mimeData for drag";

    QMimeData* mime = new QMimeData;
    QByteArray encoded;
    QDataStream stream(&encoded, QIODevice::WriteOnly);

    QSet<int> rows;
    for (const QModelIndex& idx : indexes)
        rows.insert(idx.row());

    for (int row : rows) {
        stream << row;
        QSqlRecord rec = record(row);
        stream << rec.count();
        for (int i = 0; i < rec.count(); ++i) {
            stream << rec.fieldName(i);
            stream << rec.value(i);
        }
    }

    mime->setData("application/x-qsqlrecord-row", encoded);
    return mime;
}

bool ReadOnlyDragDropSqlModel::dropMimeData(const QMimeData*, Qt::DropAction, int, int, const QModelIndex&) {
    return false;
}


