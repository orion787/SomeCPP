#ifndef EDITABLESQLTABLEMODEL_HPP
#define EDITABLESQLTABLEMODEL_HPP

#include <QObject>
#include <QSqlTableModel >

class AbstractTableEditorWidget;

class EditableSqlTableModel : public QSqlTableModel {
    Q_OBJECT
public:
    EditableSqlTableModel(QObject* parent, AbstractTableEditorWidget* editor);

    Qt::ItemFlags flags(const QModelIndex& index) const override;

private:
    AbstractTableEditorWidget* editorWidget;
};

#endif // EDITABLESQLTABLEMODEL_HPP
