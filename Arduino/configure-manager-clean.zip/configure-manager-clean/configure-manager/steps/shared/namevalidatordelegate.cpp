#include "namevalidatordelegate.hpp"

