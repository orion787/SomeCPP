#include "deletebuttondelegate.hpp"
#include "mainform.hpp"
#include "ui_mainform.h"

#include <QSqlTableModel>
#include <QSortFilterProxyModel>
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QLineEdit>
#include <QStyledItemDelegate>
#include <QSortFilterProxyModel>
#include <databaseservice.hpp>

class NameValidatorDelegate : public QStyledItemDelegate {
public:
    NameValidatorDelegate(QObject *parent = nullptr, QSqlTableModel *model = nullptr)
        : QStyledItemDelegate(parent), model(model) {}

    QWidget *createEditor(QWidget *parent, const QStyleOptionViewItem &option,
                          const QModelIndex &index) const override
    {
        QLineEdit *editor = new QLineEdit(parent);

        if (index.column() == 1) { // name
            editor->setPlaceholderText("Name required");
            editor->setValidator(new QRegularExpressionValidator(QRegularExpression(".+"), editor));
        } else {
            editor->setPlaceholderText("Description");
        }

        return editor;
    }

    void setModelData(QWidget *editor, QAbstractItemModel *model,
                      const QModelIndex &index) const override
    {
        QLineEdit *lineEdit = qobject_cast<QLineEdit *>(editor);
        if (!lineEdit)
            return;

        QString value = lineEdit->text().trimmed();

        if (index.column() == 1) { // name
            if (value.isEmpty()) {
                QMessageBox::warning(nullptr, "Error", "Name can not be empty");
                return;
            }

            QString currentId = model->data(model->index(index.row(), 0)).toString();
            for (int row = 0; row < model->rowCount(); ++row) {
                if (row == index.row()) continue;

                QString otherName = model->data(model->index(row, 1)).toString();
                if (otherName == value) {
                    QMessageBox::warning(nullptr, "Error", "Name is not unique");
                    return;
                }
            }
        }

        model->setData(index, value);
    }

private:
    QSqlTableModel *model;
};

// -- MainForm ---------------------------------------------------------------------

MainForm::MainForm(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::MainForm)
    , sqlModel(new QSqlTableModel(this, DatabaseService::instance().database_instance()))
    , proxyModel(new QSortFilterProxyModel(this))
{
    ui->setupUi(this);
    setupConnections();
}

MainForm::~MainForm()
{
    delete ui;
}

void MainForm::showEvent(QShowEvent *event)
{
    setupModel();
    replaceTitlesFromSnakeCase();
    setupTableView();
}

void MainForm::setupModel()
{
    sqlModel->setTable("models");
    sqlModel->setEditStrategy(QSqlTableModel::OnFieldChange);
    sqlModel->select();
}

void MainForm::replaceTitlesFromSnakeCase()
{
    int columnCount = sqlModel->columnCount();

    for (int col = 0; col < columnCount; ++col) {
        QString originalHeader = sqlModel->headerData(col, Qt::Horizontal).toString();

        QStringList words = originalHeader.split('_');
        for (QString &word : words) {
            word[0] = word[0].toUpper();
        }
        QString formattedHeader = words.join(' ');

        sqlModel->setHeaderData(col, Qt::Horizontal, formattedHeader);
    }
}

void MainForm::setupTableView()
{
    proxyModel->setSourceModel(sqlModel);
    proxyModel->setFilterKeyColumn(1);
    proxyModel->setFilterCaseSensitivity(Qt::CaseInsensitive);

    ui->modelsTableView->setModel(proxyModel);
    ui->modelsTableView->setItemDelegate(new NameValidatorDelegate(this, sqlModel));
    ui->modelsTableView->setSortingEnabled(true);
    ui->modelsTableView->hideColumn(0);

    ui->modelsTableView->horizontalHeader()->setStretchLastSection(true);
    ui->modelsTableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->modelsTableView->verticalHeader()->setHidden(true);

    int deleteColumn = sqlModel->columnCount() - 1; // use last column

    ui->modelsTableView->setColumnHidden(deleteColumn, false);
    ui->modelsTableView->setColumnWidth(deleteColumn, 60);

    auto deleteDelegate = new DeleteButtonDelegate(this);
    ui->modelsTableView->setItemDelegateForColumn(deleteColumn, deleteDelegate);

    connect(deleteDelegate, &DeleteButtonDelegate::deleteRequested, this, &MainForm::handleDeleteClicked);
}

void MainForm::setupConnections()
{
    connect(ui->searchLineEdit, &QLineEdit::textChanged, this, [this](const QString &text) {
        proxyModel->setFilterFixedString(text);
    });
}

void MainForm::handleDeleteClicked(const QModelIndex &proxyIndex)
{
    QModelIndex sourceIndex = proxyModel->mapToSource(proxyIndex);
    int id = sqlModel->data(sqlModel->index(sourceIndex.row(), 0)).toInt();
    DatabaseService::instance().models->deleteModel(id);
    sqlModel->select();
}
