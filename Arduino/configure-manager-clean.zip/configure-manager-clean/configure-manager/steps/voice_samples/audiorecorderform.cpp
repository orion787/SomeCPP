#include "audiorecorderform.hpp"
#include "ui_audiorecorderform.h"
#include <QFileDialog>
#include <QDateTime>
#include <QMessageBox>
#include <QDebug>

AudioRecorderForm::AudioRecorderForm(QWidget* parent)
    : QWidget(parent), ui(new Ui::AudioRecorderForm)
{
    ui->setupUi(this);
    Pa_Initialize();
    ui->startButton->setEnabled(false);

    int numDevices = Pa_GetDeviceCount();
    for (int i = 0; i < numDevices; ++i) {
        const PaDeviceInfo* info = Pa_GetDeviceInfo(i);
        if (info->maxInputChannels > 0) {
            QString name = QString::fromUtf8(info->name);
            ui->deviceComboBox->addItem(name, i);
        }
    }
    if (ui->deviceComboBox->currentData().isValid()) {
        ui->startButton->setEnabled(true);
    }

    connect(ui->startButton, &QPushButton::clicked, this, &AudioRecorderForm::onStartClicked);
    connect(ui->stopButton, &QPushButton::clicked, this, &AudioRecorderForm::onStopClicked);
    connect(ui->selectDirButton, &QPushButton::clicked, this, &AudioRecorderForm::onSelectDirClicked);
    connect(&timeUpdateTimer, &QTimer::timeout, this, &AudioRecorderForm::updateDurationLabel);
    connect(ui->deviceComboBox, &QComboBox::currentIndexChanged, this, [this]() {
        ui->startButton->setEnabled(true);
    });
    timeUpdateTimer.setInterval(1000);



    ui->stopButton->setEnabled(false);

    plotTimer.setInterval(50);
    connect(&plotTimer, &QTimer::timeout, this, &AudioRecorderForm::updatePlot);
    ui->plotWidget->addGraph();

    QCustomPlot* plot = ui->plotWidget;

    // Background and axis
    plot->setBackground(QColor("#121212"));
    plot->xAxis->setBasePen(QPen(QColor("#888")));
    plot->yAxis->setBasePen(QPen(QColor("#888")));
    plot->xAxis->setTickPen(QPen(QColor("#888")));
    plot->yAxis->setTickPen(QPen(QColor("#888")));
    plot->xAxis->setSubTickPen(QPen(QColor("#555")));
    plot->yAxis->setSubTickPen(QPen(QColor("#555")));
    plot->xAxis->setTickLabelColor(QColor("#ffffff"));
    plot->yAxis->setTickLabelColor(QColor("#ffffff"));
    plot->xAxis->setLabelColor(QColor("#ffffff"));
    plot->yAxis->setLabelColor(QColor("#ffffff"));

    // Grid
    plot->xAxis->grid()->setPen(QPen(QColor("#2a2a2a")));
    plot->yAxis->grid()->setPen(QPen(QColor("#2a2a2a")));
    plot->xAxis->grid()->setSubGridPen(QPen(QColor("#1e1e1e")));
    plot->yAxis->grid()->setSubGridPen(QPen(QColor("#1e1e1e")));
    plot->xAxis->grid()->setSubGridVisible(true);
    plot->yAxis->grid()->setSubGridVisible(true);

    // Border and text
    plot->legend->setVisible(false);
    plot->axisRect()->setBackground(QColor("#121212"));
    plot->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

    // Graph line
    plot->graph(0)->setPen(QPen(QColor("#1db954"), 2));

    plot->xAxis2->setVisible(true);
    plot->yAxis2->setVisible(true);

    plot->xAxis->setTicks(false);
    plot->xAxis->setTickLabels(false);
    plot->yAxis->setTicks(false);
    plot->yAxis->setTickLabels(false);

    plot->xAxis2->setTicks(false);
    plot->xAxis2->setTickLabels(false);
    plot->yAxis2->setTicks(false);
    plot->yAxis2->setTickLabels(false);

    plot->xAxis2->setBasePen(QPen(QColor("#888")));
    plot->yAxis2->setBasePen(QPen(QColor("#888")));
}

AudioRecorderForm::~AudioRecorderForm()
{
    if (isRecording) {
        Pa_StopStream(stream);
        Pa_CloseStream(stream);
    }
    Pa_Terminate();
    delete ui;
}

void AudioRecorderForm::updateDurationLabel()
{
    int seconds = recordingTime.elapsed() / 1000;
    int minutes = seconds / 60;
    seconds = seconds % 60;

    ui->durationLabel->setText(QString("%1:%2")
                                   .arg(minutes, 2, 10, QChar('0'))
                                   .arg(seconds, 2, 10, QChar('0')));
}

void AudioRecorderForm::setOutputDirectory(const QString& dir)
{
    outputDirectory = dir;
}

QString AudioRecorderForm::getOutputDirectory() const
{
    return outputDirectory;
}

void AudioRecorderForm::setSelectDirVisible(bool enabled)
{
    ui->selectDirButton->setVisible(enabled);
}

bool AudioRecorderForm::selectDirVisible()
{
    return ui->selectDirButton->isVisible();
}

void AudioRecorderForm::setSampleRate(uint rate)
{
    m_sampleRate = rate;
}

uint AudioRecorderForm::sampleRate()
{
    return m_sampleRate;
}

void AudioRecorderForm::setNumChannels(uint numChannels)
{
    m_numChannels = numChannels;
}

uint AudioRecorderForm::numChannels()
{
    return m_numChannels;
}



void AudioRecorderForm::onSelectDirClicked()
{
    QString dir = QFileDialog::getExistingDirectory(this, "Select Output Directory");
    if (!dir.isEmpty()) {
        setOutputDirectory(dir);
    }
}

void AudioRecorderForm::onStartClicked()
{
    if (outputDirectory.isEmpty()) {
        QMessageBox::warning(this, "Output Directory", "Please select an output directory first.");
        return;
    }

    if (!ui->deviceComboBox->currentData().isValid()) {
        QMessageBox::warning(this, "Device not selected", "Please select a device first.");
    }
    int deviceIndex = ui->deviceComboBox->currentData().toInt();
    if (deviceIndex < 0) return;

    QString fileName = QString("recording_%1.wav").arg(QDateTime::currentDateTime().toString("yyyy-MM-dd_HH-mm-ss"));
    wavFile.setFileName(outputDirectory + "/" + fileName);
    if (!wavFile.open(QIODevice::WriteOnly)) {
        QMessageBox::critical(this, "Error", "Can't open file for writing");
        return;
    }

    writeWavHeader();

    PaStreamParameters inputParams;
    inputParams.device = deviceIndex;
    inputParams.channelCount = m_numChannels;
    inputParams.sampleFormat = sampleFormat;
    inputParams.suggestedLatency = Pa_GetDeviceInfo(deviceIndex)->defaultLowInputLatency;
    inputParams.hostApiSpecificStreamInfo = nullptr;

    PaError err = Pa_OpenStream(&stream, &inputParams, nullptr, m_sampleRate, framesPerBuffer,
                                paClipOff, &AudioRecorderForm::recordCallback, this);
    if (err != paNoError) {
        QMessageBox::critical(this, "Error", QString("Failed to open stream: %1").arg(Pa_GetErrorText(err)));
        return;
    }

    Pa_StartStream(stream);
    isRecording = true;
    audioBuffer.clear();
    plotTimer.start();

    recordingTime.start();
    timeUpdateTimer.start();

    emit recordingStart();

    ui->startButton->setEnabled(false);
    ui->stopButton->setEnabled(true);
}

void AudioRecorderForm::onStopClicked()
{
    if (!isRecording) return;

    Pa_StopStream(stream);
    Pa_CloseStream(stream);
    stream = nullptr;

    finalizeWavHeader();
    wavFile.close();
    timeUpdateTimer.stop();
    isRecording = false;
    plotTimer.stop();

    emit recordingStop();

    QDir baseDir(QCoreApplication::applicationDirPath());

    QString relativePath = baseDir.relativeFilePath(wavFile.fileName());

    emit recordedAudioSaved(relativePath);

    ui->startButton->setEnabled(true);
    ui->stopButton->setEnabled(false);


}

int AudioRecorderForm::recordCallback(const void* input, void*, unsigned long frameCount,
                                      const PaStreamCallbackTimeInfo*, PaStreamCallbackFlags, void* userData)
{
    AudioRecorderForm* self = static_cast<AudioRecorderForm*>(userData);
    if (self && self->isRecording && input) {
        const int16_t* samples = static_cast<const int16_t*>(input);
        self->wavFile.write(reinterpret_cast<const char*>(samples), frameCount * sizeof(int16_t));

        for (unsigned long i = 0; i < frameCount; ++i)
            self->audioBuffer.append(samples[i] / 32768.0); // Normalize to [-1, 1]

        if (self->audioBuffer.size() > 2048)
            self->audioBuffer = self->audioBuffer.mid(self->audioBuffer.size() - 2048);
    }
    return paContinue;
}

void AudioRecorderForm::writeWavHeader()
{
    QByteArray header(44, 0);
    wavFile.write(header);
}

void AudioRecorderForm::finalizeWavHeader()
{
    qint64 fileSize = wavFile.size();
    qint64 dataSize = fileSize - 44;

    wavFile.seek(0);
    QByteArray header;
    QDataStream s(&header, QIODevice::WriteOnly);
    s.setByteOrder(QDataStream::LittleEndian);

    s.writeRawData("RIFF", 4);
    s << quint32(fileSize - 8);
    s.writeRawData("WAVE", 4);

    s.writeRawData("fmt ", 4);
    s << quint32(16);
    s << quint16(1);
    s << quint16(m_numChannels);
    s << quint32(m_sampleRate);
    quint32 byteRate = m_sampleRate * m_numChannels * sizeof(int16_t);
    quint16 blockAlign = m_numChannels * sizeof(int16_t);
    s << byteRate;
    s << blockAlign;
    s << quint16(16);

    s.writeRawData("data", 4);
    s << quint32(dataSize);

    wavFile.write(header);
}

void AudioRecorderForm::updatePlot()
{
    QVector<double> x(audioBuffer.size());
    for (int i = 0; i < x.size(); ++i)
        x[i] = i;

    ui->plotWidget->graph(0)->setData(x, audioBuffer);
    ui->plotWidget->xAxis->setRange(0, x.size());
    ui->plotWidget->yAxis->setRange(-1, 1);
    ui->plotWidget->replot();
}
