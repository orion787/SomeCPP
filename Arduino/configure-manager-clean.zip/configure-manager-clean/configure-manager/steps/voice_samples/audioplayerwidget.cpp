#include "audioplayerwidget.hpp"
#include "clickableslider.hpp"
#include <QPushButton>
#include <QSlider>
#include <QLabel>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QStyle>
#include <QFileInfo>
#include <QShortcut>

AudioPlayerWidget::AudioPlayerWidget(QWidget *parent)
    : QWidget(parent),
    player(new QMediaPlayer(this)),
    audioOutput(new QAudioOutput(this)),
    currentTimeLabel(new QLabel("0:00", this)),
    totalTimeLabel(new QLabel("0:00", this))
{
    player->setAudioOutput(audioOutput);

    playButton = new QPushButton(style()->standardIcon(QStyle::SP_MediaPlay), "", this);
    playButton->setFixedSize(40, 40);
    playButton->setStyleSheet(R"(
        QPushButton {
            border-radius: 20px;
        }
    )");

    QShortcut *play_shortcut = new QShortcut(QKeySequence(Qt::Key_Return), this);
    connect(play_shortcut, &QShortcut::activated, playButton, &QPushButton::click);


    playButton->setEnabled(false);

    prevButton = new QPushButton(style()->standardIcon(QStyle::SP_MediaSkipBackward), "", this);
    nextButton = new QPushButton(style()->standardIcon(QStyle::SP_MediaSkipForward), "", this);

    prevButton->setFixedSize(32, 32);
    nextButton->setFixedSize(32, 32);

    positionSlider = new ClickableSlider(Qt::Horizontal, this);
    titleLabel = new QLabel(this);
    titleLabel->setAlignment(Qt::AlignCenter);


    QHBoxLayout *controls = new QHBoxLayout;
    controls->addWidget(prevButton);
    controls->addWidget(playButton);
    controls->addWidget(nextButton);
    controls->setAlignment(Qt::AlignCenter);

    positionSlider->setEnabled(false);
    playButton->setEnabled(false);
    prevButton->setEnabled(false);
    nextButton->setEnabled(false);

    QHBoxLayout *sliderLayout = new QHBoxLayout;
    sliderLayout->addWidget(currentTimeLabel);
    sliderLayout->addWidget(positionSlider);
    sliderLayout->addWidget(totalTimeLabel);

    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(titleLabel);
    mainLayout->addLayout(sliderLayout);
    mainLayout->addLayout(controls);
    setLayout(mainLayout);

    connect(playButton, &QPushButton::clicked, this, &AudioPlayerWidget::togglePlayback);
    connect(prevButton, &QPushButton::clicked, this, &AudioPlayerWidget::requestPrevious);
    connect(nextButton, &QPushButton::clicked, this, &AudioPlayerWidget::requestNext);

    connect(player, &QMediaPlayer::positionChanged, this, &AudioPlayerWidget::updatePosition);
    connect(player, &QMediaPlayer::durationChanged, this, &AudioPlayerWidget::updateDuration);
    connect(player, &QMediaPlayer::mediaStatusChanged, this, &AudioPlayerWidget::handleMediaStatusChanged);
    connect(positionSlider, &QSlider::sliderPressed, [=]() { userIsSeeking = true; });
    connect(positionSlider, &QSlider::sliderReleased, [=]() {
        userIsSeeking = false;
        setPosition(positionSlider->value());
    });
}

void AudioPlayerWidget::setAudio(const QString &filePath, const QString &title)
{
    player->setSource(QUrl::fromLocalFile(filePath));
    titleLabel->setText(title);
    playButton->setIcon(style()->standardIcon(QStyle::SP_MediaPlay));
    playButton->setEnabled(true);

    prevButton->setEnabled(true);
    nextButton->setEnabled(true);
    positionSlider->setEnabled(true);
    player->stop();
}

void AudioPlayerWidget::togglePlayback()
{
    if (player->source().isEmpty()) {
        qWarning() << "No audio file loaded!";
        return;
    }

    if (player->playbackState() == QMediaPlayer::PlayingState) {
        player->pause();
        playButton->setIcon(style()->standardIcon(QStyle::SP_MediaPlay));
    } else {
        player->play();
        playButton->setIcon(style()->standardIcon(QStyle::SP_MediaPause));
    }
}


void AudioPlayerWidget::updatePosition(qint64 pos)
{
    if (!userIsSeeking)
        positionSlider->setValue(static_cast<int>(pos));

    QTime time(0, 0);
    currentTimeLabel->setText(time.addMSecs(pos).toString("m:ss"));
}

void AudioPlayerWidget::updateDuration(qint64 dur)
{
    positionSlider->setRange(0, static_cast<int>(dur));

    QTime time(0, 0);
    totalTimeLabel->setText(time.addMSecs(dur).toString("m:ss"));
}

void AudioPlayerWidget::setPosition(int sliderValue)
{
    player->setPosition(sliderValue);
}

void AudioPlayerWidget::handleMediaStatusChanged(QMediaPlayer::MediaStatus status)
{
    if (status == QMediaPlayer::EndOfMedia) {
        playButton->setIcon(style()->standardIcon(QStyle::SP_MediaPlay));
        emit autoRequestNext();
    }
}

void AudioPlayerWidget::play()
{
    player->play();
    playButton->setIcon(style()->standardIcon(QStyle::SP_MediaPause));
}

void AudioPlayerWidget::stop()
{
    player->stop();
    playButton->setIcon(style()->standardIcon(QStyle::SP_MediaPlay));
}

void AudioPlayerWidget::setPrevEnabled(bool enabled)
{
    prevButton->setEnabled(enabled);
}

void AudioPlayerWidget::setNextEnabled(bool enabled)
{
    nextButton->setEnabled(enabled);
}
