#include "mp3towavconverter.hpp"
#include <QDebug>
#include <QDir>
#include <QFile>
#include <QFileInfo>

#define MINIMP3_IMPLEMENTATION
#include "minimp3_ex.h"

#define DR_WAV_IMPLEMENTATION
#include "dr_wav.h"

#include <QFileInfo>
#include <QDebug>
#include "minimp3_ex.h"

int Mp3ToWavConverter::getMp3BitrateKbps(const QString& filePath)
{
    FILE* file = nullptr;

#ifdef _WIN32
    std::wstring wPath = filePath.toStdWString();
    if (_wfopen_s(&file, wPath.c_str(), L"rb") != 0 || !file) {
        qWarning() << "Failed to open file:" << filePath;
        return -1;
    }
#else
    std::string path = filePath.toStdString();
    file = fopen(path.c_str(), "rb");
    if (!file) {
        qWarning() << "Failed to open file:" << filePath;
        return -1;
    }
#endif

    // Read first 4 bytes for MP3 frame header
    unsigned char header[4];
    if (fread(header, 1, 4, file) != 4) {
        fclose(file);
        qWarning() << "Failed to read MP3 header";
        return -1;
    }

    // Check for frame sync
    if ((header[0] != 0xFF) || ((header[1] & 0xE0) != 0xE0)) {
        // Not a valid MP3 frame header
        fseek(file, 0, SEEK_SET);
    } else {
        // Try to parse bitrate from header
        static const int bitrateTable[2][16] = {
            // MPEG-1 Layer III
            {0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 0},
            // MPEG-2/2.5 Layer III
            {0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0}
        };

        bool isMpeg1 = ((header[1] & 0x08) != 0);
        int bitrateIndex = (header[2] >> 4) & 0x0F;

        int bitrate = bitrateTable[isMpeg1 ? 0 : 1][bitrateIndex];
        if (bitrate > 0) {
            fclose(file);
            return bitrate;
        }

        // If bitrate index invalid or VBR, fall through
        fseek(file, 0, SEEK_SET);
    }

    // Fallback to decode + calculate
    mp3dec_io_t io;
    io.read = [](void* buf, size_t size, void* user_data) -> size_t {
        return fread(buf, 1, size, reinterpret_cast<FILE*>(user_data));
    };
    io.seek = [](uint64_t position, void* user_data) -> int {
        return fseek(reinterpret_cast<FILE*>(user_data), static_cast<long>(position), SEEK_SET);
    };
    io.read_data = file;
    io.seek_data = file;

    mp3dec_ex_t dec;
    if (mp3dec_ex_open_cb(&dec, &io, MP3D_SEEK_TO_SAMPLE) != 0) {
        qWarning() << "Failed to parse MP3 with minimp3";
        fclose(file);
        return -1;
    }

    double duration = static_cast<double>(dec.samples) / (dec.info.hz * dec.info.channels);
    mp3dec_ex_close(&dec);
    fclose(file);

    if (duration <= 0.0)
        return -1;

    QFileInfo info(filePath);
    qint64 fileSizeBytes = info.size();

    double bitrate = (fileSizeBytes * 8.0) / 1000.0 / duration;
    return static_cast<int>(bitrate);
}

double Mp3ToWavConverter::getMp3DurationSeconds(const QString &filePath)
{
    FILE* file = nullptr;

#ifdef _WIN32
    std::wstring wPath = filePath.toStdWString();
    if (_wfopen_s(&file, wPath.c_str(), L"rb") != 0 || !file) {
        qWarning() << "Failed to open file:" << filePath;
        return -1.0;
    }
#else
    std::string path = filePath.toStdString();
    file = fopen(path.c_str(), "rb");
    if (!file) {
        qWarning() << "Failed to open file:" << filePath;
        return -1.0;
    }
#endif

    mp3dec_io_t io;
    io.read = [](void* buf, size_t size, void* user_data) -> size_t {
        return fread(buf, 1, size, reinterpret_cast<FILE*>(user_data));
    };
    io.seek = [](uint64_t position, void* user_data) -> int {
        return fseek(reinterpret_cast<FILE*>(user_data), static_cast<long>(position), SEEK_SET);
    };
    io.read_data = file;
    io.seek_data = file;

    mp3dec_ex_t dec;
    if (mp3dec_ex_open_cb(&dec, &io, MP3D_SEEK_TO_SAMPLE) != 0) {
        fclose(file);
        qWarning() << "Failed to open MP3 file";
        return -1.0;
    }

    double duration = static_cast<double>(dec.samples) / (dec.info.hz * dec.info.channels);

    mp3dec_ex_close(&dec);
    fclose(file);

    return duration;
}

static short* resampleLinear(const short* input, uint32_t inRate, size_t inFrames,
                             uint32_t outRate, size_t& outFrames)
{
    outFrames = static_cast<size_t>((inFrames * static_cast<double>(outRate)) / inRate);
    short* output = new short[outFrames];

    for (size_t i = 0; i < outFrames; ++i) {
        double srcIndex = i * static_cast<double>(inRate) / outRate;
        size_t i0 = static_cast<size_t>(srcIndex);
        size_t i1 = (i0 + 1 < inFrames) ? (i0 + 1) : (inFrames - 1);
        double frac = srcIndex - i0;

        output[i] = static_cast<short>(
            input[i0] * (1.0 - frac) + input[i1] * frac
        );
    }

    return output;
}

static size_t my_write_proc(void* pUserData, const void* pData, size_t bytesToWrite)
{
    FILE* file = reinterpret_cast<FILE*>(pUserData);
    return fwrite(pData, 1, bytesToWrite, file);
}

static size_t my_read_proc(void* pUserData, void* pBufferOut, size_t bytesToRead)
{
    FILE* file = reinterpret_cast<FILE*>(pUserData);
    return fread(pBufferOut, 1, bytesToRead, file);
}

static drwav_bool32 __cdecl my_seek_proc(void* pUserData, int offset, drwav_seek_origin origin)
{
    FILE* file = reinterpret_cast<FILE*>(pUserData);
    int seekOrigin = (origin == 0) ? SEEK_SET : SEEK_CUR;
    return fseek(file, offset, seekOrigin) == 0;
}

static drwav_bool32 my_tell_proc(void* pUserData, drwav_int64* pCursor)
{
    FILE* file = reinterpret_cast<FILE*>(pUserData);
    long pos = ftell(file);
    if (pos < 0)
        return DRWAV_FALSE;
    *pCursor = static_cast<drwav_int64>(pos);
    return DRWAV_TRUE;
}

static size_t mp3_read_cb(void* buf, size_t size, void* user_data)
{
    FILE* file = reinterpret_cast<FILE*>(user_data);
    return fread(buf, 1, size, file);
}

static int mp3_seek_cb(uint64_t position, void* user_data)
{
    FILE* file = reinterpret_cast<FILE*>(user_data);
    return fseek(file, static_cast<long>(position), SEEK_SET);
}

bool Mp3ToWavConverter::convert(const QString& inputFile,
                                const QString& outputFile,
                                uint32_t targetSampleRate,
                                uint32_t targetChannels)
{
    qDebug() << "Input file:" << inputFile;
    qDebug() << "Output file:" << outputFile;
    qDebug() << "Target sample rate:" << targetSampleRate << "Channels:" << targetChannels;

    QFileInfo outInfo(outputFile);
    QDir().mkpath(outInfo.absolutePath());

    QByteArray path = inputFile.toLower().toUtf8();
    bool isMp3 = path.endsWith(".mp3");

    short* pcm = nullptr;
    int channels = 0;
    uint32_t sampleRate = 0;
    size_t totalFrames = 0;

    if (isMp3) {
        FILE* mp3File = nullptr;
#ifdef _WIN32
        std::wstring wInPath = inputFile.toStdWString();
        if (_wfopen_s(&mp3File, wInPath.c_str(), L"rb") != 0 || !mp3File) {
            qWarning() << "FAILED: Cannot open MP3 file (Unicode path):" << inputFile;
            return false;
        }
#else
        std::string inPath = inputFile.toStdString();
        mp3File = fopen(inPath.c_str(), "rb");
        if (!mp3File) {
            qWarning() << "FAILED: Cannot open MP3 file:" << inputFile;
            return false;
        }
#endif

        mp3dec_ex_t dec;
        mp3dec_io_t io;
        io.read = mp3_read_cb;
        io.seek = mp3_seek_cb;
        io.read_data = mp3File;
        io.seek_data = mp3File;

        if (mp3dec_ex_open_cb(&dec, &io, MP3D_SEEK_TO_SAMPLE)) {
            qWarning() << "FAILED: Could not open MP3 file via callbacks:" << inputFile;
            fclose(mp3File);
            return false;
        }

        channels = dec.info.channels;
        sampleRate = dec.info.hz;
        totalFrames = dec.samples / channels;

        pcm = new short[dec.samples];
        size_t samplesRead = mp3dec_ex_read(&dec, pcm, dec.samples);

        mp3dec_ex_close(&dec);
        fclose(mp3File);

        if (samplesRead == 0) {
            qWarning() << "FAILED: MP3 file has no audio:" << inputFile;
            delete[] pcm;
            return false;
        }

        totalFrames = samplesRead / channels;
    }

    short* interleaved = new short[totalFrames * targetChannels];
    for (size_t i = 0; i < totalFrames; ++i) {
        for (uint32_t ch = 0; ch < targetChannels; ++ch) {
            if (ch < channels)
                interleaved[i * targetChannels + ch] = pcm[i * channels + ch];
            else
                interleaved[i * targetChannels + ch] = pcm[i * channels];
        }
    }

    delete[] pcm;

    size_t finalFrames = 0;
    short* finalData = new short[static_cast<size_t>(totalFrames * ((double)targetSampleRate / sampleRate)) * targetChannels];

    for (uint32_t ch = 0; ch < targetChannels; ++ch) {
        short* src = new short[totalFrames];
        for (size_t i = 0; i < totalFrames; ++i)
            src[i] = interleaved[i * targetChannels + ch];

        size_t outFrames = 0;
        short* resampled = resampleLinear(src, sampleRate, totalFrames, targetSampleRate, outFrames);

        for (size_t i = 0; i < outFrames; ++i)
            finalData[i * targetChannels + ch] = resampled[i];

        finalFrames = outFrames;

        delete[] src;
        delete[] resampled;
    }

    delete[] interleaved;

    drwav_data_format format;
    format.container = drwav_container_riff;
    format.format = DR_WAVE_FORMAT_PCM;
    format.channels = targetChannels;
    format.sampleRate = targetSampleRate;
    format.bitsPerSample = 16;

    FILE* file = nullptr;

#ifdef _WIN32
    std::wstring wpath = outputFile.toStdWString();
    if (_wfopen_s(&file, wpath.c_str(), L"wb") != 0 || !file) {
        qWarning() << "FAILED: Cannot open file for writing (Windows, Unicode path):" << outputFile;
        delete[] finalData;
        return false;
    }
#else
    std::string path = outputFile.toStdString();
    file = fopen(path.c_str(), "wb");
    if (!file) {
        qWarning() << "FAILED: Cannot open file for writing (POSIX):" << outputFile;
        delete[] finalData;
        return false;
    }
#endif

    drwav wavWriter;
    if (!drwav_init_write_sequential(&wavWriter, &format, 0, my_write_proc, file, nullptr)) {
        qWarning() << "FAILED: drwav_init_write_sequential failed for:" << outputFile;
        fclose(file);
        delete[] finalData;
        return false;
    }

    qDebug() << "Final frames:" << finalFrames;
    if (finalFrames == 0) {
        qWarning() << "No frames to write. Something went wrong in resampling.";
        delete[] finalData;
        return false;
    }

    drwav_uint64 written = drwav_write_pcm_frames(&wavWriter, finalFrames, finalData);
    qDebug() << "Written frames:" << written;
    if (written == 0) {
        qWarning() << "Failed to write WAV data.";
    }

    drwav_uninit(&wavWriter);
    fclose(file);
    delete[] finalData;

    qDebug() << "SUCCESS: Converted to" << targetChannels << "ch" << targetSampleRate << "Hz:" << outputFile;
    return true;
}
