#include "learnprocesscontroller.hpp"
#include <QDebug>

LearnProcessController::LearnProcessController(QObject *parent)
    : QObject{parent}
{
    m_process = new QProcess(this);

    connect(m_process, &QProcess::readyReadStandardOutput, this, &LearnProcessController::handleReadyRead);
    connect(m_process, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, &LearnProcessController::handleFinished);
}

uint LearnProcessController::currentPercent() const
{
    return m_percent;
}

void LearnProcessController::startLearn(QString program,
                                        QString script_file_path,
                                        const QString &target_model_path,
                                        const QString &voice_source_path,
                                        const QString &voice_target_path)
{
    if (m_process->state() != QProcess::NotRunning) {
        qWarning() << "Process already running";
        return;
    }

    m_modelPath = target_model_path;

    QStringList args;
    args << "-u" << script_file_path << target_model_path << voice_source_path << voice_target_path;

    m_percent = 0;
    emit currentPercentChanged(m_percent);
    emit learnStarted();

    m_process->start(program, args);
}

void LearnProcessController::handleReadyRead()
{
    while (m_process->canReadLine()) {
        QByteArray line = m_process->readLine().trimmed();
        bool ok = false;
        int value = line.toInt(&ok);

        if (ok && value >= 0 && value <= 100) {
            if (static_cast<uint>(value) != m_percent) {
                m_percent = value;
                emit currentPercentChanged(m_percent);
            }
        } else {
            qDebug() << "[LearnProcessController] Unexpected output:" << line;
        }
    }
}

void LearnProcessController::handleFinished(int exitCode, QProcess::ExitStatus exitStatus)
{
    if (exitStatus == QProcess::NormalExit && exitCode == 0) {
        emit learnEnded(m_modelPath);
    } else {
        emit learnFailed("Training process failed or was aborted.");
    }
}

void LearnProcessController::stopLearn()
{
    if (m_process->state() != QProcess::NotRunning) {
        m_process->kill();
    }
}
