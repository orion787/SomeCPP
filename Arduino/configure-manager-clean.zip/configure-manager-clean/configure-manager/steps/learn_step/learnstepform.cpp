#include "learnstepform.hpp"
#include "ui_learnstepform.h"
#include "databaseservice.hpp"

#include <QFile>
#include <QFileInfo>
#include <QInputDialog>
#include <QMessageBox>
#include <QUuid>
#include <settings.hpp>

LearnStepForm::LearnStepForm(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::LearnStepForm)
{
    ui->setupUi(this);
    ui->startLearnButton->setEnabled(false);
    setupConnections();
}

LearnStepForm::~LearnStepForm()
{
    delete ui;
}
void LearnStepForm::checkReadyState() {
    if (ui->modelNameLineEdit->text().isEmpty()
        || !modelNameIsUnique(ui->modelNameLineEdit->text())
        || ui->modelNameLineEdit->text().length() > Settings::instance().modelNameMaxlen()
        ) {
        ui->modelNameLineEdit->setStyleSheet("QLineEdit { border: 1px solid red; }");
        ui->startLearnButton->setEnabled(false);
        return;
    } else {
        ui->modelNameLineEdit->setStyleSheet("");
        ui->startLearnButton->setEnabled(true);
    }

    ui->startLearnButton->setEnabled(voicesIsSelected());
}
void LearnStepForm::setupConnections()
{
    ui->startLearnButton->setEnabled(false);

    connect(ui->sourceListWidget, &QListWidget::currentRowChanged, this, [this](int currentRow) {
        QListWidgetItem* selectedItem = ui->sourceListWidget->item(currentRow);
        if (selectedItem) {
            QString itemText = selectedItem->text();

            for (int i = 0; i < ui->targetListWidget->count(); ++i) {
                QListWidgetItem* targetItem = ui->targetListWidget->item(i);
                if (targetItem && targetItem->text() == itemText) {
                    targetItem->setFlags(targetItem->flags() & ~Qt::ItemIsEnabled);
                } else {
                    targetItem->setFlags(targetItem->flags() | Qt::ItemIsEnabled);
                }
            }
        }

        LearnStepForm::checkReadyState();
    });

    connect(ui->targetListWidget, &QListWidget::currentRowChanged, this, [this](int currentRow) {
        QListWidgetItem* selectedItem = ui->targetListWidget->item(currentRow);
        if (selectedItem) {
            QString itemText = selectedItem->text();

            for (int i = 0; i < ui->sourceListWidget->count(); ++i) {
                QListWidgetItem* sourceItem = ui->sourceListWidget->item(i);
                if (sourceItem && sourceItem->text() == itemText) {
                    sourceItem->setFlags(sourceItem->flags() & ~Qt::ItemIsEnabled);
                } else {
                    sourceItem->setFlags(sourceItem->flags() | Qt::ItemIsEnabled);
                }
            }
        }
        LearnStepForm::checkReadyState();
    });

    connect(ui->modelNameLineEdit, &QLineEdit::editingFinished, this, [this]() {
        LearnStepForm::checkReadyState();
    });

    // Start learning process
    connect(ui->startLearnButton, &QPushButton::clicked, this, [this]() {

        auto pythonIsInstalled =  [](){
            QProcess process;
            process.start(Settings::instance().interpretatorPath(), QStringList() << "--version");
            if (!process.waitForFinished(1000))
                return false;
            return process.exitCode() == 0;
        };

        if (!pythonIsInstalled()) {
            QMessageBox::warning(this, "Python3 is required", "Please install python3 and restart PC for start training");
            return;
        }

        QString source_path = ui->sourceListWidget->currentItem()->data(Qt::UserRole).toString();
        QString target_path = ui->targetListWidget->currentItem()->data(Qt::UserRole).toString();

        ui->startLearnButton->setEnabled(false);
        ui->learnProgressBar->setValue(0);

        QString uniqueModelFileName = "model_" +
                                      QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss") +
                                      "_" + QUuid::createUuid().toString(QUuid::Id128).mid(0, 8) +
                                      ".pt";

        QString targetModelPath = Settings::instance().modelsDirPath() + "/" + uniqueModelFileName;

        learnProcessController.startLearn(
            Settings::instance().interpretatorPath(),
            Settings::instance().scriptsDirPath() + "/" + Settings::instance().learnScriptName(),
            targetModelPath,
            source_path,
            target_path
            );
    });

    // Handle progress updates
    connect(&learnProcessController, &LearnProcessController::currentPercentChanged, this, [this](uint percent) {
        ui->learnProgressBar->setValue(static_cast<int>(percent));
        ui->learnProgressBar->setEnabled(true);
    });

    // Handle successful completion
    connect(&learnProcessController, &LearnProcessController::learnEnded, this, [this](QString& modelPath) {
        QMessageBox::information(this, "Training Complete", "The training process finished successfully.");

        QFileInfo file_info(modelPath);
        if (file_info.exists()) {
            ModelStruct model;
            model.filePath = file_info.fileName();
            model.name = ui->modelNameLineEdit->text();
            model.description = ui->modelDescriptionLineEdit->text();
            DatabaseService::instance().models->addModel(model);
        }
        ui->startLearnButton->setEnabled(true);
        ui->learnProgressBar->setValue(0);
        ui->learnProgressBar->setEnabled(false);
        clearForm();
        setEnabledForm(true);
    });

    // Handle failure
    connect(&learnProcessController, &LearnProcessController::learnFailed, this, [this](const QString &error) {
        QMessageBox::critical(this, "Training Failed", "An error occurred during training:\n" + error);
        ui->startLearnButton->setEnabled(true);
        ui->learnProgressBar->setValue(0);
        clearForm();
        setEnabledForm(true);
    });

    // Handle training start
    connect(&learnProcessController, &LearnProcessController::learnStarted, this, [this]() {
        qDebug() << "Training started...";
        ui->learnProgressBar->setValue(0);
        setEnabledForm(false);
    });
}

bool LearnStepForm::voicesIsSelected()
{
    auto sourceItem  = ui->sourceListWidget->currentItem();
    auto targetItem  = ui->targetListWidget->currentItem();

    return sourceItem && targetItem;
}

bool LearnStepForm::modelNameIsUnique(QString name)
{
    if (DatabaseService::instance().models->getModelByName(name).has_value()) {
        return false;
    }
    return true;
}

void LearnStepForm::showEvent(QShowEvent *event)
{
    Q_UNUSED(event)
    updateLists();
    checkReadyState();
}

void LearnStepForm::updateLists()
{
    ui->sourceListWidget->clear();
    ui->targetListWidget->clear();

    auto voice_samples_list = DatabaseService::instance().voice_samples->getAllModels();

    QList<QListWidgetItem> items_list;

    for (const VoiceSampleStruct& voice_sample : voice_samples_list) {
        auto* sourceItem = new QListWidgetItem(voice_sample.name);
        sourceItem->setData(Qt::UserRole, voice_sample.filePath);
        ui->sourceListWidget->addItem(sourceItem);

        auto* targetItem = new QListWidgetItem(voice_sample.name);
        targetItem->setData(Qt::UserRole, voice_sample.filePath);
        ui->targetListWidget->addItem(targetItem);
    }
}

void LearnStepForm::clearForm()
{
    ui->modelNameLineEdit->clear();
    ui->modelDescriptionLineEdit->clear();
}

void LearnStepForm::setEnabledForm(bool enabled)
{
    ui->modelNameLineEdit->setEnabled(enabled);
    ui->modelDescriptionLineEdit->setEnabled(enabled);
    ui->sourceListWidget->setEnabled(enabled);
    ui->targetListWidget->setEnabled(enabled);
}
