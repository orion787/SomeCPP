#ifndef LEARNPROCESSCONTROLLER_HPP
#define LEARNPROCESSCONTROLLER_HPP

#include <QProcess>
#include <QTimer>

class LearnProcessController : public QObject
{
    Q_OBJECT
public:
    explicit LearnProcessController(QObject *parent = nullptr);
    uint currentPercent() const;

public slots:
    void startLearn(QString program,
                    QString script_file_path,
                    const QString &target_model_path,
                    const QString &voice_source_path,
                    const QString &voice_target_path);

    void stopLearn();

signals:
    void currentPercentChanged(uint percent);
    void learnEnded(QString& modelPath);
    void learnStarted();
    void learnFailed(const QString &error); // полезно

private slots:
    void handleReadyRead();
    void handleFinished(int exitCode, QProcess::ExitStatus exitStatus);

private:
    QProcess *m_process = nullptr;
    uint m_percent = 0;

    QString m_modelPath;
};

#endif
