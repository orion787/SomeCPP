#include "utils.h"

bool parseJsonToObj(const QByteArray &rawJson, QJsonObject &outObj) {
    QJsonParseError error;
    QJsonDocument doc = QJsonDocument::fromJson(rawJson, &error);

    if (error.error != QJsonParseError::NoError) {
        qWarning() << "JSON parse error:" << error.errorString();
        return false;
    }

    if (!doc.isObject()) {
        qWarning() << "Expected JSON object, got:" << (doc.isArray() ? "array" : "null/other");
        return false;
    }

    outObj = doc.object();
    return true;
}

void removeWavFiles(const QString &dirPath) {
    QDir directory(dirPath);

    QStringList filters;
    filters << "*.wav";

    QFileInfoList wavFiles = directory.entryInfoList(filters, QDir::Files | QDir::NoSymLinks);

    for (const QFileInfo &fileInfo : wavFiles) {
        QFile file(fileInfo.absoluteFilePath());
        if (file.remove()) {
            qDebug() << "Removed:" << fileInfo.fileName();
        } else {
            qWarning() << "Failed to remove:" << fileInfo.fileName();
        }
    }
}