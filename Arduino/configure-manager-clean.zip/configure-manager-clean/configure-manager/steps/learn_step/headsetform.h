#ifndef HEADSETFORM_HPP
#define HEADSETFORM_HPP

#include <QWidget>
#include <QTimer>
#include "headsetslist.h"

#ifdef HEADSET_MOCK
    #include "mockheadsetformconnector.h"
#else
    #include "http_service.hpp"
    #include "headsetformconnector.h"
#endif

namespace Ui {
class HeadsetForm;
}

class HeadsetForm : public QWidget
{
    Q_OBJECT

public:
    explicit HeadsetForm(QWidget *parent = nullptr);
    ~HeadsetForm();

private:
    Ui::HeadsetForm *ui;
    QThread *connectorThread = nullptr;
    HeadsetConnector *connectorActions = nullptr;
    HeadsetsList headsetsList;

    QString statusSaveMsg(const QString& text);

#ifdef HEADSET_MOCK
    MockHttpClient hc;
#else
    HttpClient hc;
#endif

    int currentRow = -1;
    QString currentAlias;

private slots:
    void applySetupReady(const bool result);
    void handleSaveState(const QJsonObject setupData);
    void handleScanState(const QJsonObject setupData);
    void handleCurrentHeadset(const QJsonObject setupData);
    void onRowSelected();
    void onClickSaveButton(bool checked);
    void onClickScanButton(bool checked);
    void onCellActivated(int row, int column);
};

#endif  // HEADSETFORM_HPP
