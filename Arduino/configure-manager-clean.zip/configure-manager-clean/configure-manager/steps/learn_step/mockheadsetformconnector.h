#ifndef MOCK_HEADSETCONNECTOR_H
#define MOCK_HEADSETCONNECTOR_H

#include <QObject>
#include <QUrl>
#include <QThread>
#include <QJsonObject>
#include <QString>
#include <QJsonDocument>
#include <QTimer>

struct HttpRequest {
    QString method;
    QString body;
    QString url;

    void clean() {
        method = "";
        body = "";
        url = "";
    }
};

struct ScanStates {
    bool add = false;
    bool deleteElems = false;
    bool success = false;
    bool finish = false;

    QByteArray headsetsListAdd = R"(
        {"headsets_list":
            [
                {"action": "add", "addr": "192.168.1.10", "alias": "gateway", "object": "router" },
                {"action": "add", "addr": "10.0.0.5", "alias": "db-master", "object": "postgresql" },
                {"action": "add", "addr": "172.16.0.23", "alias": "web-prod-01", "object": "nginx" },
                {"action": "add", "addr": "192.168.50.15", "alias": "printer-hp", "object": "scanner" },
                {"action": "add", "addr": "10.10.10.100", "alias": "backup-nas", "object": "storage" },
                {"action": "add", "addr": "192.168.2.55", "alias": "switch-core", "object": "cisco-switch" },
                {"action": "add", "addr": "10.0.1.12", "alias": "mail-server", "object": "exim" },
                {"action": "add", "addr": "172.16.5.8", "alias": "dns-internal", "object": "bind" },
                {"action": "add", "addr": "192.168.100.20", "alias": "api-gateway", "object": "kong" },
                {"action": "add", "addr": "10.0.2.15", "alias": "monitoring", "object": "prometheus" },
                {"action": "add", "addr": "192.168.30.9", "alias": "app-server-02", "object": "tomcat" },
                {"action": "add", "addr": "172.16.10.45", "alias": "cache-node", "object": "redis" },
                {"action": "add", "addr": "10.0.3.7", "alias": "log-collector", "object": "elasticsearch" },
                {"action": "add", "addr": "192.168.200.11", "alias": "dev-laptop", "object": "ubuntu-ws" },
                {"action": "add", "addr": "10.0.4.33", "alias": "iot-sensor-01", "object": "mqtt-broker" }
            ]
        }
    )";

    QByteArray headsetsListDelete = R"(
    {"headsets_list":
        [
            {"action": "delete", "addr": "192.168.1.10", "alias": "gateway", "object": "router" },
            {"action": "delete", "addr": "10.0.0.5", "alias": "db-master", "object": "postgresql" }
        ]
    }
    )";

    void changeState(QJsonObject& setupData, bool scanOn, bool scanOff) {
        if(scanOn) {
            if(finish) {
                setupData["headsets_list"] = "[]";
                setupData["scan_state"] = "nothing";
            } else if (!add) {
                auto headsets = QJsonDocument::fromJson(headsetsListAdd).object();
                setupData.insert("headsets_list", headsets["headsets_list"]);
                setupData["scan_state"] = "scanning";
                add = true;
            } else if(!deleteElems) {
                auto headsets = QJsonDocument::fromJson(headsetsListDelete).object();
                setupData.insert("headsets_list", headsets["headsets_list"]);
                setupData["scan_state"] = "scanning";
                deleteElems = true;
                finish = true;
            }
        }

        if(scanOff) {
            if(!success) {
                setupData["scan_state"] = "success";
                setupData["headsets_list"] = "[]";
                success = true;
            } else {
                setupData["scan_state"] = "nothing";
                setupData["headsets_list"] = "[]";
            }
        }
    }

    void clean() {
        add = false;
        deleteElems = false;
        success = false;
        finish = false;
    }

};

struct SaveStates {
    bool pairing = false;
    bool connecting = false;
    bool trusting = false;
    bool success = false;
    bool finish = false;

    void changeState(QJsonObject& setupData, const QString& currentHeadset) {
        if(finish) {
            setupData["save_state"] = "nothing";
        } else if(!pairing) {
            setupData["save_state"] = "pairing";
            pairing = true;
        } else if(!connecting) {
            setupData["save_state"] = "connecting";
            connecting = true;
        } else if(!trusting) {
            setupData["save_state"] = "trusting";
            trusting = true;
        } else if(!success) {
            setupData["save_state"] = "success";
            setupData["current_headset"] = currentHeadset;
            success = true;
            finish = true;
        }
    }

    void clean() {
        pairing = false;
        connecting = false;
        success = false;
        trusting = false;
        finish = false;
    }
};

class HeadsetConnector : public QObject {
    Q_OBJECT
public:
    explicit HeadsetConnector(QObject *parent = nullptr);

    // Q_INVOKABLE void connect();
    // Q_INVOKABLE void disconnect();

private:
    QTimer *timerSetupReady = nullptr;
    QJsonObject setupData;

    void updateSetup();
    void requestHandler(HttpRequest& httpRequest);

    bool setupReadyState = true;
    bool enableOnceSetupNotReadyState = false;

    bool saveOn = false;
    bool scanOn = false;
    bool scanOff = false;

    ScanStates scanStates;
    SaveStates saveStates;

    QString currentHeadset;

signals:
    void setupReady(const bool result);
    void newSetupData(QJsonObject setupData);
    void hasError(QString setupData);
};

class MockHttpClient : public QObject {
    Q_OBJECT
public:
    explicit MockHttpClient(QObject *parent = nullptr);

    void get(const QString &urlPath);
    void post(const QString &urlPath, const QByteArray &body);
};

#endif // MOCK_HEADSETCONNECTOR_H
