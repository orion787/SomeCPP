#include "mockgetconnectactions.hpp"
#include <QTimer>
#include <QTLogging>
#include <QDebug>

GetConnectActions::GetConnectActions(QObject *parent) : QObject(parent) {}

void GetConnectActions::connect() {
    QTimer::singleShot(100, this, [this]() {
        qDebug() << "[MockGetConnectActions] Emitting connectING";
        emit connecting();
    });

    QTimer::singleShot(2000, this, [this]() {
        qDebug() << "[MockGetConnectActions] Emitting connected";
        emit connected();
    });
}

void GetConnectActions::disconnect() {
    QTimer::singleShot(100, this, [this]() {
        qDebug() << "[MockGetConnectActions] Emitting disconnect";
        emit disconnected();
    });
}