#include "getconnectactions.hpp"

#include <QTimer>
#include <QMetaEnum>

inline constexpr const char* URL_PATH_CONNECT = "/connect";
inline constexpr const char* URL_PATH_DISCONNECT = "/disconnect";

GetConnectActions::GetConnectActions(QObject *parent) : httpClient(parent), QObject(parent) {
    QObject::connect(&httpClient, &HttpClient::replyReady, this, [this](HttpClient::RequestType reguestType, QString urlPath, int statusCode, const QByteArray &data){
        if(statusCode != 200) {
            emit connectingFailed("Wrong status code");
            hasConnect = false;
            return;
        }

        if(data.toStdString() == "connected") {
            hasConnect = true;
            emit connected();
            return;
        }else if(data.toStdString() == "disconnected") {
            hasConnect = false;
            emit disconnected();
            return;
        }else {
            emit connectingFailed("Wrong answer");
        }
    });

    QObject::connect(&httpClient, &HttpClient::replyError, this, [this](HttpClient::RequestType reguestType, QString urlPath, QNetworkReply::NetworkError error){
        auto metaEnum = QMetaEnum::fromType<QNetworkReply::NetworkError>();
        const char* errorDescription = metaEnum.valueToKey(static_cast<int>(error));
        emit connectingFailed(QString(errorDescription));
        hasConnect = false;
    });

    timer = new QTimer(this);
    QObject::connect(timer, &QTimer::timeout, this, &GetConnectActions::checkConnection);
    timer->start(1000);
}

void GetConnectActions::checkConnection() {
    if(hasConnect) {
        httpClient.get(URL_PATH_CONNECT);
        hasConnect = false;
    }
}

void GetConnectActions::connect() {
    emit connecting();
    httpClient.get(URL_PATH_CONNECT);
}

void GetConnectActions::disconnect() {
    hasConnect = false;
    emit disconnected();
    httpClient.get(URL_PATH_DISCONNECT);
}