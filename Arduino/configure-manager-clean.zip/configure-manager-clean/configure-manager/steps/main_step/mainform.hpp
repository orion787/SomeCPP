#ifndef MAINFORM_HPP
#define MAINFORM_HPP

#include "abstracttableeditorwidget.hpp"
#include "buttondelegate.hpp"
#include <QSqlTableModel>
#include <QSqlField>
#include <settings.hpp>
#include <QFile>
#include <QShortcut>

class MainForm : public AbstractTableEditorWidget {
    Q_OBJECT
public:
    explicit MainForm(QWidget* parent = nullptr)
        : AbstractTableEditorWidget(parent) {

        sortByField("created");
        tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
        tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    }

protected:
    QString tableName() const override {
        return "models";
    }

    QStringList hiddenColumns() const override {
        return { "id", "file_path" };
    }

    QStringList notNullColumns() const override {
        return {"name"};
    }

    QMap<QString, uint> maxLenghtColumns() const override {
        QMap<QString, uint> lenMap;
        lenMap["name"] = Settings::instance().modelNameMaxlen();
        return lenMap;
    }

    int filterColumn() const override {
        return model ? 1 : 0;
    }

    QStyledItemDelegate* itemDelegate() const override {


        auto* delegate = new ButtonDelegate(const_cast<MainForm*>(this));

        QIcon trashIcon = style()->standardIcon(QStyle::SP_TrashIcon);

        QVector<ButtonSpec> specs = {
            ButtonSpec("🗑️", QIcon(), "Remove"),
        };

        delegate->setButtons(specs);

        // QShortcut *del_shortcut = new QShortcut(QKeySequence(Qt::Key_Return), this);
        // connect(del_shortcut, &QShortcut::activated, this, [this]() {
        //     this->onButtonClicked(const QModelIndex& index, int buttonId);
        // });


        return delegate;
    }

    void onButtonClicked(const QModelIndex& index, int buttonId) override {
        int sourceRow = proxyModel->mapToSource(index).row();
        QSqlRecord record = model->record(sourceRow);
        QString name = record.field(record.indexOf("name")).value().toString();
        QString file_path = record.field(record.indexOf("file_path")).value().toString();

        if (buttonId == 0) {
            if (QMessageBox::question(this, "Remove", "Remove item ?") == QMessageBox::Yes) {
                QFile model_file(Settings::instance().modelsDirPath()+"/"+file_path);
                int sourceRow = proxyModel->mapToSource(index).row();
                if (model_file.exists()) {
                    model_file.remove();
                }
                model->removeRow(sourceRow);
                model->select();
            }
        }
    }

    QStringList readOnlyColumns() const override {
        return { "id", "created" };
    }

};

#endif // MAINFORM_HPP
