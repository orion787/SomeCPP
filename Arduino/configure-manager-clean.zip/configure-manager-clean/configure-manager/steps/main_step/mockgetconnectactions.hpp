#ifndef MOCKGETCONNECTACTIONS_H
#define MOCKGETCONNECTACTIONS_H

#include <QObject>
#include <QUrl>
#include <QTimer>

class GetConnectActions : public QObject {
    Q_OBJECT
public:
    explicit GetConnectActions(QObject *parent = nullptr);

    Q_INVOKABLE void connect();
    Q_INVOKABLE void disconnect();

signals:
    void connecting();
    void connectingFailed(const QString &reason);
    void connected();
    void connectionFailed(const QString &reason);
    void disconnected();
};

#endif // MOCKGETCONNECTACTIONS_H
